const fs = require('node:fs');
const assert = require('node:assert/strict');
const parser = require('@babel/parser');
const generate = require('@babel/generator').default;
const file = 'src/learn/components/lesson-labs/PersistentStructuresLabs.jsx';
const source = fs.readFileSync(file, 'utf8');
const before = parser.parse(source, { sourceType: 'module', plugins: ['jsx'] });
function normalized(value) {
  if (Array.isArray(value)) return value.filter(node => !(node?.type === 'JSXText' && /^\s*\n\s*$/.test(node.value))).map(normalized);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value).filter(([key]) => !['start', 'end', 'loc', 'extra', 'leadingComments', 'trailingComments', 'innerComments'].includes(key)).map(([key, item]) => [key, normalized(item)]));
}
const expected = normalized(before);
function visit(node, depth = 0) {
  if (!node || typeof node !== 'object') return;
  if (node.type === 'JSXElement' || node.type === 'JSXFragment') {
    const children = node.children;
    const meaningfulText = children.some(child => child.type === 'JSXText' && !/^\s*\n\s*$/.test(child.value));
    const content = children.filter(child => !(child.type === 'JSXText' && /^\s*\n\s*$/.test(child.value)));
    if (!meaningfulText && content.length > 1) {
      node.children = content.flatMap(child => [{ type: 'JSXText', value: '\n' + '  '.repeat(depth + 2) }, child]);
      node.children.push({ type: 'JSXText', value: '\n' + '  '.repeat(depth + 1) });
    }
    for (const child of node.children) visit(child, depth + 1);
    return;
  }
  for (const value of Object.values(node)) {
    if (Array.isArray(value)) value.forEach(child => visit(child, depth));
    else if (value && typeof value === 'object') visit(value, depth);
  }
}
visit(before);
const formatted = generate(before, { comments: true, compact: false, jsescOption: { minimal: true } }, source).code + '\n';
const after = parser.parse(formatted, { sourceType: 'module', plugins: ['jsx'] });
assert.deepEqual(normalized(after), expected);
fs.writeFileSync(file, formatted);
console.log('Structural JSX lines expanded; normalized AST unchanged apart from non-rendering newline-only JSX whitespace.');

