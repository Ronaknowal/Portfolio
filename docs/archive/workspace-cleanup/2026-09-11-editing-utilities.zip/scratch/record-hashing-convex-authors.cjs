const fs = require('node:fs');
const { createHash } = require('node:crypto');
const filename = 'docs/teaching/dsa-math-foundations-progress.json';
const progress = JSON.parse(fs.readFileSync(filename));
const manifest = JSON.parse(fs.readFileSync('src/learn/data/lesson-manifest.json'));
const hash = source => createHash('sha256').update(fs.readFileSync(source)).digest('hex');
const reviewed = [
  { id: 'convex-optimization', design: 'CONVEX-OPTIMIZATION-DESIGN.md', verification: 'CONVEX-OPTIMIZATION-VERIFICATION.md', data: 'convex-optimization', component: 'ConvexOptimizationLabs' },
  { id: 'hashing-collision-resolution-amortized-analysis', design: 'HASHING-AMORTIZED-LESSON-DESIGN.md', verification: 'HASHING-AMORTIZED-VERIFICATION.md', data: 'hashing-amortized', component: 'HashingAmortizedLabs' },
];
for (const record of reviewed) {
  const entry = progress.topics.find(topic => topic.id === record.id);
  if (entry.status !== 'in-progress') throw new Error(`Unexpected status: ${record.id}`);
  const source = `src/learn/data/${manifest[record.id].slice(2)}`;
  const files = [source, `src/learn/data/${record.data}-models.js`, `src/learn/data/${record.data}-examples.js`, `src/learn/components/lesson-labs/${record.component}.jsx`, `src/learn/components/lesson-labs/${record.data}-labs.css`, `src/learn/data/curriculum/blueprints/${record.id}.js`];
  if (entry.moduleId === 'data-structures-algorithms') files.push(`src/learn/data/practice/${record.id}.js`);
  Object.assign(entry, { status: 'author-verified', source: manifest[record.id], designRecord: `docs/teaching/${record.design}`, verificationRecord: `docs/teaching/${record.verification}`, reviewedSourceSha256: hash(source), reviewedFiles: Object.fromEntries(files.map(file => [file, hash(file)])) });
}
for (const [id, design] of [['learning-rate-schedules-cosine-warmup-onecyclelr', 'LEARNING-RATE-SCHEDULES-DESIGN.md'], ['string-matching-prefix-functions-rolling-hashes', 'STRING-MATCHING-LESSON-DESIGN.md']]) {
  const entry = progress.topics.find(topic => topic.id === id);
  if (entry.status !== 'pending') throw new Error(`Unexpected next assignment: ${id}`);
  Object.assign(entry, { status: 'in-progress', designRecord: `docs/teaching/${design}` });
}
fs.writeFileSync(filename, JSON.stringify(progress, null, 2) + '\n');
console.log('Hashing and Convex author evidence recorded; schedules and string matching assigned.');
