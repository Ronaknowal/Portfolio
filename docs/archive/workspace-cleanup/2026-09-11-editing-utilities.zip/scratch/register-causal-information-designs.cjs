const fs = require('node:fs');
const assert = require('node:assert/strict');
const entries = [
  ['causalInferenceBlueprint','causal-inference-do-calculus','Causal Inference & Do-Calculus','CAUSAL-INFERENCE-LESSON-DESIGN.md'],
  ['mutualInformationBlueprint','mutual-information-information-bottleneck','Mutual Information & Information Bottleneck','MUTUAL-INFORMATION-LESSON-DESIGN.md'],
];
const indexPath = 'src/learn/data/curriculum/blueprints/index.js';
let index = fs.readFileSync(indexPath, 'utf8');
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(ledgerPath));
for (const [name,id,title,record] of entries) {
  assert(!index.includes(name));
  index = "import " + name + " from './" + id + ".js';\n" + index.replace(/};\s*$/, "  '" + title + "': " + name + ",\n};\n");
  const topic = ledger.topics.find(entry => entry.id === id);
  assert.equal(topic.status, 'pending');
  Object.assign(topic, { status: 'in-progress', designRecord: 'docs/teaching/' + record });
}
fs.writeFileSync(indexPath, index);
fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2) + '\n');
