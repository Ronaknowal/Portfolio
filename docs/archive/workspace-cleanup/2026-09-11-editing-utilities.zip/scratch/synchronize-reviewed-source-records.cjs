const fs = require('node:fs');
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(ledgerPath));
const manifest = JSON.parse(fs.readFileSync('src/learn/data/lesson-manifest.json'));
for (const topic of ledger.topics) {
  if (manifest[topic.id]) topic.source = manifest[topic.id];
  if (topic.id === 'computational-geometry-robust-predicates-convex-hulls') topic.designRecord = 'docs/teaching/COMPUTATIONAL-GEOMETRY-LESSON-DESIGN.md';
  if (topic.id === 'randomized-algorithms-sampling-error-guarantees') topic.designRecord = 'docs/teaching/RANDOMIZED-ALGORITHMS-LESSON-DESIGN.md';
  if (topic.id === 'constrained-multi-objective-optimization') topic.designRecord = 'docs/teaching/CONSTRAINED-MULTIOBJECTIVE-DESIGN.md';
}
fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2) + '\n');
console.log('Live source mappings synchronized without changing any evidence status.');
