const fs = require('node:fs');
const parser = require('@babel/parser');
const draft = 'scratch/bayesian-inference-review/lesson-body.jsx';
let source = fs.readFileSync(draft, 'utf8');
source = source.replace('covarianceVar(θ)', 'covariance Var(θ)').replace('is(4/6)', 'is (4/6)').replace('prior(2,1,1)', 'prior (2,1,1)').replace('counts(1,2,0)', 'counts (1,2,0)').replaceAll('in[0,1]', 'in [0,1]');
source = source.replace('The evidence shifts toward lower θ than the 8/10 example. Required checks:', 'The evidence shifts toward lower θ than the 8/10 example. At 10,000 cells, the mean is about .420543, P(θ>.7) about .036292, and the ordered-sequence evidence about .000681820. These agree with a separate continuous integral. When sensitivity equals the false-positive rate, reports carry no information about θ and the posterior stays at the prior. Required checks:');
const ast = parser.parse(source, { sourceType: 'module', plugins: ['jsx'] });
const changes = [];
function visit(node) {
  if (!node || typeof node !== 'object') return;
  if (node.type === 'JSXText') {
    const original = source.slice(node.start, node.end);
    const escaped = original.replaceAll('>', '&gt;');
    if (escaped !== original) changes.push({ start: node.start, end: node.end, escaped });
  }
  for (const [key, value] of Object.entries(node)) {
    if (['loc', 'start', 'end', 'extra'].includes(key)) continue;
    if (Array.isArray(value)) value.forEach(visit);
    else if (value && typeof value === 'object') visit(value);
  }
}
visit(ast);
for (const change of changes.sort((a, b) => b.start - a.start)) source = source.slice(0, change.start) + change.escaped + source.slice(change.end);
parser.parse(source, { sourceType: 'module', plugins: ['jsx'] });
parser.parse(fs.readFileSync('src/learn/components/lesson-labs/BayesianInferenceLabs.jsx', 'utf8'), { sourceType: 'module', plugins: ['jsx'] });
fs.writeFileSync('src/learn/data/topics/bayesian-inference-conjugate-priors.jsx', source);
console.log('Published complete parsed Bayesian lesson; preserved identity and manifest mapping.');
