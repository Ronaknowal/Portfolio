const fs = require('node:fs');
const assert = require('node:assert/strict');
const entries = [
  ['stochasticProcessesBlueprint', 'stochastic-processes-markov-chains-brownian-motion-poisson', 'Stochastic Processes (Markov Chains, Brownian Motion, Poisson)', 'STOCHASTIC-PROCESSES-LESSON-DESIGN.md'],
  ['dynamicalSystemsBlueprint', 'dynamical-systems-theory-chaos', 'Dynamical Systems Theory & Chaos', 'DYNAMICAL-SYSTEMS-LESSON-DESIGN.md'],
];
const indexPath = 'src/learn/data/curriculum/blueprints/index.js';
let index = fs.readFileSync(indexPath, 'utf8');
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(ledgerPath));
for (const [name, id, title, record] of entries) {
  assert(!index.includes(name));
  assert(fs.statSync('docs/teaching/' + record).size > 500);
  index = "import " + name + " from './" + id + ".js';\n" + index.replace(/};\s*$/, '  ' + JSON.stringify(title) + ': ' + name + ',\n};\n');
  const topic = ledger.topics.find(row => row.id === id);
  assert.equal(topic.status, 'pending', id);
  Object.assign(topic, { status: 'in-progress', designRecord: 'docs/teaching/' + record });
}
fs.writeFileSync(indexPath, index);
fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2) + '\n');
