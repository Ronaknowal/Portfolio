const fs = require('node:fs');
const parser = require('@babel/parser');
const generate = require('@babel/generator').default;
const file = 'scratch/bayesian-inference-review/lesson-body.jsx';
let source = fs.readFileSync(file, 'utf8');
source = source.replace(' Direct individual video fetches failed in this environment, so use the verified course index to select them.', '');
const ast = parser.parse(source, { sourceType: 'module', plugins: ['jsx'] });
let questions = 0;
function visit(node) {
  if (!node || typeof node !== 'object') return;
  if (node.type === 'JSXElement' && node.openingElement.name.name === 'Practice') {
    if (node.openingElement.attributes.some(attribute => attribute.name?.name === 'prompt')) throw Error('Already migrated.');
    const index = node.children.findIndex(child => child.type === 'JSXElement');
    const prompt = node.children.splice(index, 1)[0];
    node.openingElement.attributes.push({ type: 'JSXAttribute', name: { type: 'JSXIdentifier', name: 'prompt' }, value: { type: 'JSXExpressionContainer', expression: prompt } });
    questions += 1;
  }
  if (node.type === 'JSXText') {
    node.value = node.value.replace(/([A-Za-z])(\d)/g, '$1 $2').replace(/([A-Za-z])(\.\d)/g, '$1 $2');
    if (node.extra) delete node.extra;
  }
  for (const [key, value] of Object.entries(node)) {
    if (['loc', 'start', 'end', 'extra'].includes(key)) continue;
    if (Array.isArray(value)) value.forEach(visit);
    else if (value && typeof value === 'object') visit(value);
  }
}
visit(ast);
if (questions !== 8) throw Error('Expected eight practice prompts.');
fs.writeFileSync(file, generate(ast, { comments: true, jsescOption: { minimal: true } }).code + '\n');
console.log('Eight practice prompts visible; source parsed and formatted.');
