const fs = require('node:fs');
const assert = require('node:assert/strict');
const parser = require('@babel/parser');
const generate = require('@babel/generator').default;
const files = [
  'src/learn/components/lesson-labs/VectorTensorLabs.jsx',
  'src/learn/data/vector-tensor-models.js',
  'src/learn/data/topics/vectors-matrices-tensor-operations.jsx',
];
function normalize(value) {
  if (Array.isArray(value)) return value.map(normalize);
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).filter(([key]) => !['start', 'end', 'loc', 'extra', 'tokens'].includes(key)).map(([key, child]) => [key, normalize(child)]));
  }
  return value;
}
for (const file of files) {
  const source = fs.readFileSync(file, 'utf8');
  const ast = parser.parse(source, { sourceType: 'module', plugins: ['jsx'] });
  const formatted = generate(ast, { comments: true, compact: false, retainLines: false }, source).code + '\n';
  const after = parser.parse(formatted, { sourceType: 'module', plugins: ['jsx'] });
  assert.deepEqual(normalize(after), normalize(ast), file);
  fs.writeFileSync(file, formatted);
}
fs.writeFileSync('scratch/vector-tensor-verification/formatting-results.json', JSON.stringify({ date: new Date().toISOString(), files, normalizedAstIdentical: true, templateRawAndJsxTextValuesCompared: true }, null, 2));
