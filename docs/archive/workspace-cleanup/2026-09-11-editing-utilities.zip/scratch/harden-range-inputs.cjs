const fs = require('fs');
const root = 'src/learn/components/lesson-labs/';
const first = root + 'RangeQueryLabs.jsx';
let text = fs.readFileSync(first, 'utf8');
text = text.replace(/Number\((left|right|index|value|end|delta|amount)\)/g, 'rangeInteger($1)');
// This state was never read: completed trace.state supplies the next lazy operation.
text = text.replace('  const [state, setState] = useState(() => lazyState());\n', '');
const lazyStart = text.indexOf('export function LazyRangeLab()');
const lazyEnd = text.indexOf('export function PrefixCancellationFigure()', lazyStart);
text = text.slice(0, lazyStart) + text.slice(lazyStart, lazyEnd).replace('setState(next.state); ', '') + text.slice(lazyEnd);
fs.writeFileSync(first, text);
const second = root + 'RangeDequeLabs.jsx';
text = fs.readFileSync(second, 'utf8').replace('RangeCells, RangeField, RangeSteps', 'RangeCells, RangeField, RangeSteps, rangeInteger');
text = text.replace(/Number\((width|target)\)/g, 'rangeInteger($1)');
fs.writeFileSync(second, text);
