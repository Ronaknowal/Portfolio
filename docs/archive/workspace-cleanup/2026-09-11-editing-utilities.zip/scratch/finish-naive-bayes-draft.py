from pathlib import Path
import re
p = Path("scratch/naive-bayes-lesson-draft.jsx")
s = p.read_text(encoding="utf-8")
old = 'The fixed changed-run output and its interpretation follow below once the independent execution is recorded.'
new = 'The fixed changed run gives baseline accuracy 0.7225, Brier 0.201183 and log loss 0.592234; raw GNB gives 0.7258, 0.181789 and 0.552812; sigmoid calibration gives 0.7492, 0.167991 and 0.510724. It changes 134 decisions at 0.5. These are measured finite-sample results under the stated seed, not promised improvements.'
assert old in s
s = s.replace(old, new)
anchor = 'These are measured finite-sample results under the stated seed, not promised improvements.</Prose>'
s = s.replace(anchor, anchor + '<Prose>The four nonempty bins have sizes 506, 364, 231 and 99, mean predictions 0.1538, 0.2859, 0.5042 and 0.6420, and observed positive fractions 0.1166, 0.2830, 0.4502 and 0.6768. The highest bin [0.8,1] is empty. The declared threshold 0.8 again takes no positive actions, giving realized cost 0.277500 per test case. Report that operating limitation alongside the improved global losses. A different seed, distribution or sample size needs its own report; changing the mapping after reading this test requires another untouched evaluation.</Prose>')
# Narrow plain-prose joins only; do not alter URLs, identifiers, code or equations.
start = s.index('<H2>11. Practise')
end = s.index('<Sources alternatives=')
part = s[start:end]
part = re.sub(r'(?<=[A-Za-z])(?=[0-9])', ' ', part)
part = re.sub(r'(?<=[,])(?=[0-9])', ' ', part)
s = s[:start] + part + s[end:]
for before, after in [('after section3','after section 3'), ('Lecture5:', 'Lecture 5:'), ('sections4–7', 'sections 4–7'), ('section7.', 'section 7.'), ('version1.9.1', 'version 1.9.1'), ('section9', 'section 9')]:
    s = s.replace(before, after)
p.write_text(s, encoding="utf-8")
lab = Path("src/learn/components/lesson-labs/NaiveBayesLabs.jsx")
text = lab.read_text(encoding="utf-8").replace('height={355}', 'height={340}')
lab.write_text(text, encoding="utf-8")
