const fs = require('node:fs');
const crypto = require('node:crypto');
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(ledgerPath));
const sources = [
  ['reductions-p-np-computational-intractability', JSON.parse(fs.readFileSync('scratch/intractability-lesson-review/final-source-hashes.json')), 'docs/teaching/REDUCTIONS-INTRACTABILITY-VERIFICATION.md'],
  ['randomized-algorithms-sampling-error-guarantees', Object.fromEntries(Object.entries(JSON.parse(fs.readFileSync('docs/teaching/evidence/randomized-algorithms-author-review.json')).source).map(([file, record]) => [file, record.sha256])), 'docs/teaching/RANDOMIZED-ALGORITHMS-VERIFICATION.md'],
];
for (const [id, hashes, record] of sources) {
  for (const [file, expected] of Object.entries(hashes)) {
    if (crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex') !== expected) throw new Error(`Frozen source changed: ${file}`);
  }
  const topic = ledger.topics.find(entry => entry.id === id);
  topic.status = 'author-verified';
  topic.verificationRecord = record;
  topic.reviewedFiles = hashes;
  topic.reviewedSourceSha256 = hashes[`src/learn/data/topics/${id}.jsx`];
}
fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2) + '\n');
const scriptPath = 'scripts/verify-learning-load-boundaries.cjs';
let script = fs.readFileSync(scriptPath, 'utf8').replaceAll('matrixLessons', 'mathematicsLessons');
const additions = [
  ["reductions-p-np-computational-intractability", ["intractability-examples.js", "intractability-models.js"]],
  ["randomized-algorithms-sampling-error-guarantees", ["randomized-algorithm-examples.js", "randomized-algorithm-models.js"]],
  ["network-flow-minimum-cuts-bipartite-matching", ["network-flow-examples.js", "network-flow-models.js"]],
];
for (const [id, files] of additions) {
  if (!script.includes(`'${id}':`)) script = script.replace('const dsaOwnership = {', `const dsaOwnership = {\n  '${id}': ${JSON.stringify(files)},`);
}
for (const id of ['convex-duality-lagrangian-methods-kkt-conditions', 'second-order-methods-l-bfgs-k-fac-shampoo-natural-gradient']) {
  if (!script.includes(`'${id}'`)) script = script.replace('const mathematicsLessons = [', `const mathematicsLessons = ['${id}', `);
}
fs.writeFileSync(scriptPath, script);
console.log('Frozen author records verified; production isolation cases now include Reductions, Randomized, Flow, KKT and Second-Order.');
