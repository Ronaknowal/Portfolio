const fs = require('node:fs');
const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const evidence = JSON.parse(fs.readFileSync('docs/teaching/evidence/external-memory-author-review.json'));
for (const [file, sha] of Object.entries(evidence.source_sha256)) {
  assert.equal(createHash('sha256').update(fs.readFileSync(file)).digest('hex'), sha, file);
}
const filename = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(filename));
const topic = ledger.topics.find(entry => entry.id === evidence.topic_id);
topic.status = 'author-verified';
topic.source = `./topics/${topic.id}.jsx`;
topic.designRecord = 'docs/teaching/EXTERNAL-MEMORY-LESSON-DESIGN.md';
topic.verificationRecord = 'docs/teaching/EXTERNAL-MEMORY-VERIFICATION.md';
topic.reviewedFiles = evidence.source_sha256;
topic.reviewedSourceSha256 = evidence.source_sha256[`src/learn/data/topics/${topic.id}.jsx`];
fs.writeFileSync(filename, JSON.stringify(ledger, null, 2) + '\n');
console.log('Final External-Memory source author-verified; integration pending.');
