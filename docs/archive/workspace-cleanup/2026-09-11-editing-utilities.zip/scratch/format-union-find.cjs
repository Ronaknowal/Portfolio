const fs = require('node:fs');
const assert = require('node:assert/strict');
const { parse } = require('@babel/parser');
const generate = require('@babel/generator').default;
const files = [
  'src/learn/data/union-find-models.js',
  'src/learn/components/lesson-labs/UnionFindLabs.jsx',
  'src/learn/data/practice/disjoint-sets-union-find.js',
  'src/learn/data/curriculum/blueprints/disjoint-sets-union-find.js',
];
function normalize(value) {
  if (Array.isArray(value)) return value.map(normalize);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value)
    .filter(([key]) => !['start', 'end', 'loc', 'extra', 'errors'].includes(key))
    .map(([key, child]) => [key, normalize(child)]));
}
fs.mkdirSync('scratch/union-find-format-baseline', { recursive: true });
for (const file of files) {
  const before = fs.readFileSync(file, 'utf8');
  const ast = parse(before, { sourceType: 'module', plugins: ['jsx'] });
  const after = generate(ast, { comments: true, compact: false, jsescOption: { minimal: true } }, before).code + '\n';
  assert.deepEqual(normalize(parse(after, { sourceType: 'module', plugins: ['jsx'] })), normalize(ast));
  fs.writeFileSync('scratch/union-find-format-baseline/' + file.replaceAll('/', '__'), before);
  fs.writeFileSync(file, after);
}
console.log('Formatted four Union-Find sources with unchanged normalized AST, comments and strings.');
