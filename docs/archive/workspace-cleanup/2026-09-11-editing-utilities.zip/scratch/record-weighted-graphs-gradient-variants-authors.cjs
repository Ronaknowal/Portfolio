const fs = require('node:fs');
const { createHash } = require('node:crypto');
const assert = require('node:assert/strict');
const filename = 'docs/teaching/dsa-math-foundations-progress.json';
const progress = JSON.parse(fs.readFileSync(filename));
const manifest = JSON.parse(fs.readFileSync('src/learn/data/lesson-manifest.json'));
for (const [id, design, verification, evidence] of [
  ['shortest-paths-spanning-trees-topological-ordering', 'WEIGHTED-GRAPHS-LESSON-DESIGN.md', 'WEIGHTED-GRAPHS-VERIFICATION.md', 'scratch/weighted-graph-lesson-review/final-source-hashes.json'],
  ['gradient-descent-variants-sgd-adam-adagrad-rmsprop-lamb-lars', 'GRADIENT-DESCENT-VARIANTS-DESIGN.md', 'GRADIENT-DESCENT-VARIANTS-VERIFICATION.md', 'scratch/gradient-variants-verification/final-source-hashes.json'],
]) {
  const entry = progress.topics.find(topic => topic.id === id);
  assert.equal(entry.status, 'in-progress');
  const evidenceData = JSON.parse(fs.readFileSync(evidence));
  const hashes = evidenceData.hashes || evidenceData;
  for (const [source, hash] of Object.entries(hashes)) assert.equal(createHash('sha256').update(fs.readFileSync(source)).digest('hex'), hash);
  const source = `src/learn/data/${manifest[id].slice(2)}`;
  Object.assign(entry, { status: 'author-verified', source: manifest[id], designRecord: `docs/teaching/${design}`, verificationRecord: `docs/teaching/${verification}`, reviewedSourceSha256: hashes[source], reviewedFiles: hashes });
}
for (const [id, design] of [['reductions-p-np-computational-intractability', 'REDUCTIONS-INTRACTABILITY-LESSON-DESIGN.md'], ['convex-duality-lagrangian-methods-kkt-conditions', 'CONVEX-DUALITY-KKT-DESIGN.md']]) {
  const entry = progress.topics.find(topic => topic.id === id);
  assert.equal(entry.status, 'pending');
  Object.assign(entry, { status: 'in-progress', designRecord: `docs/teaching/${design}` });
}
fs.writeFileSync(filename, JSON.stringify(progress, null, 2) + '\n');
console.log('Weighted Graphs and Gradient Variants author versions verified and recorded.');
