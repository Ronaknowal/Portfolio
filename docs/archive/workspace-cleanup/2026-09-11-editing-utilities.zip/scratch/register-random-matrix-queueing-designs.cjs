const fs = require('node:fs');
const assert = require('node:assert/strict');
const entries = [
  ['randomMatrixTheoryBlueprint', 'random-matrix-theory', 'Random Matrix Theory', 'RANDOM-MATRIX-THEORY-DESIGN.md'],
  ['queueingTheoryBlueprint', 'queueing-theory-m-m-1-m-g-1-little-s-law', "Queueing Theory (M/M/1, M/G/1, Little's Law)", 'QUEUEING-THEORY-LESSON-DESIGN.md'],
];
const indexPath = 'src/learn/data/curriculum/blueprints/index.js';
let index = fs.readFileSync(indexPath, 'utf8');
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(ledgerPath));
for (const [name, id, title, record] of entries) {
  assert(!index.includes(name));
  assert(fs.statSync('docs/teaching/' + record).size > 500);
  index = "import " + name + " from './" + id + ".js';\n" + index.replace(/};\s*$/, '  ' + JSON.stringify(title) + ': ' + name + ',\n};\n');
  const topic = ledger.topics.find(row => row.id === id);
  assert.equal(topic.status, 'pending', id);
  Object.assign(topic, { status: 'in-progress', designRecord: 'docs/teaching/' + record });
}
fs.writeFileSync(indexPath, index);
fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2) + '\n');
