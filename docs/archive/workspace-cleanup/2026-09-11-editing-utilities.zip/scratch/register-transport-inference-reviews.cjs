const fs = require('node:fs');
const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const read = file => JSON.parse(fs.readFileSync(file));
const hash = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const save = (file, data) => fs.writeFileSync(file, JSON.stringify(data, null, 2) + '\n');
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = read(ledgerPath);
const definitions = [
  ['variational-inference', 'VARIATIONAL-INFERENCE-VERIFICATION.md', read('scratch/variational-inference-lesson-review/final-source-hashes.json')],
  ['exponential-families-sufficient-statistics', 'EXPONENTIAL-FAMILIES-VERIFICATION.md', Object.fromEntries(read('docs/teaching/evidence/exponential-family-author-review.json').sourceFiles.filter(entry => entry.path.startsWith('src/')).map(entry => [entry.path, entry.sha256]))],
  ['measure-theory-probability-spaces', 'MEASURE-THEORY-PROBABILITY-SPACES-VERIFICATION.md', read('scratch/measure-theory-verification/final-source-hashes.json').files],
];
const otFiles = [
  'src/learn/data/topics/optimal-transport-wasserstein-distance-sinkhorn.jsx',
  'src/learn/data/optimal-transport-models.js', 'src/learn/data/optimal-transport-examples.js',
  'src/learn/components/lesson-labs/OptimalTransportLabs.jsx', 'src/learn/components/lesson-labs/optimal-transport-labs.css',
  'src/learn/data/curriculum/blueprints/optimal-transport-wasserstein-distance-sinkhorn.js',
];
definitions.push(['optimal-transport-wasserstein-distance-sinkhorn', 'OPTIMAL-TRANSPORT-VERIFICATION.md', Object.fromEntries(otFiles.map(file => [file, hash(file)]))]);
for (const [id, record, files] of definitions) {
  for (const [file, expected] of Object.entries(files)) assert.equal(hash(file), expected, file);
  const topic = ledger.topics.find(entry => entry.id === id);
  assert.equal(topic.status, 'in-progress', id);
  Object.assign(topic, { status: 'author-verified', verificationRecord: 'docs/teaching/' + record, reviewedFiles: files, reviewedSourceSha256: files['src/learn/data/topics/' + id + '.jsx'] });
}
save('docs/teaching/evidence/variational-inference-author-review.json', {
  frozenAt: new Date().toISOString(), files: definitions[0][2],
  native: read('scratch/variational-inference-native-verification/independent-evidence.json'),
  browser: read('scratch/variational-inference-lesson-review/results.json'),
  numericalCorrection: read('scratch/variational-inference-lesson-review/log-ratio-fix-results.json'),
  independentReview: 'docs/teaching/VARIATIONAL-INFERENCE-INDEPENDENT-REVIEW.md',
});
save('docs/teaching/evidence/measure-theory-author-review.json', {
  frozenAt: read('scratch/measure-theory-verification/final-source-hashes.json').frozenAt, files: definitions[2][2],
  native: read('scratch/measure-theory-verification/native-results.json'), modelCounts: read('scratch/measure-theory-verification/model-counts.json'),
  browser: read('scratch/measure-theory-browser/results.json'), finalLabel: read('scratch/measure-theory-browser/final-label-results.json'),
  independentReview: 'docs/teaching/MEASURE-THEORY-INDEPENDENT-REVIEW.md',
});
const opened = ['mass-split-390','scaling-2-390','cdf-distance-320','reading-1-390','bias-capped-390','inline-1-320','equation-8-320','reading-6-390','reading-9-320','practice-transfer-320'];
const otBrowser = read('scratch/optimal-transport-review/browser/results.json');
for (const result of otBrowser.results) { assert.deepEqual(result.failedRequests, []); assert.deepEqual(result.applicationErrors, []); assert.deepEqual(result.overflowMath, []); assert.equal(result.pageOverflow, false); }
save('docs/teaching/evidence/optimal-transport-author-review.json', {
  frozenAt: new Date().toISOString(), files: definitions[3][2],
  native: read('scratch/optimal-transport-review/native-results.json'), models: read('scratch/optimal-transport-review/model-results.json'),
  browser: otBrowser, formatting: read('scratch/optimal-transport-verification/formatting-results.json'),
  independentReview: 'docs/teaching/OPTIMAL-TRANSPORT-INDEPENDENT-REVIEW.md',
  independentResults: read('scratch/optimal-transport-independent-review/results.json'),
  actuallyOpenedScreenshots: opened.map(name => { const file = 'scratch/optimal-transport-review/browser/' + name + '.png'; return { file, sha256: hash(file) }; }),
  originalBody: { path: 'scratch/optimal-transport-review/original-lesson.jsx', sha256: hash('scratch/optimal-transport-review/original-lesson.jsx') },
});
save(ledgerPath, ledger);
const loadPath = 'scripts/verify-learning-load-boundaries.cjs';
const loading = fs.readFileSync(loadPath, 'utf8');
const ids = definitions.map(entry => entry[0]);
assert(ids.every(id => !loading.includes("'" + id + "'")));
fs.writeFileSync(loadPath, loading.replace('const mathematicsLessons = [', 'const mathematicsLessons = [' + ids.map(id => "'" + id + "'").join(', ') + ', '));
console.log('Mathematics21–24 author-verified and frozen; production loading scope now24 maths +22 DSA +8 integration cases.');
