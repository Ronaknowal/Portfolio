const fs = require('node:fs');
const file = 'src/learn/data/topics/learning-rate-schedules-cosine-warmup-onecyclelr.jsx';
let text = fs.readFileSync(file, 'utf8');
text = text.replace('import { ResumeStateFigure,', 'import { CalibrationUpdateFigure, ResumeStateFigure,');
text = text.replace('    <Prose>The error multiplier explains', '    <CalibrationUpdateFigure />\n    <Prose>The error multiplier explains');
text = text.replace('The previous example on this page used p=(u−W)/(T−W) after warmup: it repeated M at the join and never used m inside its ten-update budget. The program below retains both conventions so you can see the difference. The older formula is not intrinsically invalid; it needs an accurate endpoint promise.', 'Compare the alternative p=(u−W)/(T−W) after warmup: it repeats M at the join and never uses m inside a ten-update budget. The program below shows both conventions. Either formula can be useful; its endpoint promise must match its actual values.');
for (const [before, after] of [
  ['would be−', 'would be −'], ['throughT−1', 'through T−1'], ['12 and.25', '12 and .25'], ['peak isη=', 'peak is η='], ['peak is−', 'peak is −'], ['ends at−', 'ends at −'],
  ['threshold0', 'threshold 0'], ['patience0', 'patience 0'], ['losses are1', 'losses are 1'], ['areM/2 andM', 'are M/2 and M'],
  ['approximately[', 'approximately ['], ['rates[', 'rates ['], ['and−', 'and −'], ['variance.', 'variance .'], ['mean−', 'mean −'], ['error is.', 'error is .'],
  ['uses.2', 'uses .2'], ['uses.05', 'uses .05'], ['threshold.1', 'threshold .1'], ['rate.4', 'rate .4'], ['factor.5', 'factor .5'], ['floor.05', 'floor .05'], ['Observe[', 'Observe ['], ['states are(', 'states are ('], ['with[', 'with ['], ['sums are.2', 'sums are .2'],
]) text = text.split(before).join(after);
text = text.replace('Include a case where no schedule wins on every seed.', 'Check whether the winner changes across seeds, and report what you observe.');
fs.writeFileSync(file, text);
const labs = 'src/learn/components/lesson-labs/LearningRateScheduleLabs.jsx';
let source = fs.readFileSync(labs, 'utf8');
source = source.replace('<div className="schedule-table-wrap"><table><caption>', '<div className="schedule-table-wrap" tabIndex={0} role="region" aria-label="Consumed schedule indices and rates, horizontally scrollable"><table><caption>');
fs.writeFileSync(labs, source);
