const fs = require('node:fs');
const assert = require('node:assert/strict');
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(ledgerPath));
const topic = ledger.topics.find(row => row.id === 'topology-topological-data-analysis-tda');
assert.equal(topic.status, 'pending');
Object.assign(topic, {
  status: 'in-progress',
  designRecord: 'docs/teaching/TOPOLOGY-TDA-LESSON-DESIGN.md',
});
fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2) + '\n');
const designPath = 'docs/teaching/TOPOLOGY-TDA-LESSON-DESIGN.md';
let design = fs.readFileSync(designPath, 'utf8');
design = design.replace('Canonical Category Theory note, to be saved during this design.', '[Category Theory note](topic-notes/category-theory-emerging-use-in-ml.md), open.');
design = design.replace(/``(?=\d)/g, 'sections ').replace(/`(?=\d(?:\.|\s|\s*and))/g, 'section ');
fs.writeFileSync(designPath, design);
