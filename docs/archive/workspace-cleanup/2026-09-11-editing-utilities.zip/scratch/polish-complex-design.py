from pathlib import Path
path = Path('docs/teaching/COMPLEX-FOURIER-LAPLACE-LESSON-DESIGN.md')
text = path.read_text(encoding='utf-8')
pairs = '''product4|product 4
of1 |of 1 
stepπ|step π
to1.|to 1.
section3|section 3
section4|section 4
section5|section 5
section6|section 6
section7|section 7
section8|section 8
section9|section 9
section10|section 10
T=1s|T=1 s
or3|or 3
at320px|at 320 px
bin1|bin 1
ending1|ending 1
twiddle±i|twiddle ±i
outputindices|output indices
13Hz/phaseπ/3 and3Hz/phase−π/3 at16Hz|13 Hz with phase π/3 and 3 Hz with phase −π/3 at 16 Hz
representative−3Hz|representative −3 Hz
frequency,phase|frequency, phase
at64Hz|at 64 Hz
off-bin5.5Hz|off-bin 5.5 Hz
at1/T|at 1/T
output0|output 0
output4|output 4
modularsum|modular sum
defaulttwo-tone|default two-tone
componentphase|component phase
selectedtime|selected time
alreadyderived|already derived
x=e^(−at),a=1|x=e^(−at), a=1
half-planeROC|half-plane ROC
comparisoninside/on/outsideboundary|comparison inside, on and outside the boundary
a,σ,ω|a, σ, ω
finitehorizon|finite horizon
finitepoint|finite point
ROCwidth|ROC width
an800px|an 800 px
explicitDFT|explicit DFT
finiteLaplace|finite Laplace
exactfour-point|exact four-point
symbolicfirst-order|symbolic first-order
filterconvolution|filter convolution
and81|and 81
weightedLaplace|weighted Laplace
gridspacing|grid spacing
paddinglength|padding length
first-orderfilter|first-order filter
convolutionintegral|convolution integral
rationalLaplace|rational Laplace
theirROCs|their ROCs
imaginaryaxis|imaginary axis
nonzeroinitial|nonzero initial
initialvalue|initial value
filtercapstone|filter capstone
reconstructionerror|reconstruction error
displayedFFT|displayed FFT
September2026|September 2026
authorledger|author ledger
Topic4,|Topic 4,
atzero|at zero
principalroot|principal root
MIT6.003|MIT 6.003
localHz|local Hz
slideformat|slide format
Jirí Lebl|Jiří Lebl
Section4.3.2|Section 4.3.2
atcorners|at corners
continuitypoints|continuity points
DLMF6.16|DLMF 6.16
asymptoticconstant|asymptotic constant
exactformula|exact formula
duringimplementation|during implementation
numericalvalue|numerical value
alreadyvalidated|already validated
andinverse|and inverse
angularfrequency|angular frequency
inplaces|in places
ordinaryintegral|ordinary integral
consistent2πfactors|consistent 2π factors
Strictsampling|Strict sampling
idealinfinite|ideal infinite
signedfrequency|signed frequency
andnormalization|and normalization
Currentweb|Current web
identifies2.5|identifies 2.5
localNumPy|local NumPy
is2.3.5|is 2.3.5
Verifyactual|Verify actual
usedAPIs|used APIs
squaredmagnitudes|squared magnitudes
physicallynormalized|physically normalized
selectedcode|selected code
Usefulintermediate|Useful intermediate
legacyMatlab|legacy Matlab
theperiodic|the periodic
plannedhere|planned here
speedclaims|speed claims
leftsupport|left support
ROCexamples|ROC examples
Thatcourse|That course
bilateraltransforms|bilateral transforms
initialordinary|initial ordinary
MIT18.03|MIT 18.03
generalizedinitial|generalized initial
workedIVP|worked IVP
Pre-jump0−|Pre-jump 0−
ordinarypost-jump0+|ordinary post-jump 0+
Initialterms|Initial terms
carryessential|carry essential
finite-durationnormalization|finite-duration normalization
Helpfulafter|Helpful after
complexrotation|complex rotation
signedcurve|signed curve
literaluniformwiremass|literal uniform wire mass
Linkthe|Link the
originalvideo|original video
fullvideo|full video
notviewed|not viewed
Officialvideoidentity|Official video identity
androots|and roots
Suitableearly|Suitable early
workedalternative|worked alternative
unverifiedtimestamp|unverified timestamp
fullwatchclaim|full-watch claim
individualblueprint|individual blueprint
figuresfile|figures file
Mathdirectly|Math directly
integratedintro|integrated intro
bymeaning|by meaning
implementationbatch|implementation batch
sharedindex|shared index
Native/modelchecks|Native/model checks
complexgeometry|complex geometry
branchboundaries|branch boundaries
coefficientintegrals|coefficient integrals
exactroot-of-unity|exact root-of-unity
directDFT|direct DFT
versusNumPy|versus NumPy
includingodd|including odd
finiteFFT|finite FFT
butterflyintermediate|butterfly intermediate
aliasphase|alias phase
andNyquist|and Nyquist
off-binclosed|off-bin closed
withnear-removablehighprecision|with high precision near removable limits
actualwindowweights|actual window weights
andmodularconvolution|and modular convolution
time-domainfilterresponse|time-domain filter response
andinitialconditions|and initial conditions
unilateralderivative|unilateral derivative
sidedLaplaceROCs|sided Laplace ROCs
finiteweighted|finite weighted
includingnearzeroexponents|including near-zero exponents
andimpulsiveconditions|and impulsive conditions
andallchangedpractice|and all changed practice
andout-of-contract|and out-of-contract
andunrepresentable|and unrepresentable
Donotfix|Do not fix
invalidnumerics|invalid numerics
silentlychanging|silently changing
mathematicaldata|mathematical data
Proposedmodelbounds|Proposed model bounds
DFTN4/8,windowN32/64/128|DFT N=4/8, window N=32/64/128
andpadding≤512|and padding ≤512
exactbounds|exact bounds
afterimplementation|after implementation
andtested|and tested
actualprograms|actual programs
extractedfromfinaldata|extracted from final data
nottranscribedstand-ins|not transcribed stand-ins
finalsourcehashes|final source hashes
independentreview|independent review
findsrepairs|finds repairs
Browserauthorreview|Browser author review
realintendedfonts|real intended fonts
at1440/390/320|at 1440/390/320
actualcontrols|actual controls
andkeyboard|and keyboard
invaliddraftpreservation|invalid draft preservation
allquestions|all questions
independentnumericgeometry|independent numeric geometry
finiteSVG/textbounds|finite SVG/text bounds
validanchors|valid anchors
andzero|and zero
unexpectederrors|unexpected errors
failedrequests|failed requests
actualscreenshots|actual screenshots
ofboth|of both
ordinaryreading|ordinary reading
andmechanismstates|and mechanism states
passingbounds|passing bounds
Allcompiled|All compiled
andproductionloading|and production loading
checksremain|checks remain
duringwriting|during writing
concreteomissions|concrete omissions
thecorrectdestination|the correct destination
thisdesign|this design
onlyafteractualbody|only after actual body
evidenceexists|evidence exists
nextstep|next step
parentassessment|parent assessment
fullauthoring|full authoring
emptylesson|empty lesson
successfuldesigncheck|successful design check
aspublishedcontent|as published content'''
for row in pairs.splitlines():
    old, new = row.split('|')
    text = text.replace(old, new)
path.write_text(text, encoding='utf-8')
