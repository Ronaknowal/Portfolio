const fs = require('fs');
const parser = require('@babel/parser');
const generate = require('@babel/generator').default;
const assert = require('node:assert/strict');
const files = ['src/learn/data/weighted-graph-models.js','src/learn/components/lesson-labs/WeightedGraphLabs.jsx','scripts/verify-weighted-graph-models.mjs'];
function clean(value) {
  if (Array.isArray(value)) return value.map(clean);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value).filter(([key]) => !['start','end','loc','extra','leadingComments','trailingComments','innerComments'].includes(key)).map(([key, item]) => [key, clean(item)]));
}
for(const file of files) {
  const source=fs.readFileSync(file,'utf8');
  const before=parser.parse(source,{sourceType:'module',plugins:['jsx']});
  const formatted=generate(before,{comments:true,compact:false,retainLines:false,jsescOption:{minimal:true}},source).code+'\n';
  const after=parser.parse(formatted,{sourceType:'module',plugins:['jsx']});
  assert.deepEqual(clean(after),clean(before),file);
  fs.writeFileSync(file,formatted);
  console.log(file+' normalized AST unchanged');
}
