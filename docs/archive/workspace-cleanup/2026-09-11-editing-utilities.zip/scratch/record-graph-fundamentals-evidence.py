import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parents[1]
production = [
    "src/learn/data/topics/graph-fundamentals-adjacency-laplacian-connectivity.jsx",
    "src/learn/data/graph-fundamentals-models.js",
    "src/learn/data/graph-fundamentals-examples.js",
    "src/learn/components/lesson-labs/GraphFundamentalsLabs.jsx",
    "src/learn/components/lesson-labs/graph-fundamentals-labs.css",
    "src/learn/data/curriculum/blueprints/graph-fundamentals-adjacency-laplacian-connectivity.js",
]
verification = [
    "scripts/prepare-graph-fundamentals-examples.py",
    "scripts/verify-graph-fundamentals.py",
    "scripts/format-graph-fundamentals.cjs",
    "scripts/review-graph-fundamentals.cjs",
    "scripts/review-graph-fundamentals-reading.cjs",
    "docs/teaching/GRAPH-FUNDAMENTALS-LESSON-DESIGN.md",
    "docs/teaching/evidence/graph-fundamentals-original-content.json",
]
opened = [
    "graph-edge-energy-initial-1440.png",
    "foundation-matrix-390.png", "directed-components-390.png",
    "incidence-flow-390.png", "availability-390.png",
    "graph-matrix-walks-initial-1440.png",
    "graph-normalization-initial-320.png", "loop-and-isolate-320.png",
    "graph-averaging-initial-1440.png", "growing-discrete-mode-320.png",
    "connected-interpolation-320.png",
    "ordinary-section-4-390.png", "ordinary-section-6-320.png",
    "ordinary-section-8-390.png", "ordinary-section-9-390.png",
    "changed-harmonic-solution-320.png", "sources-390.png",
    "question-before-first-program-390.png", "question-before-first-program-320.png",
]

def digest(relative):
    return hashlib.sha256((root / relative).read_bytes()).hexdigest()

def read(relative):
    return json.loads((root / relative).read_text(encoding="utf-8"))

record = {
    "topicId": "graph-fundamentals-adjacency-laplacian-connectivity",
    "authorFrozenAt": datetime.now(timezone.utc).isoformat(),
    "status": "author-verified; independent review and root production integration separate",
    "productionHashes": {name: digest(name) for name in production},
    "verificationSourceHashes": {name: digest(name) for name in verification},
    "native": read("scratch/graph-fundamentals-native/results.json"),
    "browser": read("scratch/graph-fundamentals-browser/results.json"),
    "firstProgramReading": read("scratch/graph-fundamentals-browser/reading-results.json"),
    "formatting": read("scratch/graph-fundamentals-verification/formatting-results.json"),
    "openedFinalImages": {
        "scratch/graph-fundamentals-browser/" + name:
            digest("scratch/graph-fundamentals-browser/" + name)
        for name in opened
    },
    "limits": [
        "Finite tests complement proofs, not exhaustive verification.",
        "Video metadata and official course summary inspected; full video playback not performed.",
        "Computed toy graph trajectories are not measured physical or performance data.",
        "Browser review covers this lesson; production loading/build belongs to root integration.",
        "User acceptance is pending.",
    ],
}
assert record["native"]["sourceHashes"] == {
    name: record["productionHashes"][name]
    for name in ["src/learn/data/graph-fundamentals-models.js", "src/learn/data/graph-fundamentals-examples.js"]
}
destination = root / "docs/teaching/evidence/graph-fundamentals-author-review.json"
destination.write_text(json.dumps(record, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps({key: record[key] for key in ["authorFrozenAt", "productionHashes"]}, indent=2))
