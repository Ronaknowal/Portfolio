import re
from pathlib import Path

path = Path("src/learn/data/topics/topology-topological-data-analysis-tda.jsx")
source = path.read_text(encoding="utf-8")
equations = [
    r"""\begin{aligned}
D(\sigma)&=\max_{x,y\in\sigma}d(x,y),\\
\sigma\in\operatorname{Rips}_{\varepsilon}(P)
&\Longleftrightarrow D(\sigma)\le\varepsilon.
\end{aligned}""",
    r"""\begin{aligned}
\partial\{0,1,2\}&=\{0,1\}\\
&\quad+\{0,2\}+\{1,2\},\\[4pt]
\partial^2\{0,1,2\}&=(\{0\}+\{1\})\\
&\quad+(\{0\}+\{2\})\\
&\quad+(\{1\}+\{2\})=0.
\end{aligned}""",
    r"""\begin{aligned}
Z_k&=\ker\partial_k,\\
B_k&=\operatorname{im}\partial_{k+1},\\
H_k&=Z_k/B_k.
\end{aligned}""",
    r"""\begin{aligned}
r_k&=\operatorname{rank}_{\mathbb F_2}\partial_k,\\
\beta_k&=n_k-r_k-r_{k+1}.
\end{aligned}""",
    r"""d_B(D,E)=\min_M\max_i c_i(M).""",
    r"""\begin{aligned}
K_t^f&\subseteq K_{t+\eta}^g\subseteq K_{t+2\eta}^f,\\
K_t^g&\subseteq K_{t+\eta}^f\subseteq K_{t+2\eta}^g.
\end{aligned}""",
    r"""\begin{gathered}
\begin{bmatrix}s(t)\\s(t-\tau)\end{bmatrix}
=A\begin{bmatrix}\cos t\\\sin t\end{bmatrix},\\[4pt]
A=\begin{bmatrix}1&0\\\cos\tau&\sin\tau\end{bmatrix},\\
\det A=\sin\tau.
\end{gathered}""",
    r"""\begin{aligned}
m(t)&=\min(t-b,d-t),\\
h_{b,d}(t)&=\max(0,m(t)).
\end{aligned}""",
    r"""\begin{aligned}
u_j&=(x_j-b)/\sigma,\\
v_j&=(y_j-p)/\sigma,\qquad j=0,1,\\
P_x&=\Phi(u_1)-\Phi(u_0),\\
P_y&=\Phi(v_1)-\Phi(v_0),\\
I&=w(p)\,P_xP_y.
\end{aligned}""",
]
pattern = r"<MathBlock>\{String\.raw`[\s\S]*?`\}</MathBlock>"
assert len(re.findall(pattern, source)) == len(equations)
iterator = iter(equations)
source = re.sub(pattern, lambda _: "<MathBlock>{String.raw`\n" + next(iterator) + "\n`}</MathBlock>", source)
source = source.replace("The <strong>bottleneck distance</strong> minimizes the largest cost over such matchings.", "Here M ranges over partial matchings, and cᵢ(M) lists every matched-point and unmatched-to-diagonal cost described above. An empty list has maximum zero. The <strong>bottleneck distance</strong> minimizes that largest cost over such matchings.")
source = source.replace("The product follows because the Gaussian uses independent coordinate directions:", "The product follows because the Gaussian uses independent coordinate directions. Let uⱼ and vⱼ be the standardized pixel endpoints, Pₓ and Pᵧ the two interval probabilities, and I this bar's weighted pixel contribution:")
path.write_text(source, encoding="utf-8")
print("Reflowed all nine mathematical displays without removing the computation.")
