import base64
import hashlib
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parents[1]
source_path = root / 'src/learn/data/topics/random-matrix-theory.jsx'
raw = source_path.read_bytes()
source = raw.decode('utf-8')
program = re.search(r'<CodeBlock language="python">\{`(.*?)`\}</CodeBlock>', source, re.S).group(1)
expected = re.search(r'<CodeBlock language="output">\{`(.*?)`\}</CodeBlock>', source, re.S).group(1)
result = subprocess.run([sys.executable, '-X', 'utf8', '-I', '-c', program], check=True, capture_output=True, text=True, encoding='utf-8')
assert result.stdout.rstrip() == expected.strip()
record = {
    'capturedAt': datetime.now(timezone.utc).isoformat(),
    'stableId': 'random-matrix-theory',
    'sourcePath': str(source_path.relative_to(root)).replace('\\', '/'),
    'sourceSha256': hashlib.sha256(raw).hexdigest(),
    'sourceBytesBase64': base64.b64encode(raw).decode('ascii'),
    'source': source,
    'program': program,
    'output': expected,
    'originalProgramExecuted': True,
    'actualStdout': result.stdout,
    'preservationContract': 'Retain this complete original edge calculation and output in the rewrite; retain useful topic scope with explicitly corrected assumptions. This archive does not endorse all original claims.',
}
destination = root / 'docs/teaching/evidence/random-matrix-original-content.json'
if destination.exists():
    previous = json.loads(destination.read_text(encoding='utf-8'))
    assert previous['sourceSha256'] == record['sourceSha256']
else:
    destination.write_text(json.dumps(record, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({key: record[key] for key in ['capturedAt', 'sourceSha256', 'originalProgramExecuted', 'actualStdout']}, indent=2))
