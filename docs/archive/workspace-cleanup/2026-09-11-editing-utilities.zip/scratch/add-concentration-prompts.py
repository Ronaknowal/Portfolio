from pathlib import Path
import html
import re

root=Path(__file__).resolve().parents[1]
file=root/'src/learn/data/topics/concentration-inequalities-hoeffding-bernstein-chernoff.jsx'
text=file.read_text(encoding='utf-8')
questions={
 'exponentialWitness':'Does summing the exponential contributions over every count agree with the factored MGF? Compare several weights, then locate the best bound while the event remains fixed.',
 'hoeffdingBudget':'How do the same tolerance and failure budget produce both a tail guarantee for a fixed sample count and a sufficient count for a planned experiment? Identify why rounding must be upward.',
 'unequalRanges':'When three observations have different supports, which expectation and squared-width sum control their centered sum? Enumerate the outcomes, then repeat the calculation with fixed weights.',
 'varianceRadii':'For the same data count and failure budget, how much changes when a valid variance bound is available? Keep the interval width and variance information separate.',
 'bernsteinInversion':'Does the quadratic radius actually solve the target tail equation? Then compute both the probability and the size of the error on an all-zero sample to test the unjustified plug-in procedure.',
 'rareCount':'How does a change from an expected count of 20 to a threshold of 30 determine the relative increase? Evaluate the unsimplified guarantee without confusing it with the exact tail.',
 'exactBinomial':'For one fixed inclusive event, how different are the exact probability and four valid guarantees? Verify the small rational case and the impossible threshold as well as the rare-count scenario.',
 'samplingLaws':'Do identical marginal means produce identical error events under three sampling designs? Compare the exact distributions at a partial sample and at the full population size.',
 'simultaneousBudget':'How do per-check and global budgets differ numerically? Calculate family failures, verify a telescoping allocation over time, and solve the changed sample-size tasks.',
}
for name,question in questions.items():
 before=f'<RunnableExample example={{concentrationInequalityExamples.{name}}} />'
 after=f'<ConcentrationExample example={{concentrationInequalityExamples.{name}}} question="{html.escape(question,quote=True)}" />'
 assert text.count(before)==1,name
 text=text.replace(before,after)
hints=[
 'Solve the two-sided Hoeffding expression once for its radius and once for n. Separate failure of the independence assumption from a mismatch between the sampled and claimed populations.',
 'Count outcomes with six, seven and eight heads. For each inequality, write its random variable, expectation or variance, and the deviation from the mean before substituting.',
 'Square each support width and add. A fixed coefficient scales its interval width by the coefficient’s absolute value, even when the coefficient is negative.',
 'Set L=log(2/δ), form the positive root, and substitute it back into the exponent. For the plug-in question, distinguish a sample statistic from a population guarantee.',
 'Relative tolerance r corresponds to absolute tolerance rp. Keep p in the count-sensitive formula, and ask what information makes that unknown quantity usable for planning.',
 'Use variance of a sum, including covariance, or the exact finite law for each design. The uniform-subset correction depends on the fraction of the fixed population observed.',
 'Budget the probability of any predictor failing, rather than requiring predictor failures to be independent. Repeated times add an additional index to that family.',
 'Write three separate targets and sampling designs. Ask which information was fixed before evaluation, and whether a finite family or an all-time procedure is being protected.',
]
start=text.index('<H2>8. Practise changing the contract</H2>')
prefix,practice=text[:start],text[start:]
assert practice.count('<Checkpoint ')==8
for hint in hints:
 practice=practice.replace('<Checkpoint ',f'<ConcentrationExercise hint="{html.escape(hint,quote=True)}" ',1)
practice=practice.replace('</Checkpoint>','</ConcentrationExercise>')
file.write_text(prefix+practice,encoding='utf-8')
