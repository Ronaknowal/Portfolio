const fs = require('node:fs');
const file = 'src/learn/components/lesson-labs/GradientVariantsLabs.jsx';
let source = fs.readFileSync(file, 'utf8');
const replacements = [
  ['fill="currentColor"', 'fill="context-stroke"'],
  ['lower={-Number(extent.toPrecision(2))} upper={Number(extent.toPrecision(2))}', 'lower={-Number((extent * 264 / 180).toPrecision(2))} upper={Number((extent * 264 / 180).toPrecision(2))}'],
  ['rx={Math.sqrt(2 * level) / (2 * extent) * 264}', 'rx={Math.sqrt(2 * level) / (2 * extent) * 180}'],
  ['</marker></defs><ShortAxis xLabel="parameter x"', '</marker><clipPath id={`${arrowId}-clip`}><rect x="44" y="32" width="264" height="182" /></clipPath></defs><ShortAxis xLabel="parameter x"'],
  ['{[0.5, 2, 8, 20].map', '<g clipPath={`url(#${arrowId}-clip)`}>{[0.5, 2, 8, 20].map'],
  ['className="optimizer-contour" />)}', 'className="optimizer-contour" />)}</g>'],
  ['Same scale within this block; read numbers across blocks.', 'Linear norm scale within this block.'],
];
for (const [oldText, newText] of replacements) {
  if (!source.includes(oldText)) throw new Error(`Missing target: ${oldText}`);
  source = source.replace(oldText, newText);
}
fs.writeFileSync(file, source);
