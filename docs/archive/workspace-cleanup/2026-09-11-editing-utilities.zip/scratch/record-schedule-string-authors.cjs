const fs = require('node:fs');
const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const id = 'learning-rate-schedules-cosine-warmup-onecyclelr';
const files = [`src/learn/data/topics/${id}.jsx`, 'src/learn/data/learning-rate-schedule-models.js', 'src/learn/data/learning-rate-schedule-examples.js', 'src/learn/components/lesson-labs/LearningRateScheduleLabs.jsx', 'src/learn/components/lesson-labs/learning-rate-schedule-labs.css', `src/learn/data/curriculum/blueprints/${id}.js`];
const hash = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const read = file => JSON.parse(fs.readFileSync(file));
const sources = Object.fromEntries(files.map(file => [file, hash(file)]));
fs.writeFileSync('docs/teaching/evidence/learning-rate-schedule-author-review.json', JSON.stringify({ recordedAt: new Date().toISOString(), sources,
  native: read('scratch/learning-rate-schedule-review/verification-results.json'), practice: read('scratch/learning-rate-schedule-review/practice-results.json'),
  browser: read('scratch/learning-rate-schedule-browser/results.json'), reading: read('scratch/learning-rate-schedule-browser/reading-results.json'),
  independentRecord: 'docs/teaching/LEARNING-RATE-SCHEDULES-INDEPENDENT-REVIEW.md' }, null, 2) + '\n');
const ledgerFile = 'docs/teaching/dsa-math-foundations-progress.json';
const progress = read(ledgerFile);
const manifest = read('src/learn/data/lesson-manifest.json');
for (const [topicId, design, verification, evidence] of [
  [id, 'LEARNING-RATE-SCHEDULES-DESIGN.md', 'LEARNING-RATE-SCHEDULES-VERIFICATION.md', 'docs/teaching/evidence/learning-rate-schedule-author-review.json'],
  ['string-matching-prefix-functions-rolling-hashes', 'STRING-MATCHING-LESSON-DESIGN.md', 'STRING-MATCHING-VERIFICATION.md', 'docs/teaching/evidence/string-matching-author-review.json'],
]) {
  const entry = progress.topics.find(topic => topic.id === topicId);
  assert.equal(entry.status, 'in-progress');
  const reviewedFiles = read(evidence).sources;
  for (const [file, digest] of Object.entries(reviewedFiles)) assert.equal(hash(file), digest, file);
  Object.assign(entry, { status: 'author-verified', source: manifest[topicId], designRecord: `docs/teaching/${design}`, verificationRecord: `docs/teaching/${verification}`, reviewedFiles, reviewedSourceSha256: reviewedFiles[`src/learn/data/${manifest[topicId].slice(2)}`] });
}
const randomized = progress.topics.find(topic => topic.id === 'randomized-algorithms-sampling-error-guarantees');
assert.equal(randomized.status, 'pending');
randomized.status = 'in-progress';
fs.writeFileSync(ledgerFile, JSON.stringify(progress, null, 2) + '\n');
