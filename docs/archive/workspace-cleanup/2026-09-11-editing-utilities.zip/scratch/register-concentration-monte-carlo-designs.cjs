const fs = require('node:fs');
const plans = [
  ['concentration-inequalities-hoeffding-bernstein-chernoff', 'Concentration Inequalities (Hoeffding, Bernstein, Chernoff)', 'concentrationInequalitiesBlueprint', 'CONCENTRATION-INEQUALITIES-LESSON-DESIGN.md'],
  ['monte-carlo-methods-mcmc-metropolis-hastings-hmc-nuts', 'Monte Carlo Methods & MCMC (Metropolis-Hastings, HMC, NUTS)', 'monteCarloMcmcBlueprint', 'MONTE-CARLO-MCMC-LESSON-DESIGN.md'],
];
const indexPath = 'src/learn/data/curriculum/blueprints/index.js';
let index = fs.readFileSync(indexPath, 'utf8');
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(ledgerPath));
for (const [id, title, binding, design] of plans) {
  if (!index.includes(binding)) index = `import ${binding} from './${id}.js';\n` + index.replace(/};\s*$/, `  ${JSON.stringify(title)}: ${binding},\n};\n`);
  const topic = ledger.topics.find(entry => entry.id === id);
  topic.status = 'in-progress';
  topic.designRecord = `docs/teaching/${design}`;
}
fs.writeFileSync(indexPath, index);
fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2) + '\n');
console.log('Concentration19 and Monte Carlo20 design briefs registered; old bodies still require their scoped rewrite review.');
