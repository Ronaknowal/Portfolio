const fs = require('node:fs');
const crypto = require('node:crypto');
const hash = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const secondId = 'second-order-methods-l-bfgs-k-fac-shampoo-natural-gradient';
const secondFiles = [`src/learn/data/topics/${secondId}.jsx`, 'src/learn/data/second-order-methods-models.js', 'src/learn/data/second-order-methods-examples.js', 'src/learn/components/lesson-labs/SecondOrderMethodsLabs.jsx', 'src/learn/components/lesson-labs/second-order-methods-labs.css', `src/learn/data/curriculum/blueprints/${secondId}.js`];
const secondHashes = Object.fromEntries(secondFiles.map(file => [file, hash(file)]));
fs.writeFileSync('docs/teaching/evidence/second-order-methods-author-review.json', JSON.stringify({ frozenAt: new Date().toISOString(), files: secondHashes, verificationRecord: 'docs/teaching/SECOND-ORDER-METHODS-VERIFICATION.md', status: 'author-verified' }, null, 2) + '\n');
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(ledgerPath));
for (const [id, hashes, design, verification] of [
  [secondId, secondHashes, 'SECOND-ORDER-METHODS-DESIGN.md', 'SECOND-ORDER-METHODS-VERIFICATION.md'],
  ['network-flow-minimum-cuts-bipartite-matching', JSON.parse(fs.readFileSync('scratch/network-flow-lesson-review/final-source-hashes.json')), 'NETWORK-FLOW-LESSON-DESIGN.md', 'NETWORK-FLOW-VERIFICATION.md'],
  ['non-convex-optimization-landscape', JSON.parse(fs.readFileSync('scratch/nonconvex-landscape-verification/final-source-hashes.json')).files, 'NONCONVEX-LANDSCAPE-DESIGN.md', 'NONCONVEX-LANDSCAPE-VERIFICATION.md'],
]) {
  for (const [file, expected] of Object.entries(hashes)) if (hash(file) !== expected) throw new Error(`Source changed: ${file}`);
  const topic = ledger.topics.find(entry => entry.id === id);
  Object.assign(topic, { status: 'author-verified', designRecord: `docs/teaching/${design}`, verificationRecord: `docs/teaching/${verification}`, reviewedFiles: hashes, reviewedSourceSha256: hashes[`src/learn/data/topics/${id}.jsx`] });
}
const geometryId = 'computational-geometry-robust-predicates-convex-hulls';
const geometry = ledger.topics.find(topic => topic.id === geometryId);
geometry.status = 'in-progress';
geometry.designRecord = 'docs/teaching/COMPUTATIONAL-GEOMETRY-DESIGN.md';
const manifestPath = 'src/learn/data/lesson-manifest.json';
const manifest = JSON.parse(fs.readFileSync(manifestPath));
manifest[geometryId] = `./topics/${geometryId}.jsx`;
fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + '\n');
const indexPath = 'src/learn/data/curriculum/blueprints/index.js';
let index = fs.readFileSync(indexPath, 'utf8');
if (!index.includes('computationalGeometryBlueprint')) index = `import computationalGeometryBlueprint from './${geometryId}.js';\n` + index.replace(/};\s*$/, `  "Computational Geometry, Robust Predicates & Convex Hulls": computationalGeometryBlueprint,\n};\n`);
fs.writeFileSync(indexPath, index);
for (const id of ['persistent-data-structures-structural-sharing-versioned-queries', 'constrained-multi-objective-optimization']) ledger.topics.find(topic => topic.id === id).status = 'in-progress';
fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2) + '\n');
const scriptPath = 'scripts/verify-learning-load-boundaries.cjs';
let script = fs.readFileSync(scriptPath, 'utf8');
if (!script.includes("'non-convex-optimization-landscape'")) script = script.replace('const mathematicsLessons = [', "const mathematicsLessons = ['non-convex-optimization-landscape', ");
fs.writeFileSync(scriptPath, script);
console.log('Recorded three frozen author reviews; registered complete Geometry draft; added Nonconvex production isolation case.');
