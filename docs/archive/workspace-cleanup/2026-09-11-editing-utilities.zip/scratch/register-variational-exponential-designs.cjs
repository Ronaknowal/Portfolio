const fs = require('node:fs');
const assert = require('node:assert/strict');
const plans = [
  ['variational-inference', 'Variational Inference', 'variationalInferenceBlueprint', 'VARIATIONAL-INFERENCE-LESSON-DESIGN.md'],
  ['exponential-families-sufficient-statistics', 'Exponential Families & Sufficient Statistics', 'exponentialFamiliesBlueprint', 'EXPONENTIAL-FAMILIES-LESSON-DESIGN.md'],
];
const indexPath = 'src/learn/data/curriculum/blueprints/index.js';
let index = fs.readFileSync(indexPath, 'utf8');
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(ledgerPath));
for (const [id, title, binding, design] of plans) {
  assert.ok(!index.includes(binding));
  index = "import " + binding + " from './" + id + ".js';\n" + index.replace(/};\s*$/, '  ' + JSON.stringify(title) + ': ' + binding + ',\n};\n');
  const topic = ledger.topics.find(entry => entry.id === id);
  assert.ok(topic);
  topic.status = 'in-progress';
  topic.designRecord = 'docs/teaching/' + design;
}
fs.writeFileSync(indexPath, index);
fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2) + '\n');
console.log('Variational21 and Exponential22 briefs registered; implementation remains in progress.');
