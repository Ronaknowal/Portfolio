import datetime
import hashlib
import json
from pathlib import Path

root = Path.cwd()
path = root/'docs/teaching/evidence/functional-analysis-author-review.json'
record = json.loads(path.read_text(encoding='utf8'))
def fingerprint(name):
    raw = (root/name).read_bytes()
    return {'path': name, 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
prior = {'authorFrozenAt': record['authorFrozenAt'], 'production': record['production'], 'support': record['support'], 'focusedReading': record['evidence']['focusedReading']}
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
record['production'] = [fingerprint(item['path']) for item in record['production']]
record['support'] = [fingerprint(item['path']) for item in record['support']]
reading = 'scratch/functional-analysis-browser/reading-results.json'
record['evidence']['focusedReading'] = {'file': fingerprint(reading), 'result': json.loads((root/reading).read_text())}
record['postFreezeAmendments'] = [{
    'at': now,
    'reason': 'Add checkable actual changed-noise and linear-target results to practice H after independent pedagogical review.',
    'priorFreeze': prior,
    'changedProduction': ['src/learn/data/topics/functional-analysis-rkhs.jsx'],
    'nativeAttribution': 'Independent reviewer executed actual changed programs; author read full actual outputs and code hashes, not independently rerun here.',
    'nativeEvidence': json.loads((root/'scratch/functional-analysis-independent-review/results.json').read_text()),
    'browserEvidence': record['evidence']['focusedReading'],
}]
record['authorFrozenAt'] = now
record['openedScreenshots'] += [fingerprint(f'scratch/functional-analysis-browser/changed-capstone-solution-{width}.png') for width in [1440,390,320]]
record['reviewNotes'][0] = 'Thirty-seven listed captures were actually opened; generated-only images are not counted.'
path.write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
print(json.dumps({'authorFrozenAt':now,'body':record['production'][0],'opened':len(record['openedScreenshots'])}))
