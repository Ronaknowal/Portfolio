const fs = require('node:fs');
const { parse } = require('@babel/parser');
const filename = 'src/learn/data/lesson-manifest.json';
const manifest = JSON.parse(fs.readFileSync(filename));
const id = 'string-matching-prefix-functions-rolling-hashes';
if (manifest[id]) throw new Error('Already registered; inspect current state.');
parse(fs.readFileSync(`src/learn/data/topics/${id}.jsx`, 'utf8'), { sourceType: 'module', plugins: ['jsx'] });
manifest[id] = `./topics/${id}.jsx`;
fs.writeFileSync(filename, JSON.stringify(manifest, null, 2) + '\n');
