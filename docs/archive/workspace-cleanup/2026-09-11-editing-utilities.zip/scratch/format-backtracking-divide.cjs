const fs = require('node:fs');
const assert = require('node:assert/strict');
const { parse } = require('@babel/parser');
const generate = require('@babel/generator').default;
const files = [
  'src/learn/data/backtracking-divide-models.js',
  'src/learn/components/lesson-labs/BacktrackingDivideLabs.jsx',
  'src/learn/data/practice/backtracking-divide-and-conquer.js',
  'src/learn/data/curriculum/blueprints/backtracking-divide-and-conquer.js',
  'scripts/verify-backtracking-divide-models.mjs',
];
function normalize(value) {
  if (Array.isArray(value)) return value.map(normalize);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value).filter(([key]) => !['start', 'end', 'loc', 'extra', 'errors'].includes(key)).map(([key, child]) => [key, normalize(child)]));
}
fs.mkdirSync('scratch/backtracking-divide-format-baseline', { recursive: true });
for (const file of files) {
  const before = fs.readFileSync(file, 'utf8');
  const ast = parse(before, { sourceType: 'module', plugins: ['jsx'] });
  const after = generate(ast, { comments: true, compact: false, jsescOption: { minimal: true } }, before).code + '\n';
  assert.deepEqual(normalize(parse(after, { sourceType: 'module', plugins: ['jsx'] })), normalize(ast));
  fs.writeFileSync('scratch/backtracking-divide-format-baseline/' + file.replaceAll('/', '__'), before);
  fs.writeFileSync(file, after);
}
console.log('Five owned sources formatted; normalized AST, comments and strings unchanged.');
