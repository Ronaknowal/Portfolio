const fs = require('node:fs');
const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const hash = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const path = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(path));
const entityEvidence = JSON.parse(fs.readFileSync('scratch/lesson-comparison-entities/source-results.json'));
for (const item of entityEvidence.results) {
  assert.equal(item.normalizedAstEqual, true);
  assert.equal(hash(item.file), item.afterSha256);
  const topic = ledger.topics.find(entry => entry.reviewedFiles?.[item.file]);
  assert.ok(topic);
  assert.equal(topic.reviewedFiles[item.file], item.beforeSha256);
  topic.reviewedFiles[item.file] = item.afterSha256;
  topic.reviewedSourceSha256 = item.afterSha256;
}
fs.writeFileSync('docs/teaching/evidence/lesson-comparison-entities.json', JSON.stringify(entityEvidence, null, 2) + '\n');
const id = 'maximum-likelihood-map-estimation';
const owned = JSON.parse(fs.readFileSync('scratch/maximum-likelihood-lesson-review/final-source-hashes.json'));
for (const [file, expected] of Object.entries(owned)) assert.equal(hash(file), expected, file);
const topic = ledger.topics.find(entry => entry.id === id);
topic.status = 'author-verified';
topic.designRecord = 'docs/teaching/MAXIMUM-LIKELIHOOD-MAP-LESSON-DESIGN.md';
topic.verificationRecord = 'docs/teaching/MAXIMUM-LIKELIHOOD-MAP-VERIFICATION.md';
topic.reviewedFiles = owned;
topic.reviewedSourceSha256 = owned[`src/learn/data/topics/${id}.jsx`];
fs.writeFileSync(path, JSON.stringify(ledger, null, 2) + '\n');
console.log('Entity-only source amendments and frozen MLE author review recorded; final production integration pending.');
