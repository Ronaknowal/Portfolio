const fs = require('node:fs');
const crypto = require('node:crypto');
const id = 'randomized-algorithms-sampling-error-guarantees';
const manifestPath = 'src/learn/data/lesson-manifest.json';
const manifest = JSON.parse(fs.readFileSync(manifestPath));
manifest[id] = `./topics/${id}.jsx`;
fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + '\n');
const indexPath = 'src/learn/data/curriculum/blueprints/index.js';
let index = fs.readFileSync(indexPath, 'utf8');
if (!index.includes('randomizedAlgorithmsBlueprint')) {
  index = `import randomizedAlgorithmsBlueprint from './${id}.js';\n` + index.replace(/};\s*$/, '  "Randomized Algorithms, Sampling & Error Guarantees": randomizedAlgorithmsBlueprint,\n};\n');
  fs.writeFileSync(indexPath, index);
}
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(ledgerPath));
const topic = ledger.topics.find(entry => entry.id === 'convex-duality-lagrangian-methods-kkt-conditions');
const snapshot = JSON.parse(fs.readFileSync('scratch/duality-kkt-verification/final-source-hashes.json'));
const hashes = Object.fromEntries(snapshot.files.map(file => [file.path, file.sha256]));
for (const [file, hash] of Object.entries(hashes)) {
  if (crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex') !== hash) throw new Error(`Frozen source changed: ${file}`);
}
topic.status = 'author-verified';
topic.verificationRecord = 'docs/teaching/CONVEX-DUALITY-KKT-VERIFICATION.md';
topic.reviewedFiles = hashes;
topic.reviewedSourceSha256 = hashes[`src/learn/data/topics/${topic.id}.jsx`];
fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2) + '\n');
console.log('Registered Randomized body/brief; KKT frozen author evidence recorded.');
