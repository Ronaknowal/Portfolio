const fs = require('node:fs');
const parser = require('@babel/parser');
let text = fs.readFileSync('scratch/decision-tree-lesson-draft.jsx', 'utf8');
const slash = String.fromCharCode(92);
const tick = String.fromCharCode(96);
const formulas = [
  'G=1-@sum_{k=1}^{K}p_k^2,@qquad G_{@mathrm{binary}}=2p(1-p).',
  'H=-@sum_k p_k@log_2p_k,@qquad 0@log_2 0:=0.',
  '@Delta=I_{@mathrm{parent}}-@left(@frac{n_L}{n}I_L+@frac{n_R}{n}I_R@right).',
  '@Delta_{@mathrm{MSE}}=@frac{@operatorname{SSE}_P-@operatorname{SSE}_L-@operatorname{SSE}_R}{n_P}.',
  '@begin{aligned}R(T)&=@sum_{@ell@in@mathrm{leaves}}@frac{n_@ell}{n_{@mathrm{root}}}I_@ell,@@R_@alpha(T)&=R(T)+@alpha L(T).@end{aligned}',
];
let index=0;
text=text.replace(/<MathBlock>[\s\S]*?<\/MathBlock>/g,()=>'<MathBlock>{String.raw'+tick+formulas[index++].replaceAll('@',slash)+tick+'}</MathBlock>');
if(index!==formulas.length) throw Error('Unexpected formula inventory');
parser.parse(text,{sourceType:'module',plugins:['jsx']});
fs.writeFileSync('scratch/decision-tree-lesson-draft.jsx',text);
fs.writeFileSync('src/learn/data/topics/decision-trees-random-forests.jsx',text);
console.log('Parsed and installed complete tree lesson with '+index+' exact TeX blocks.');
