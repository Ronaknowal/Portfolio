const fs = require('node:fs');
const parser = require('@babel/parser');
const generate = require('@babel/generator').default;
const files = [
  'src/learn/data/topics/convex-optimization.jsx',
  'src/learn/components/lesson-labs/ConvexOptimizationLabs.jsx',
  'src/learn/data/convex-optimization-models.js',
];
function cleanText(value) { return value.replace(/([a-zA-Z])(?=[0-9])/g, '$1 '); }
function walk(node) {
  if (!node || typeof node !== 'object') return;
  if (node.type === 'JSXElement' && ['Code', 'CodeBlock'].includes(node.openingElement.name.name)) return;
  if (node.type === 'JSXText') {
    node.value = cleanText(node.value);
    node.extra = {
      raw: node.value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('{', '&#123;').replaceAll('}', '&#125;'),
      rawValue: node.value,
    };
  }
  if (node.type === 'StringLiteral' && node.value.includes(' ') && !node.value.includes('http') && !node.value.includes('\\n')) {
    node.value = cleanText(node.value);
    if (node.extra) delete node.extra;
  }
  for (const [key, value] of Object.entries(node)) {
    if (key === 'loc' || key === 'extra' || key === 'tokens' || key === 'comments') continue;
    if (Array.isArray(value)) value.forEach(walk);
    else if (value && typeof value === 'object') walk(value);
  }
}
for (const file of files) {
  const ast = parser.parse(fs.readFileSync(file, 'utf8'), { sourceType: 'module', plugins: ['jsx'] });
  walk(ast);
  const result = generate(ast, { comments: true, jsescOption: { minimal: true } }).code + '\n';
  parser.parse(result, { sourceType: 'module', plugins: ['jsx'] });
  fs.writeFileSync(file, result);
}
console.log('Formatted only three owned Convex sources and spaced prose numeral boundaries.');
