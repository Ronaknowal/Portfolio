from pathlib import Path
path = Path('src/learn/components/lesson-labs/MutualInformationLabs.jsx')
text = path.read_text(encoding='utf8')
text = text.replace('return <div className="mi-table-scroll" role="region" aria-label={caption} tabIndex={0}><table><caption>{caption}</caption>', 'return <div className="mi-table"><h4 className="mi-table-caption">{caption}</h4><p className="mi-scroll-hint">Scroll sideways for all columns.</p><div className="mi-table-scroll" role="region" aria-label={caption} tabIndex={0}><table><caption className="mi-sr-only">{caption}</caption>')
old = '</td>)}</tr>)}</tbody></table></div>;'
assert text.count(old) == 1
text = text.replace(old, '</td>)}</tr>)}</tbody></table></div></div>;')
text = text.replace('const x = value => 40 + 246 * (value - minimum) / (maximum - minimum);', 'const x = value => 40 + 246 * (value - minimum) / (maximum - minimum);\n  const ticks = [minimum, ...(x(0) - x(minimum) > 50 && x(maximum) - x(0) > 50 ? [0] : []), maximum];')
text = text.replace('[minimum, 0, maximum].map((value, i)', 'ticks.map((value, i)')
text = text.replace('<div className="mi-counts" role="region"', '<h4 className="mi-table-caption">Observed counts · active seed {seed}</h4><p className="mi-scroll-hint">Scroll sideways for all columns.</p>\n    <div className="mi-counts" role="region"')
text = text.replace('<caption>Observed counts · active seed {seed}</caption>', '<caption className="mi-sr-only">Observed counts · active seed {seed}</caption>')
for old, new in [('from0 to2bits', 'from 0 to 2 bits'), ('from0 to1bit', 'from 0 to 1 bit'), ('rate${', 'rate ${'), ('relevance${', 'relevance ${'), ('}bits', '} bits'), ('upper bound${', 'upper bound ${'), ('lower bound${', 'lower bound ${'), ('from${', 'from ${'), ('} to${', '} to ${'), ('is${', 'is ${'), ('True J at beta3', 'True J at beta = 3'), ('multiplying these', 'multiplying these'), ('ln2', 'ln 2'), ('variance1', 'variance 1'), ('exactly0', 'exactly 0'), ('these20', 'these 20'), ('sigma.25 gives2.04373bits, sigma.5 gives1.16096, sigma1 gives.5, sigma2 gives.16096', 'sigma .25 gives 2.04373 bits, sigma .5 gives 1.16096, sigma 1 gives .5, sigma 2 gives .16096')]:
    text = text.replace(old, new)
path.write_text(text, encoding='utf8')
