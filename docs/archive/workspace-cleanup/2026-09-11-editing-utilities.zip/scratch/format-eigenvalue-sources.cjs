const fs = require('node:fs');
const assert = require('node:assert/strict');
const { parse } = require('@babel/parser');
const generate = require('@babel/generator').default;
const files = [
  'src/learn/data/eigenvalue-models.js',
  'src/learn/data/eigenvalue-examples.js',
  'src/learn/components/lesson-labs/EigenvalueLabs.jsx',
  'src/learn/data/topics/eigenvalues-eigenvectors.jsx',
  'src/learn/data/curriculum/blueprints/eigenvalues-eigenvectors.js',
];
function normalize(value) {
  if (Array.isArray(value)) return value.map(normalize);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value)
    .filter(([key]) => !['start', 'end', 'loc', 'extra', 'errors'].includes(key))
    .map(([key, child]) => [key, normalize(child)]));
}
fs.mkdirSync('scratch/eigenvalue-format-baseline', { recursive: true });
for (const file of files) {
  const before = fs.readFileSync(file, 'utf8');
  const ast = parse(before, { sourceType: 'module', plugins: ['jsx'] });
  const after = generate(ast, { comments: true, compact: false, jsescOption: { minimal: true } }, before).code + '\n';
  assert.deepEqual(normalize(parse(after, { sourceType: 'module', plugins: ['jsx'] })), normalize(ast));
  fs.writeFileSync('scratch/eigenvalue-format-baseline/' + file.replaceAll('/', '__'), before);
  fs.writeFileSync(file, after);
}
const cssFile = 'src/learn/components/lesson-labs/eigenvalue-labs.css';
const cssBefore = fs.readFileSync(cssFile, 'utf8');
const tokens = cssBefore.split(/([{};])/);
let indent = 0, line = '', formatted = '';
for (const token of tokens) {
  if (token === '{') { formatted += '  '.repeat(indent) + line.trim() + ' {\n'; line = ''; indent++; }
  else if (token === ';') { if (line.trim()) formatted += '  '.repeat(indent) + line.trim().replace(/^([^:]+):/, '$1: ') + ';\n'; line = ''; }
  else if (token === '}') { if (line.trim()) formatted += '  '.repeat(indent) + line.trim().replace(/^([^:]+):/, '$1: ') + ';\n'; line = ''; indent--; formatted += '  '.repeat(indent) + '}\n'; }
  else line += token;
}
const canonical = text => text.replace(/\s+/g, '').replace(/;}/g, '}');
assert.equal(canonical(formatted), canonical(cssBefore));
fs.writeFileSync('scratch/eigenvalue-format-baseline/eigenvalue-labs.css', cssBefore);
fs.writeFileSync(cssFile, formatted);
console.log('Formatted five Eigenvalue sources with identical normalized AST and CSS with identical non-whitespace tokens.');
