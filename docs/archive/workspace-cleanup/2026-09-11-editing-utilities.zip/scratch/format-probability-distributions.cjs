const fs = require('node:fs');
const assert = require('node:assert/strict');
const parser = require('@babel/parser');
const generate = require('@babel/generator').default;
const files = ['src/learn/components/lesson-labs/ProbabilityDistributionsLabs.jsx', 'src/learn/data/probability-distributions-models.js', 'src/learn/data/topics/probability-distributions-bayes-theorem.jsx'];
function normalize(value) {
  if (Array.isArray(value)) return value.map(normalize);
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).filter(([key]) => !['start', 'end', 'loc', 'extra', 'tokens'].includes(key)).map(([key, child]) => [key, normalize(child)]));
  return value;
}
for (const file of files) {
  const source = fs.readFileSync(file, 'utf8');
  const before = parser.parse(source, { sourceType: 'module', plugins: ['jsx'] });
  const output = generate(before, { comments: true, compact: false }, source).code + '\n';
  assert.deepEqual(normalize(parser.parse(output, { sourceType: 'module', plugins: ['jsx'] })), normalize(before));
  fs.writeFileSync(file, output);
}
fs.writeFileSync('scratch/probability-distributions-review/formatting-results.json', JSON.stringify({ checkedAt: new Date().toISOString(), files, normalizedAstIdentical: true, jsxAndTemplateValuesPreserved: true }, null, 2));
