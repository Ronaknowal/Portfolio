const fs = require('node:fs');
const assert = require('node:assert/strict');
const path = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(path));
for (const [id, name] of [['it-calculus-stochastic-differential-equations', 'ITO-CALCULUS-SDE'], ['functional-analysis-rkhs', 'FUNCTIONAL-ANALYSIS-RKHS']]) {
  const topic = ledger.topics.find(row => row.id === id);
  assert.equal(topic.status, 'pending');
  Object.assign(topic, { status: 'in-progress', designRecord: 'docs/teaching/' + name + '-LESSON-DESIGN.md' });
}
fs.writeFileSync(path, JSON.stringify(ledger, null, 2) + '\n');
