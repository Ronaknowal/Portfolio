const fs = require('node:fs');
const crypto = require('node:crypto');
const file = 'docs/teaching/dsa-math-foundations-progress.json';
const progress = JSON.parse(fs.readFileSync(file, 'utf8'));
const records = [
  ['greedy-algorithms-exchange-arguments', 'greedy-exchange', 'GreedyExchangeLabs', 'GREEDY-EXCHANGE-LESSON-DESIGN', 'GREEDY-EXCHANGE-VERIFICATION'],
  ['dynamic-programming-states-transitions-optimization', 'dynamic-programming', 'DynamicProgrammingLabs', 'DYNAMIC-PROGRAMMING-LESSON-DESIGN', 'DYNAMIC-PROGRAMMING-VERIFICATION'],
  ['tensor-algebra-einsum-notation', 'einsum', 'EinsumLabs', 'TENSOR-ALGEBRA-EINSUM-DESIGN', 'TENSOR-ALGEBRA-EINSUM-VERIFICATION'],
];
const hash = filename => crypto.createHash('sha256').update(fs.readFileSync(filename)).digest('hex');
for (const [id, stem, component, design, verification] of records) {
  const entry = progress.topics.find(topic => topic.id === id);
  if (entry.status !== 'in-progress') throw new Error('Refuse refreshing existing evidence: ' + id);
  const paths = [
    `src/learn/data/topics/${id}.jsx`,
    `src/learn/data/${stem}-models.js`,
    `src/learn/data/${stem}-examples.js`,
    `src/learn/components/lesson-labs/${component}.jsx`,
    `src/learn/components/lesson-labs/${stem}-labs.css`,
    `src/learn/data/curriculum/blueprints/${id}.js`,
    ...(entry.moduleId === 'data-structures-algorithms' ? [`src/learn/data/practice/${id}.js`] : []),
  ];
  for (const name of [design, verification]) if (fs.statSync(`docs/teaching/${name}.md`).size < 500) throw new Error('Missing evidence: ' + name);
  Object.assign(entry, {
    status: 'implementation-reviewed', source: `./topics/${id}.jsx`,
    designRecord: `docs/teaching/${design}.md`, verificationRecord: `docs/teaching/${verification}.md`,
    reviewedSourceSha256: hash(paths[0]), reviewedFiles: Object.fromEntries(paths.map(filename => [filename, hash(filename)])),
    integrationRecord: 'docs/teaching/DSA-MATH-FOUNDATIONS-INTEGRATION.md',
  });
}
for (const [id, design] of [
  ['segment-trees-fenwick-trees-range-queries', 'RANGE-QUERIES-LESSON-DESIGN'],
  ['algorithm-correctness-loop-invariants-termination', 'ALGORITHM-CORRECTNESS-LESSON-DESIGN'],
  ['multivariate-calculus-gradients', 'MULTIVARIATE-CALCULUS-GRADIENTS-DESIGN'],
]) {
  const entry = progress.topics.find(topic => topic.id === id);
  if (!['pending', 'in-progress'].includes(entry.status)) throw new Error('Unexpected active state');
  entry.status = 'in-progress';
  entry.designRecord = `docs/teaching/${design}.md`;
}
fs.writeFileSync(file, JSON.stringify(progress, null, 2) + '\n');
console.log('Recorded Greedy, DP and Tensor final source versions; preserved prior hashes and the complete scope.');
