const fs = require('node:fs');
const id = 'bayesian-inference-conjugate-priors';
fs.mkdirSync('scratch/bayesian-inference-review', { recursive: true });
const original = 'scratch/bayesian-inference-review/original-published-body.jsx';
if (!fs.existsSync(original)) fs.copyFileSync(`src/learn/data/topics/${id}.jsx`, original);
const indexPath = 'src/learn/data/curriculum/blueprints/index.js';
let index = fs.readFileSync(indexPath, 'utf8');
if (!index.includes('bayesianInferenceBlueprint')) {
  index = `import bayesianInferenceBlueprint from './${id}.js';\n` + index.replace(/};\s*$/, '  "Bayesian Inference & Conjugate Priors": bayesianInferenceBlueprint,\n};\n');
}
fs.writeFileSync(indexPath, index);
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(ledgerPath));
const topic = ledger.topics.find(entry => entry.id === id);
topic.status = 'in-progress';
topic.designRecord = 'docs/teaching/BAYESIAN-INFERENCE-CONJUGATE-DESIGN.md';
fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2) + '\n');
console.log('Bayesian design registered; existing pilot preserved until complete replacement.');
