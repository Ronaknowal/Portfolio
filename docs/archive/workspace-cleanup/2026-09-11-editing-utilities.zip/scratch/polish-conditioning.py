from pathlib import Path

root = Path(__file__).resolve().parents[1]
body = root / 'src/learn/data/topics/conditioning-stability-numerical-analysis.jsx'
text = body.read_text(encoding='utf-8')
text = text.replace('<Code>math.isclose(1e-9, 2e-9, rel_tol=1e-6, abs_tol=1e-12)</Code> is false.', '<Code>math.isclose</Code> with <Code>rel_tol=1e-6</Code> and <Code>abs_tol=1e-12</Code> rejects the comparison.')
body.write_text(text, encoding='utf-8')
lab = root / 'src/learn/components/lesson-labs/ConditioningStabilityLabs.jsx'
text = lab.read_text(encoding='utf-8')
text = text.replace('80 + 314 * (value - 1) / 59', '106 + 288 * (value - 1) / 59')
start = text.index('export function CancellationLab()')
end = text.index('export function MeasurementSensitivityLab()')
section = text[start:end].replace('x1="80"', 'x1="106"').replace('x2="80"', 'x2="106"').replace('x="80"', 'x="106"').replace('x="72"', 'x="98"').replace('[0, bottom / 2, bottom]', '[0, Math.floor(bottom / 2), bottom]').replace('>10^{tick}</text>', '>1e{tick}</text>')
text = text[:start] + section + text[end:]
text = text.replace('{f(node.value, 10)}', '{String(node.value)}').replace('{f(current.before, 10)}', '{String(current.before)}').replace('{f(current.value, 10)}', '{String(current.value)}').replace('{f(current.updated, 10)}', '{String(current.updated)}')
lab.write_text(text, encoding='utf-8')
css = root / 'src/learn/components/lesson-labs/conditioning-stability-labs.css'
text = css.read_text(encoding='utf-8').replace('.conditioning-pipeline { list-style: none; display: grid; grid-template-columns: 1fr 1fr;', '.conditioning-pipeline { list-style: none; display: grid; grid-template-columns: 1fr;')
text = text.replace('.conditioning-tree { min-width: 550px;', '.conditioning-tree { min-width: 550px; width: max-content;')
text = text.replace('flex: 1; min-width: 90px;', 'flex: 1; min-width: 160px;')
css.write_text(text, encoding='utf-8')
