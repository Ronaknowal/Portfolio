const fs = require('node:fs');
const assert = require('node:assert/strict');
const file = 'src/learn/components/lesson-labs/TopologyTdaLabs.jsx';
let source = fs.readFileSync(file, 'utf8');
const edits = [
  ["const cellName = vertices => '{' + vertices.join(',') + '}';", "const cellName = vertices => '{' + vertices.join(',') + '}';\nconst keyName = key => cellName(key.split('-'));"],
  ["className={boundaryKeys.has(String(index)) ? 'tda-boundary-vertex' : 'tda-vertex'}", "className={boundaryKeys.has(String(index)) ? 'tda-boundary-vertex' : activePoints.includes(index) || selectedKeys.has(String(index)) ? 'tda-selected-vertex' : 'tda-vertex'}"],
  ['rx={85} ry={38}', 'rx={58} ry={29}'],
  ['Stretching changes distances; an inverse recovers each point.', 'Vertical scaling changes distances; an inverse recovers each point.'],
  ['<line x1={45} y1={85} x2={215} y2={85}', '<line x1={72} y1={85} x2={188} y2={85}'],
  ['<circle cx={45} cy={85}', '<circle cx={72} cy={85}'],
  ['<circle cx={215} cy={85}', '<circle cx={188} cy={85}'],
  ["selected.join(' + ')", "selected.map(keyName).join(' + ')"],
  ["result.boundary.join(' + ')", "result.boundary.map(keyName).join(' + ')"],
  ["combinationKeys.join(' + ')", "combinationKeys.map(keyName).join(' + ')"],
  ["boundaryKeys.join(' + ')", "boundaryKeys.map(keyName).join(' + ')"],
  ['<text x={250} y={286}>{format(maximum)}</text>', '<text x={265} y={286} textAnchor="end">{format(maximum)}</text>'],
  ['<text x={40} y={24}>death ε</text>', '<text x={40} y={24}>death ε</text><text x={46} y={54}>{format(maximum)}</text>'],
  ['max={computation.maximum} step={0.01}', 'max={computation.maximum} step="any"'],
  ['Coordinates and thresholds use binary64 arithmetic;', 'Geometry automatically fits the selected points; compare coordinate scales through ε values, not screen pixel widths. Coordinates and thresholds use binary64 arithmetic;'],
];
for (const [before, after] of edits) {
  assert(source.includes(before), before);
  source = source.replace(before, after);
}
fs.writeFileSync(file, source);
const cssFile = 'src/learn/components/lesson-labs/topology-tda-labs.css';
let css = fs.readFileSync(cssFile, 'utf8');
assert(css.includes('font-size: 16px;'));
css = css.replace('font-size: 16px;', 'font-size: 17px;');
css += '\n.tda-selected-vertex { fill: #eac06e; stroke: #0c1118; stroke-width: 1.3; }\n';
fs.writeFileSync(cssFile, css);
console.log('Corrected map geometry, chain labels, selected vertices, plot endpoint and exact-threshold control.');
