import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { einsumExamples } from '../src/learn/data/einsum-examples.js';
const directory = 'scratch/einsum-verification';
mkdirSync(directory, { recursive: true });
let source = readFileSync('src/learn/data/einsum-examples.js', 'utf8');
for (const [key, example] of Object.entries(einsumExamples)) {
  const filename = directory + '/' + key + '.py';
  writeFileSync(filename, example.code);
  const run = spawnSync('scratch/lesson-tools/Scripts/python.exe', ['-I', filename], { encoding: 'utf8', env: { ...process.env, PYTHONIOENCODING: 'utf-8' } });
  if (run.status !== 0) throw new Error(key + ': ' + run.stderr);
  const expected = run.stdout.replaceAll('\r\n', '\n').trim();
  source = source.replace("expected: ''", 'expected: ' + JSON.stringify(expected));
  console.log(key + ': ' + expected);
}
writeFileSync('src/learn/data/einsum-examples.js', source);
