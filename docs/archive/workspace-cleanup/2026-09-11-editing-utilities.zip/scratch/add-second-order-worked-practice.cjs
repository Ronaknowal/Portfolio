const fs = require('node:fs');
const file = 'src/learn/data/topics/second-order-methods-l-bfgs-k-fac-shampoo-natural-gradient.jsx';
let source = fs.readFileSync(file, 'utf8');
const marker = '<summary>Acceptance criteria and interpretation</summary>';
if (!source.includes(marker) || source.includes('secondOrderMethodsExamples.changedFitComparison')) throw new Error('Expected the unexpanded practice response.');
source = source.replace(marker, marker + '<RunnableExample example={secondOrderMethodsExamples.changedFitComparison} /><Prose>This executed example counts the final objective/gradient check as well as training evaluations. L-BFGS uses 15 evaluations and reaches the declared gradient infinity-norm tolerance. Gradient descent with the declared rate .2 reaches its 1,000-evaluation budget first, though its residual is already close: .0000478 versus .0000471. This is evidence for this fixed fit and rate, not a universal speed or optimizer ranking. The observed evaluation count stays within the budget; a library maximum-evaluation setting should still be checked against actual calls.</Prose>');
fs.writeFileSync(file, source);
console.log('Added the executed changed-data comparison inside the independent practice solution.');
