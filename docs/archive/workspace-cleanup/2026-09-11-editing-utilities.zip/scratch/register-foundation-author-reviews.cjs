const fs = require('node:fs');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const hash = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const id = 'external-memory-algorithms-b-trees-i-o-complexity';
const body = `src/learn/data/topics/${id}.jsx`;
assert.ok(fs.statSync(body).size > 15000);
const manifestPath = 'src/learn/data/lesson-manifest.json';
const manifest = JSON.parse(fs.readFileSync(manifestPath));
manifest[id] = `./topics/${id}.jsx`;
fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + '\n');
const indexPath = 'src/learn/data/curriculum/blueprints/index.js';
let index = fs.readFileSync(indexPath, 'utf8');
if (!index.includes('hypothesisTestingBlueprint')) {
  index = "import hypothesisTestingBlueprint from './hypothesis-testing-confidence-intervals.js';\n" + index.replace(/};\s*$/, '  "Hypothesis Testing & Confidence Intervals": hypothesisTestingBlueprint,\n};\n');
}
fs.writeFileSync(indexPath, index);
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(ledgerPath));
const hypothesis = ledger.topics.find(entry => entry.id === 'hypothesis-testing-confidence-intervals');
hypothesis.status = 'in-progress';
hypothesis.designRecord = 'docs/teaching/HYPOTHESIS-TESTING-CONFIDENCE-DESIGN.md';
for (const [topicId, files, design, verification] of [
  ['computational-geometry-robust-predicates-convex-hulls', JSON.parse(fs.readFileSync('docs/teaching/evidence/computational-geometry-author-review.json')).source_sha256, 'COMPUTATIONAL-GEOMETRY-LESSON-DESIGN.md', 'COMPUTATIONAL-GEOMETRY-VERIFICATION.md'],
  ['persistent-data-structures-structural-sharing-versioned-queries', JSON.parse(fs.readFileSync('scratch/persistent-structures-lesson-review/final-source-hashes.json')), 'PERSISTENT-DATA-STRUCTURES-LESSON-DESIGN.md', 'PERSISTENT-DATA-STRUCTURES-VERIFICATION.md'],
]) {
  for (const [file, expected] of Object.entries(files)) assert.equal(hash(file), expected, file);
  const topic = ledger.topics.find(entry => entry.id === topicId);
  topic.source = manifest[topicId];
  topic.status = 'author-verified';
  topic.designRecord = `docs/teaching/${design}`;
  topic.verificationRecord = `docs/teaching/${verification}`;
  topic.reviewedFiles = files;
  topic.reviewedSourceSha256 = files[`src/learn/data/topics/${topicId}.jsx`];
}
fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2) + '\n');
console.log('External-Memory complete draft published; Hypothesis design registered; Geometry/Persistent source-frozen as author-verified, integration pending.');
