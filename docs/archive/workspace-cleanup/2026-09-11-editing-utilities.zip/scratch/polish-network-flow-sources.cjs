const fs = require('node:fs');
const files = ['src/learn/components/lesson-labs/NetworkFlowLabs.jsx', 'src/learn/data/topics/network-flow-minimum-cuts-bipartite-matching.jsx', 'src/learn/data/practice/network-flow-minimum-cuts-bipartite-matching.js'];
const replacements = [
  ['capacity1', 'capacity 1'], ['capacity2', 'capacity 2'], ['capacity3', 'capacity 3'], ['capacity4', 'capacity 4'], ['capacity5', 'capacity 5'], ['capacity7', 'capacity 7'], ['capacity9', 'capacity 9'], ['capacity0', 'capacity 0'],
  ['flow3', 'flow 3'], ['flow1', 'flow 1'], ['size3', 'size 3'], ['size5', 'size 5'], ['value2', 'value 2'],
  ['cost1', 'cost 1'], ['cost2', 'cost 2'], ['cost4', 'cost 4'], ['cost200', 'cost 200'], ['value1', 'value 1'],
  ['Python3.12', 'Python 3.12'], ['Algorithms4', 'Algorithms 4'], ['Lecture13', 'Lecture 13'], ['MIT6.046', 'MIT 6.046'],
  ['tasks1–3', 'tasks 1–3'], ['size3', 'size 3'], ['integer0', 'integer 0'], ['integers0', 'integers 0'],
  ['all64', 'all 64'], ['from0', 'from 0'], ['to9', 'to 9'], ['to2', 'to 2'], ['by6', 'by 6'], ['only4', 'only 4'],
  ['carrying2', 'carrying 2'], ['carry0', 'carry 0'], ['carries0', 'carries 0'], ['carrying1', 'carrying 1'], ['carrying5', 'carrying 5'],
  ['receives1', 'receives 1'], ['sends1', 'sends 1'], ['Sending1', 'Sending 1'], ['Sending2', 'Sending 2'], ['Sending3', 'Sending 3'],
  ['value3', 'value 3'], ['value4', 'value 4'], ['delivers4', 'delivers 4'], ['demands6', 'demands 6'], ['delivers5', 'delivers 5'],
  ['cost3', 'cost 3'], ['cost5', 'cost 5'], ['cost7', 'cost 7'], ['cost6', 'cost 6'], ['cost8', 'cost 8'], ['cost9', 'cost 9'],
  ['minimum3', 'minimum 3'], ['optimum3', 'optimum 3'], ['optimum2', 'optimum 2'], ['size1', 'size 1'], ['size2', 'size 2'], ['size4', 'size 4'], ['size7', 'size 7'],
  ['edge2', 'edge 2'], ['edge1', 'edge 1'], ['Vertex1', 'Vertex 1'], ['vertex1', 'vertex 1'], ['vertex2', 'vertex 2'],
  ['Cell1', 'Cell 1'], ['cell1', 'cell 1'], ['cell0', 'cell 0'], ['above0', 'above 0'], ['by1', 'by 1'], ['by2', 'by 2'],
  ['at least1', 'at least 1'], ['at least0', 'at least 0'], ['at most1', 'at most 1'], ['at least2', 'at least 2'],
  ['left0', 'left 0'], ['right0', 'right 0'], ['task1', 'task 1'], ['task3', 'task 3'], ['limit0', 'limit 0'],
  ['tasks1', 'tasks 1'], ['20 times', '20 times'], ['seed20', 'seed 20'], ['seed20 times', 'seed 20 times'],
  ['up to2,000', 'up to 2,000'], ['and10,000', 'and 10,000'], ['at most8×8', 'at most 8×8'],
  ['capacity{', 'capacity {'], ['size{', 'size {'], ['Size{', 'Size {'], ['only{', 'only {'], ['least{', 'least {'],
  ['Task{name}', 'Task {name}'], ['Cell{vertex}', 'Cell {vertex}'], ['unary{', 'unary {'], ['boundaries{', 'boundaries {'], ['penalty{', 'penalty {'],
  ['minimum{', 'minimum {'], ['cost{', 'cost {'], ['capacity${', 'capacity ${'], ['> flow${', '> flow ${'],
];
for (const file of files) {
  let source = fs.readFileSync(file, 'utf8');
  for (const [before, after] of replacements) source = source.replaceAll(before, after);
  fs.writeFileSync(file, source);
}
