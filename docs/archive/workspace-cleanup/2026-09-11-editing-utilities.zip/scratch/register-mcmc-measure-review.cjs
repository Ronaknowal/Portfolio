const fs = require('node:fs');
const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(ledgerPath));
const topicId = 'monte-carlo-methods-mcmc-metropolis-hastings-hmc-nuts';
const files = JSON.parse(fs.readFileSync('scratch/monte-carlo-mcmc-lesson-review/final-source-hashes.json'));
for (const [file, hash] of Object.entries(files)) assert.equal(createHash('sha256').update(fs.readFileSync(file)).digest('hex'), hash, file);
const evidence = {
  topicId, frozenAt: new Date().toISOString(), files,
  native: JSON.parse(fs.readFileSync('scratch/monte-carlo-mcmc-native-verification/independent-evidence.json')),
  browser: JSON.parse(fs.readFileSync('scratch/monte-carlo-mcmc-lesson-review/results.json')),
  changedTargetReview: JSON.parse(fs.readFileSync('scratch/monte-carlo-mcmc-lesson-review/beta-transfer-review.json')),
  independentReview: 'docs/teaching/MONTE-CARLO-MCMC-INDEPENDENT-REVIEW.md'
};
fs.writeFileSync('docs/teaching/evidence/monte-carlo-mcmc-author-review.json', JSON.stringify(evidence, null, 2) + '\n');
const topic = ledger.topics.find(entry => entry.id === topicId);
assert.equal(topic.status, 'in-progress');
Object.assign(topic, {
  status: 'author-verified',
  verificationRecord: 'docs/teaching/MONTE-CARLO-MCMC-VERIFICATION.md',
  reviewedFiles: files,
  reviewedSourceSha256: files['src/learn/data/topics/' + topicId + '.jsx'],
});
const indexPath = 'src/learn/data/curriculum/blueprints/index.js';
const index = fs.readFileSync(indexPath, 'utf8');
assert.ok(!index.includes('measureTheoryBlueprint'));
fs.writeFileSync(indexPath, "import measureTheoryBlueprint from './measure-theory-probability-spaces.js';\n" + index.replace(/};\s*$/, "  'Measure Theory & Probability Spaces': measureTheoryBlueprint,\n};\n"));
const measure = ledger.topics.find(entry => entry.id === 'measure-theory-probability-spaces');
assert.ok(measure);
measure.status = 'in-progress';
measure.designRecord = 'docs/teaching/MEASURE-THEORY-PROBABILITY-SPACES-DESIGN.md';
fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2) + '\n');
const loadPath = 'scripts/verify-learning-load-boundaries.cjs';
let load = fs.readFileSync(loadPath, 'utf8');
const ids = ['hypothesis-testing-confidence-intervals', 'bayesian-inference-conjugate-priors', 'concentration-inequalities-hoeffding-bernstein-chernoff', topicId];
load = load.replace('const mathematicsLessons = [', 'const mathematicsLessons = [' + ids.map(id => "'" + id + "'").join(', ') + ', ');
load = load.replace('reviewed matrix lesson loads only its selected body and actual dependencies', 'reviewed mathematics lesson loads only its selected body and actual dependencies');
fs.writeFileSync(loadPath, load);
console.log('MCMC author freeze recorded; Measure Theory brief registered; production check scope now20 mathematics and22 DSA.');
