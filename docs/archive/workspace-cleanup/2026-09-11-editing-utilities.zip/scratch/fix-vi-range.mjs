import {readFileSync,writeFileSync} from 'node:fs';
const f='src/learn/components/lesson-labs/VariationalInferenceLabs.jsx';let s=readFileSync(f,'utf8');s=s.replace('label="Probability of A" value={first} min={0} max={1} step={0.01}','label="Probability of A" value={first} min={0} max={1} step="any"');writeFileSync(f,s);
