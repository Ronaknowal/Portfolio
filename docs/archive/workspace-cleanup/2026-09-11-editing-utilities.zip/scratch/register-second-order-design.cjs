const fs = require('node:fs');
const crypto = require('node:crypto');
const id = 'second-order-methods-l-bfgs-k-fac-shampoo-natural-gradient';
const indexPath = 'src/learn/data/curriculum/blueprints/index.js';
let index = fs.readFileSync(indexPath, 'utf8');
if (!index.includes('secondOrderMethodsBlueprint')) {
  index = `import secondOrderMethodsBlueprint from './${id}.js';\n` + index.replace(/};\s*$/, '  "Second-Order Methods (L-BFGS, K-FAC, Shampoo, Natural Gradient)": secondOrderMethodsBlueprint,\n};\n');
  fs.writeFileSync(indexPath, index);
}
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(ledgerPath));
const secondOrder = ledger.topics.find(topic => topic.id === id);
secondOrder.status = 'in-progress';
secondOrder.designRecord = 'docs/teaching/SECOND-ORDER-METHODS-DESIGN.md';
const flow = ledger.topics.find(topic => topic.id === 'network-flow-minimum-cuts-bipartite-matching');
flow.status = 'in-progress';
if (fs.existsSync('docs/teaching/NETWORK-FLOW-LESSON-DESIGN.md')) flow.designRecord = 'docs/teaching/NETWORK-FLOW-LESSON-DESIGN.md';
const reductions = ledger.topics.find(topic => topic.id === 'reductions-p-np-computational-intractability');
const hashes = JSON.parse(fs.readFileSync('scratch/intractability-lesson-review/final-source-hashes.json'));
for (const [file, hash] of Object.entries(hashes)) {
  if (crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex') !== hash) throw new Error(`Frozen source changed: ${file}`);
}
reductions.status = 'author-verified';
reductions.verificationRecord = 'docs/teaching/REDUCTIONS-INTRACTABILITY-VERIFICATION.md';
reductions.reviewedFiles = hashes;
reductions.reviewedSourceSha256 = hashes[`src/learn/data/topics/${reductions.id}.jsx`];
fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2) + '\n');
console.log('Registered Second-Order design, active Network Flow and frozen Reductions author evidence.');
