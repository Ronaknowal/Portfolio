from pathlib import Path
path = Path('src/learn/data/topics/mutual-information-information-bottleneck.jsx')
text = path.read_text(encoding='utf8')
changes = [
    (r'I(A;Y\mid B)=\sum_b p(b)D_{\rm KL}(P_b\Vert Q_b),', r'I(A;Y\mid B)\\=\sum_b p(b)D_{\rm KL}(P_b\Vert Q_b),'),
    (r'=\mathbb E_{x,z}\log\frac{q(z\mid x)}{r(z)}+\beta\mathbb E_{x,z}D_w(x,z).', r'=\mathbb E_{x,z}\log\frac{q(z\mid x)}{r(z)}\\+\beta\mathbb E_{x,z}D_w(x,z).'),
]
for old, new in changes:
    assert text.count(old) == 1
    text = text.replace(old, new)
path.write_text(text, encoding='utf8')

path = Path('scripts/prepare-mutual-information-examples.py')
text = path.read_text(encoding='utf8')
for old, new in [('with0.', 'with 0.'), ('MI is1,', 'MI is 1,'), ('MI is0.', 'MI is 0.')]:
    text = text.replace(old, new)
path.write_text(text, encoding='utf8')
