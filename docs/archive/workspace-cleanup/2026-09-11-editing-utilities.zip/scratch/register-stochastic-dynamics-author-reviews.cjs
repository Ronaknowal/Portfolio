const fs = require('node:fs');
const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const hash = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(ledgerPath, 'utf8'));
const records = [
  ['stochastic-processes-markov-chains-brownian-motion-poisson', 'stochastic-processes', 'STOCHASTIC-PROCESSES-VERIFICATION.md'],
  ['random-matrix-theory', 'random-matrix', 'RANDOM-MATRIX-THEORY-VERIFICATION.md'],
  ['queueing-theory-m-m-1-m-g-1-little-s-law', 'queueing', 'QUEUEING-THEORY-VERIFICATION.md'],
  ['dynamical-systems-theory-chaos', 'dynamical-systems', 'DYNAMICAL-SYSTEMS-VERIFICATION.md'],
];
for (const [id, prefix, verification] of records) {
  const entry = ledger.topics.find(topic => topic.id === id);
  assert.equal(entry.status, 'in-progress', id);
  const recordPath = 'docs/teaching/evidence/' + prefix + '-author-review.json';
  const review = JSON.parse(fs.readFileSync(recordPath, 'utf8'));
  assert.equal(review.topicId, id);
  const sources = review.production || review.hashes;
  assert.equal(sources.length, 6);
  entry.reviewedFiles = Object.fromEntries(sources.map(source => {
    const file = source.path || source.file;
    assert.equal(hash(file), source.sha256, file);
    return [file, source.sha256];
  }));
  entry.reviewedSourceSha256 = entry.reviewedFiles['src/learn/data/' + entry.source.replace('./', '')];
  assert(entry.reviewedSourceSha256);
  entry.status = 'author-verified';
  entry.verificationRecord = 'docs/teaching/' + verification;
  entry.authorEvidenceRecord = recordPath;
}
fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2) + '\n');
const loadingPath = 'scripts/verify-learning-load-boundaries.cjs';
let loading = fs.readFileSync(loadingPath, 'utf8');
const anchor = 'const mathematicsLessons = [';
assert(loading.includes(anchor));
for (const [id] of records) assert(!loading.includes("'" + id + "'"), id + ' already present');
loading = loading.replace(anchor, anchor + records.map(([id]) => "'" + id + "'").join(', ') + ', ');
fs.writeFileSync(loadingPath, loading);
console.log('Registered four exact author reviews and added four independent production-loading cases; integrated review remains pending.');
