const fs = require('node:fs');
const file = 'src/learn/data/topics/eigenvalues-eigenvectors.jsx';
let source = fs.readFileSync(file, 'utf8');
const changes = [
  ['This preserves the original transformation and uses explicit output formatting.', 'This program uses the same transformation and explicit output formatting.'],
  ["This completes the original lesson's PCA idea with an explicit dataset and full setup.", 'Compute covariance, projections and error from the four-point dataset with full setup.'],
  ['The companion summary and the early transcript sections were reviewed for this lesson; full-video viewing is not claimed.', 'The summary and transcript offer a written companion to the lecture.'],
  ['A Schur factorization supplies an orthonormal basis with a triangular representation even when a diagonal eigenbasis fails.', 'Over complex coordinates, a Schur factorization supplies a unitary basis and an upper-triangular representation even when a diagonal eigenbasis fails. Its real counterpart may need 2×2 blocks for complex-conjugate pairs.'],
  ['Numerical residuals and demonstrations support the calculations; they are not measurements of learning outcomes or guarantees about an unmodeled real system.', 'For a real application, check that the assumed linear rule, units and measured inputs describe the system you intend to study.'],
];
for (const [before, after] of changes) {
  if (!source.includes(before)) throw new Error('Missing intended prose: ' + before);
  source = source.replace(before, after);
}
require('@babel/parser').parse(source, { sourceType: 'module', plugins: ['jsx'] });
fs.writeFileSync(file, source);
const labs = 'src/learn/components/lesson-labs/EigenvalueLabs.jsx';
source = fs.readFileSync(labs, 'utf8');
source = source.replace('Actual bounded 2×2 operations; no general eigensolver or sampled benchmark.', 'Every quantity is calculated from the displayed 2×2 matrix.');
fs.writeFileSync(labs, source);
console.log('Removed authoring-history/process prose and clarified complex versus real Schur form.');
