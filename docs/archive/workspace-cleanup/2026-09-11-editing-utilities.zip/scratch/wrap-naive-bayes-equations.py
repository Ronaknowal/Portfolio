from pathlib import Path
import json
import re
p = Path("src/learn/data/topics/naive-bayes-probabilistic-classifiers.jsx")
s = p.read_text(encoding="utf-8")
replacements = {
2: r"\begin{aligned}s_c(x)&=\log\pi_c+\sum_j\log P(x_j\mid c),\\m&=\max_r s_r,\\\ell&=m+\log\sum_r\exp(s_r-m),\\\log P(c\mid x)&=s_c-\ell.\end{aligned}",
5: r"\begin{gathered}P(b\mid c)=\prod_j\phi_{cj}^{b_j}(1-\phi_{cj})^{1-b_j},\\t_{cj}=\begin{cases}\log\phi_{cj}&b_j=1,\\\log(1-\phi_{cj})&b_j=0,\end{cases}\\s_c(b)=\log\pi_c+\sum_jt_{cj}.\end{gathered}",
9: r"\begin{aligned}Q_{cj}&=\frac{(x_j-\mu_{cj})^2}{\sigma_{cj}^2},\\D_j&=\log\frac{\sigma_{1j}^2}{\sigma_{0j}^2}+Q_{1j}-Q_{0j},\\s_1(x)-s_0(x)&=\log\frac{\pi_1}{\pi_0}-\frac12\sum_jD_j.\end{aligned}",
10: r"\begin{gathered}P(\text{fault}\mid +,+,+)\\=\frac{0.2\cdot0.8}{0.2\cdot0.8+0.8\cdot0.4}=\frac13,\\\widehat P_{\mathrm{ind}}(\text{fault}\mid +,+,+)\\=\frac{0.2\cdot0.8^3}{0.2\cdot0.8^3+0.8\cdot0.4^3}=\frac23.\end{gathered}",
12: r"\begin{aligned}\log O_{\mathrm{new}}(x)&=\log O_{\mathrm{old}}(x)\\&\quad+\log\frac{\pi_{\mathrm{new},1}/\pi_{\mathrm{new},0}}{\pi_{\mathrm{old},1}/\pi_{\mathrm{old},0}}.\end{aligned}",
16: r"\begin{gathered}P(x\mid\text{training})=\frac{N!}{\prod_jx_j!}\frac{\prod_j A_j^{\overline{x_j}}}{A_0^{\overline N}},\\A_0=\sum_j A_j,\\a^{\overline m}=a(a+1)\cdots(a+m-1),\\a^{\overline0}=1.\end{gathered}"
}
matches = list(re.finditer(r'<MathBlock>\{".*?"\}</MathBlock>', s))
assert len(matches) == 17, len(matches)
for index, value in sorted(replacements.items(), reverse=True):
    match = matches[index]
    s = s[:match.start()] + "<MathBlock>{" + json.dumps(value) + "}</MathBlock>" + s[match.end():]
needle = '<MathBlock>{' + json.dumps(replacements[9]) + '}</MathBlock>'
s = s.replace(needle, '<Prose>In the next formula, Q꜀ⱼ is the squared deviation measured relative to that class variance. Dⱼ compares this distance penalty and the spread-normalization penalty between the classes. Summing those per-feature comparisons gives the complete score difference:</Prose>\n    ' + needle)
p.write_text(s, encoding="utf-8")
