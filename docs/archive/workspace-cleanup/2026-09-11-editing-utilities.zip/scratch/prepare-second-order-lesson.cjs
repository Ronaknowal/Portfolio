const fs = require('node:fs');
const assert = require('node:assert/strict');
const parser = require('@babel/parser');
const generate = require('@babel/generator').default;
const target = 'src/learn/data/topics/second-order-methods-l-bfgs-k-fac-shampoo-natural-gradient.jsx';
let source = fs.readFileSync('scratch/second-order-lesson.jsx', 'utf8');
source = source.replaceAll('../src/learn/components/', '../../components/').replaceAll('../src/learn/data/', '../');
parser.parse(source, { sourceType: 'module', plugins: ['jsx'] });
if (!fs.existsSync('scratch/second-order-original.jsx')) fs.copyFileSync(target, 'scratch/second-order-original.jsx');
fs.writeFileSync(target, source);
function normalize(value) {
  if (Array.isArray(value)) return value.map(normalize);
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).filter(([key]) => !['start', 'end', 'loc', 'extra', 'tokens'].includes(key)).map(([key, child]) => [key, normalize(child)]));
  return value;
}
const files = [target, 'src/learn/components/lesson-labs/SecondOrderMethodsLabs.jsx', 'src/learn/data/second-order-methods-models.js'];
for (const file of files) {
  const original = fs.readFileSync(file, 'utf8');
  const ast = parser.parse(original, { sourceType: 'module', plugins: ['jsx'] });
  const output = generate(ast, { comments: true, compact: false }, original).code + '\n';
  assert.deepEqual(normalize(parser.parse(output, { sourceType: 'module', plugins: ['jsx'] })), normalize(ast));
  fs.writeFileSync(file, output);
}
console.log('Complete Second-Order lesson installed; formatting preserves normalized AST and literal code/math.');
