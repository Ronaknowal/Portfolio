from pathlib import Path
import json
import re
p = Path("src/learn/data/topics/naive-bayes-probabilistic-classifiers.jsx")
s = p.read_text(encoding="utf-8")
replacements = {
1: r"\begin{gathered}P(\text{spam}\mid\text{free})\\=\frac{8/33}{8/33+1/21}=\frac{56}{67},\\P(\text{ham}\mid\text{free})=\frac{11}{67}.\end{gathered}",
2: r"\begin{gathered}s_c(x)=\log\pi_c+\sum_j\log P(x_j\mid c),\\m=\max_r s_r,\\\ell=m+\log\sum_r\exp(s_r-m),\\\log P(c\mid x)=s_c-\ell.\end{gathered}",
7: r"\begin{gathered}z_{cj}=\frac{x_j-\mu_{cj}}{\sigma_{cj}},\\f(x_j\mid c)=\frac{\exp(-z_{cj}^{2}/2)}{\sqrt{2\pi}\,\sigma_{cj}}.\end{gathered}",
8: r"\begin{gathered}\widehat\mu=\frac1D\sum_i x_i,\\\widehat\sigma^2=\frac1D\sum_i(x_i-\widehat\mu)^2.\end{gathered}",
9: r"\begin{gathered}Q_{cj}=\frac{(x_j-\mu_{cj})^2}{\sigma_{cj}^2},\\D_j=\log\frac{\sigma_{1j}^2}{\sigma_{0j}^2}+Q_{1j}-Q_{0j},\\s_1(x)-s_0(x)\\=\log\frac{\pi_1}{\pi_0}-\frac12\sum_jD_j.\end{gathered}",
13: r"\begin{gathered}\mathbb E[(p-Y)^2\mid x]\\=(p-q)^2+q(1-q),\\q=P(Y=1\mid x).\end{gathered}",
15: r"\begin{aligned}\log O(x)&=\log\frac{\pi_1}{\pi_0}\\&\quad+\sum_jx_j\log\frac{\theta_{1j}}{\theta_{0j}}.\end{aligned}"
}
matches = list(re.finditer(r'<MathBlock>\{".*?"\}</MathBlock>', s))
assert len(matches) == 17
for index, value in sorted(replacements.items(), reverse=True):
    match = matches[index]
    s = s[:match.start()] + "<MathBlock>{" + json.dumps(value) + "}</MathBlock>" + s[match.end():]
p.write_text(s, encoding="utf-8")
