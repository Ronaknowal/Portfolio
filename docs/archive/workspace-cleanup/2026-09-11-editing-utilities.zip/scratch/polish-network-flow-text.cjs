const fs = require('node:fs');
const { parse } = require('@babel/parser');
for (const file of ['src/learn/data/topics/network-flow-minimum-cuts-bipartite-matching.jsx', 'src/learn/components/lesson-labs/NetworkFlowLabs.jsx']) {
  let source = fs.readFileSync(file, 'utf8');
  const ast = parse(source, { sourceType: 'module', plugins: ['jsx'] });
  const edits = [];
  function walk(node) {
    if (!node || typeof node !== 'object') return;
    if (node.type === 'JSXText') {
      const text = source.slice(node.start, node.end);
      const changed = text.replace(/([A-Za-z]{2,})(?=\d)/g, '$1 ');
      if (changed !== text) edits.push({ start: node.start, end: node.end, text: changed });
    }
    for (const value of Object.values(node)) {
      if (Array.isArray(value)) value.forEach(walk);
      else if (value && typeof value === 'object') walk(value);
    }
  }
  walk(ast);
  for (const edit of edits.sort((a, b) => b.start - a.start)) source = source.slice(0, edit.start) + edit.text + source.slice(edit.end);
  // Only scroll containers receive a keyboard stop; tables retain their own captions.
  if (file.includes('NetworkFlowLabs')) source = source.replace(/className="nf-table-scroll"(?! tabIndex)/g, 'className="nf-table-scroll" tabIndex={0} role="region" aria-label="Detailed flow data"');
  fs.writeFileSync(file, source);
  console.log(file, edits.length, 'learner-facing text spans spaced; no code/URL/example changes');
}
