const fs = require('node:fs');
const indexPath = 'src/learn/data/curriculum/blueprints/index.js';
let index = fs.readFileSync(indexPath, 'utf8');
if (!index.includes('maximumLikelihoodBlueprint')) {
  index = "import maximumLikelihoodBlueprint from './maximum-likelihood-map-estimation.js';\n" + index.replace(/};\s*$/, '  "Maximum Likelihood & MAP Estimation": maximumLikelihoodBlueprint,\n};\n');
}
fs.writeFileSync(indexPath, index);
const path = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(path));
const entry = ledger.topics.find(topic => topic.id === 'maximum-likelihood-map-estimation');
entry.status = 'in-progress';
entry.designRecord = 'docs/teaching/MAXIMUM-LIKELIHOOD-MAP-LESSON-DESIGN.md';
fs.writeFileSync(path, JSON.stringify(ledger, null, 2) + '\n');
const bodyPath = 'src/learn/data/topics/probability-distributions-bayes-theorem.jsx';
let body = fs.readFileSync(bodyPath, 'utf8');
for (const [old, replacement] of [
  ['e⁻ˡᵃᵐᵇᵈᵃ⁽ˢ⁺ᵗ⁾', '<Code>exp(−λ(s+t))</Code>'],
  ['e⁻ˡᵃᵐᵇᵈᵃˢ', '<Code>exp(−λs)</Code>'],
  ['e⁻ˡᵃᵐᵇᵈᵃᵗ', '<Code>exp(−λt)</Code>'],
]) body = body.replaceAll(old, replacement);
fs.writeFileSync(bodyPath, body);
console.log('MLE design registered; Probability exponential notation clarified.');
