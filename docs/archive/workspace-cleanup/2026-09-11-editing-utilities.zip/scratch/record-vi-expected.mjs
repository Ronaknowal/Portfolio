import {readFileSync,writeFileSync} from 'node:fs';import {spawnSync} from 'node:child_process';import {variationalExamples as examples} from '../src/learn/data/variational-inference-examples.js';
let text=readFileSync('src/learn/data/variational-inference-examples.js','utf8');
for(const name of Object.keys(examples)){const r=spawnSync('scratch/lesson-tools/Scripts/python.exe',['-I',`scratch/variational-inference-native-verification/${name}.py`],{encoding:'utf8'});if(r.status)throw Error(r.stderr);text=text.replace("expected: ''",'expected: '+JSON.stringify(r.stdout.replace(/\r\n/g,'\n').trim()));}
writeFileSync('src/learn/data/variational-inference-examples.js',text);
