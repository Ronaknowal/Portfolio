import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parents[1]
path = root / 'docs/teaching/evidence/graph-fundamentals-author-review.json'
record = json.loads(path.read_text(encoding='utf-8'))
model = 'src/learn/data/graph-fundamentals-models.js'
script = 'scripts/verify-graph-fundamentals.py'
stamp = datetime.now(timezone.utc).isoformat()
amendment = {
    'checkedAt': stamp,
    'previousFreeze': record['authorFrozenAt'],
    'previousModelHash': record['productionHashes'][model],
    'finding': 'A positive degree whose reciprocal overflows was accepted by graphNormalizations; 1e-310 yielded non-finite normalized matrices.',
    'repair': 'Reject non-finite inverse degrees with RangeError and request a weight rescale. Keep zero-degree convention and finite reciprocal behavior.',
    'verification': 'Full owned native/oracle suite rerun, plus three rejected subnormal weights and accepted 1e-308 with independently expected two-node matrices.',
    'browserScope': 'Existing final browser and opened images predate this guard. All body/lab/CSS/example/brief bytes are unchanged; UI exposes no rejected subnormal weights. No new browser run is claimed.',
}
for name, old in record['productionHashes'].items():
    current = hashlib.sha256((root / name).read_bytes()).hexdigest()
    if name != model:
        assert current == old, name
    record['productionHashes'][name] = current
record['verificationSourceHashes'][script] = hashlib.sha256((root / script).read_bytes()).hexdigest()
record['native'] = json.loads((root / 'scratch/graph-fundamentals-native/results.json').read_text(encoding='utf-8'))
record['authorFrozenAt'] = stamp
record['amendments'] = record.get('amendments', []) + [amendment]
path.write_text(json.dumps(record, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({'freeze': stamp, 'modelHash': record['productionHashes'][model]}, indent=2))
