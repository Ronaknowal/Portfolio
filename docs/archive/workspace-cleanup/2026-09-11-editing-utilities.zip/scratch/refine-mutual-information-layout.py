from pathlib import Path

path = Path('src/learn/data/topics/mutual-information-information-bottleneck.jsx')
text = path.read_text(encoding='utf8')
changes = [
    (r'\begin{gathered}I(X;Y)=\mathbb E\!\left[\log_2 p(Y\mid X)-\log_2 p(Y)\right],\\ I(X;Y)=D_{\rm KL}(P_{XY}\Vert P_XP_Y).\end{gathered}', r'\begin{gathered}\begin{aligned}I(X;Y)&=\mathbb E\log_2p(Y\mid X)\\&\quad-\mathbb E\log_2p(Y),\end{aligned}\\I(X;Y)=D_{\rm KL}(P_{XY}\Vert P_XP_Y).\end{gathered}'),
    (r'\begin{gathered}I(A;Y\mid B)=\sum_b p(b)\,D_{\rm KL}\!\left(p(a,y\mid b)\Vert p(a\mid b)p(y\mid b)\right),\\ I((A,B);Y)=I(B;Y)+I(A;Y\mid B).\end{gathered}', r'\begin{gathered}I(A;Y\mid B)=\sum_b p(b)D_{\rm KL}(P_b\Vert Q_b),\\ I((A,B);Y)\\=I(B;Y)+I(A;Y\mid B).\end{gathered}'),
    (r'\begin{aligned}I(Y;(X,Z))&=I(Y;X)+I(Y;Z\mid X)\\ &=I(Y;X),\\ I(Y;(X,Z))&=I(Y;Z)+I(Y;X\mid Z).\end{aligned}', r'\begin{gathered}I(Y;(X,Z))\\=I(Y;X)+I(Y;Z\mid X)\\=I(Y;X),\\I(Y;(X,Z))\\=I(Y;Z)+I(Y;X\mid Z).\end{gathered}'),
    (r'J(q)=I(X;Z)-\beta I(Y;Z),\qquad \beta\geq0,', r'J(q)=I(X;Z)-\beta I(Y;Z),\\\beta\geq0,'),
    (r'\begin{gathered}p(z)=\sum_xp(x)q(z\mid x),\\ p(y\mid z)=\frac{\sum_xp(x)p(y\mid x)q(z\mid x)}{p(z)}.\end{gathered}', r'\begin{gathered}p(z)=\sum_xp(x)q(z\mid x),\\p(x\mid z)=\frac{p(x)q(z\mid x)}{p(z)},\\p(y\mid z)=\sum_xp(x\mid z)p(y\mid x).\end{gathered}'),
    (r'\begin{gathered}d(x,z)=D_{\rm KL}\!\left(p(y\mid x)\Vert p(y\mid z)\right),\\ q_{\rm new}(z\mid x)=\frac{p(z)\exp[-\beta d(x,z)]}{\sum_{z\x27}p(z\x27)\exp[-\beta d(x,z\x27)]}.\end{gathered}'.replace(r'\x27', "'"), r'\begin{gathered}d(x,z)\\=D_{\rm KL}(p(y\mid x)\Vert p(y\mid z)),\\a_z(x)=p(z)\exp[-\beta d(x,z)],\\q_{\rm new}(z\mid x)=\frac{a_z(x)}{\sum_j a_j(x)}.\end{gathered}'),
    (r'\begin{aligned}F(q,r,w)={}&\mathbb E_{x,z}\log\frac{q(z\mid x)}{r(z)}\\ &+\beta\,\mathbb E_{x,z}D_{\rm KL}(p(y\mid x)\Vert w(y\mid z)).\end{aligned}', r'\begin{gathered}D_w(x,z)\\=D_{\rm KL}(p(y\mid x)\Vert w(y\mid z)),\\F(q,r,w)\\=\mathbb E_{x,z}\log\frac{q(z\mid x)}{r(z)}+\beta\mathbb E_{x,z}D_w(x,z).\end{gathered}'),
    (r'\begin{aligned}F(q,r,w)={}&J(q)+\beta I(X;Y)\\ &+D_{\rm KL}(p(z)\Vert r(z))\\ &+\beta\,\mathbb E_zD_{\rm KL}(p(y\mid z)\Vert w(y\mid z)).\end{aligned}', r'\begin{gathered}F(q,r,w)\\=J(q)+\beta I(X;Y)\\+D_{\rm KL}(p(z)\Vert r(z))\\+\beta\mathbb E_zD_{\rm KL}(p(y\mid z)\Vert w(y\mid z)).\end{gathered}'),
    (r'\begin{gathered}C=\mathbb E_{y,z}[-\log s(y\mid z)],\\ L=H(Y)-C\\ =I(Y;Z)-\mathbb E_zD_{\rm KL}(p(y\mid z)\Vert s(y\mid z))\\ \leq I(Y;Z).\end{gathered}', r'\begin{gathered}C=\mathbb E_{y,z}[-\log s(y\mid z)],\\G_s=\mathbb E_zD_{\rm KL}(p(y\mid z)\Vert s(y\mid z)),\\L=H(Y)-C\\=I(Y;Z)-G_s\leq I(Y;Z).\end{gathered}'),
    (r'D_{\rm KL}(q(z\mid x)\Vert\mathcal N(0,I))=\frac12\sum_j\left(\mu_j(x)^2+\sigma_j(x)^2-1-\log\sigma_j(x)^2\right).', r'\begin{gathered}D_{\rm KL}(q(z\mid x)\Vert\mathcal N(0,I))\\=\frac12\sum_j\left(\mu_j^2+v_j-1-\log v_j\right).\end{gathered}'),
    (r'I(X;Z)=\frac12\log_2\left(1+\frac{1}{\sigma^2}\right)\quad\text{bits}.', r'I(X;Z)=\frac12\log_2\left(1+\frac{1}{\sigma^2}\right).'),
    ('In each XOR slice, knowing A determines Y.', 'Write P_b for the conditional joint p(a,y|b) and Q_b for the product p(a|b)p(y|b). In each XOR slice, knowing A determines Y.'),
    ('For p(z)&gt;0, the second line is a weighted average of input-specific label distributions. The denominator matters: it converts the assigned joint mass into a conditional distribution.', 'For p(z)&gt;0, the last line is a weighted average of input-specific label distributions. The denominator in p(x|z) matters: it converts the assigned joint mass into the conditional weights used by that average.'),
    ('Prefer common codewords, but penalize predictive mismatch.', 'Prefer common codewords, but penalize predictive mismatch. Form unnormalized assignment weights a_z(x), then divide by their sum over codewords.'),
    ('C is the decoder’s expected cross-entropy.', 'C is the decoder’s expected cross-entropy, and G_s names its nonnegative conditional KL gap.'),
    ('The pathwise derivative from Variational Inference lets gradients pass through μ and σ while holding the sampled ε fixed.', 'The pathwise derivative from Variational Inference lets gradients pass through μ and σ while holding the sampled ε fixed. For one fixed input, abbreviate μ_j=μ_j(x) and v_j=σ_j(x)² in the KL formula below.'),
]
for old, new in changes:
    assert text.count(old) == 1, old
    text = text.replace(old, new)
path.write_text(text, encoding='utf8')
