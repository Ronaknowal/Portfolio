const fs = require('node:fs');
const bodyPath = 'src/learn/data/topics/second-order-methods-l-bfgs-k-fac-shampoo-natural-gradient.jsx';
let body = fs.readFileSync(bodyPath, 'utf8');
body = body.replace('5-factor-a-layers-fisher-information', '5-factor-a-layer-s-fisher-information');
fs.writeFileSync(bodyPath, body);
const labPath = 'src/learn/components/lesson-labs/SecondOrderMethodsLabs.jsx';
let source = fs.readFileSync(labPath, 'utf8');
if (source.includes('const formatProbability')) throw new Error('Probability repair already applied.');
const marker = 'function Range({';
source = source.replace(marker, 'const formatProbability = value => value < 1 && value > 0.9999 ? `1 − ${format(1 - value)}` : format(value);\n' + marker);
source = source.replace('{label}: p={format(value)}', '{label}: p={formatProbability(value)}')
  .replace('success probability ${format(value)}, failure probability ${format(1 - value)}', 'success probability ${formatProbability(value)}, failure probability ${formatProbability(1 - value)}')
  .replace('success {format(value)} · failure {format(1 - value)}', 'success {formatProbability(value)} · failure {formatProbability(1 - value)}')
  .replace('Gold denotes success and blue failure; text gives both masses.', 'Gold denotes success and blue failure; text gives both masses. Numerical readouts are rounded; an interior probability near one is written as one minus its small remaining failure mass.');
// Avoid placing the start label partly outside the fixed geometry viewBox.
source = source.replace('<text x="242" y="64">start (1,1)</text>', '<text x="242" y="64" textAnchor="end">start (1,1)</text>');
fs.writeFileSync(labPath, source);
console.log('Repaired the section anchor, near-one probability labels and plot-label alignment.');
