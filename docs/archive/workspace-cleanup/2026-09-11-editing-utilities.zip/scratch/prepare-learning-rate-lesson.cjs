const fs = require('node:fs');
const { parse } = require('@babel/parser');
const generate = require('@babel/generator').default;
const bodySource = fs.readFileSync('scratch/learning-rate-schedule-lesson.jsx', 'utf8');
const bodyAst = parse(bodySource, { sourceType: 'module', plugins: ['jsx'] });
function cleanText(node, preserve = false) {
  if (!node || typeof node !== 'object') return;
  const element = node.type === 'JSXElement' ? node.openingElement.name.name : null;
  const skip = preserve || ['Code', 'CodeBlock'].includes(element);
  if (node.type === 'JSXText') {
    if (!skip) node.value = node.value.replace(/([A-Za-z])(?=\d)/g, '$1 ');
    node.extra = { raw: node.value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('{', '&#123;').replaceAll('}', '&#125;'), rawValue: node.value };
  }
  for (const [key, child] of Object.entries(node)) {
    if (['extra', 'loc', 'start', 'end'].includes(key)) continue;
    if (Array.isArray(child)) child.forEach(item => cleanText(item, skip));
    else if (child && typeof child === 'object') cleanText(child, skip);
  }
}
cleanText(bodyAst);
const output = generate(bodyAst, { comments: true }).code + '\n';
parse(output, { sourceType: 'module', plugins: ['jsx'] });
fs.writeFileSync('src/learn/data/topics/learning-rate-schedules-cosine-warmup-onecyclelr.jsx', output);
for (const filename of ['src/learn/components/lesson-labs/LearningRateScheduleLabs.jsx', 'src/learn/data/learning-rate-schedule-models.js']) {
  const ast = parse(fs.readFileSync(filename, 'utf8'), { sourceType: 'module', plugins: ['jsx'] });
  cleanText(ast, true);
  const formatted = generate(ast, { comments: true }).code + '\n';
  parse(formatted, { sourceType: 'module', plugins: ['jsx'] });
  fs.writeFileSync(filename, formatted);
}
console.log('Complete schedules source parsed, text/code boundaries preserved and draft published for browser review.');
