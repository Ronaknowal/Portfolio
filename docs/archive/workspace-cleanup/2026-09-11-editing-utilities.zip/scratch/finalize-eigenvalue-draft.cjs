const fs = require('node:fs');
const { parse } = require('@babel/parser');
const draft = 'scratch/eigenvalue-authoring/lesson-draft.jsx';
let source = fs.readFileSync(draft, 'utf8');
const ast = parse(source, { sourceType: 'module', plugins: ['jsx'] });
const edits = [];
function visit(node) {
  if (!node || typeof node !== 'object') return;
  if (node.type === 'JSXText') {
    const original = source.slice(node.start, node.end);
    const updated = original.replace(/([a-z]{2,})(?=[0-9\[])/g, '$1 ').replace(/\b(NumPy)(?=\d)/g, '$1 ').replace(/\b1kg\b/g, '1 kg').replace(/\b1N\/m\b/g, '1 N/m');
    if (original !== updated) edits.push({ start: node.start, end: node.end, updated });
  }
  for (const value of Object.values(node)) {
    if (Array.isArray(value)) value.forEach(visit);
    else if (value && typeof value === 'object') visit(value);
  }
}
visit(ast);
for (const edit of edits.sort((left, right) => right.start - left.start)) source = source.slice(0, edit.start) + edit.updated + source.slice(edit.end);
source = source.replace("['MIT Markov matrices notes:", "['Stanford linear systems: eigenbases and the strict discrete-time stability criterion', 'https://ee263.stanford.edu/archive/eig.pdf'],\n      ['MIT Markov matrices notes:");
parse(source, { sourceType: 'module', plugins: ['jsx'] });
fs.writeFileSync('src/learn/data/topics/eigenvalues-eigenvectors.jsx', source);
const labs = 'src/learn/components/lesson-labs/EigenvalueLabs.jsx';
fs.writeFileSync(labs, fs.readFileSync(labs, 'utf8').replace('20% goes to B →', '20% moves to compartment B').replace('← 30% goes to A', '30% moves to compartment A'));
console.log('Published complete parseable Eigenvalues draft; clarified prose spacing and responsive mixing destinations.');
