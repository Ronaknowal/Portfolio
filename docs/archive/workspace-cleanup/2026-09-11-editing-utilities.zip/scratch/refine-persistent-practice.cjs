const fs=require('fs'),assert=require('node:assert/strict');const file='src/learn/data/topics/persistent-data-structures-structural-sharing-versioned-queries.jsx';let source=fs.readFileSync(file,'utf8');let count=0;source=source.replace(/<Checkpoint prompt="([1-8]\. [^"]*)"><details><summary>Hint<\/summary>(.*?)<\/details>(.*?)<\/Checkpoint>/g,(_,prompt,hint,solution)=>{count++;return `<PracticeTask prompt="${prompt}" hint={${hint}}>${solution}</PracticeTask>`});assert.equal(count,8);source=source.replace('export default {',`function PracticeTask({ prompt, hint, children }) {
  return <div className="lesson-check persistent-practice-task">
    <p><strong>Try it independently.</strong> {prompt}</p>
    <details><summary>Hint</summary>{hint}</details>
    <details><summary>Show explained solution</summary>{children}</details>
  </div>;
}

export default {`);require('@babel/parser').parse(source,{sourceType:'module',plugins:['jsx']});fs.writeFileSync(file,source);console.log('Eight practice tasks now keep hints separate from solutions; prose preserved')
