const fs=require('node:fs'),assert=require('node:assert/strict'),{createHash}=require('node:crypto');
const read=file=>JSON.parse(fs.readFileSync(file)),hash=file=>createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const evidence='docs/teaching/evidence/';
const definitions=[
 ['f-divergences-integral-probability-metrics','F-DIVERGENCES-IPMS',Object.fromEntries(read(evidence+'f-divergences-ipms-verification.json').sourceHashes.map(row=>[row.file,row.sha256]))],
 ['graph-fundamentals-adjacency-laplacian-connectivity','GRAPH-FUNDAMENTALS',read(evidence+'graph-fundamentals-author-review.json').productionHashes],
 ['spectral-graph-theory','SPECTRAL-GRAPH-THEORY',read(evidence+'spectral-graph-author-review.json').productionHashes],
 ['combinatorial-optimization-approximation-algorithms','COMBINATORIAL-OPTIMIZATION',read(evidence+'combinatorial-optimization-author-review.json').files],
];
const ledgerPath='docs/teaching/dsa-math-foundations-progress.json',ledger=read(ledgerPath);
for(const[id,name,files]of definitions){
 for(const[file,expected]of Object.entries(files))assert.equal(hash(file),expected,file);
 assert(fs.existsSync('docs/teaching/'+name+'-VERIFICATION.md'));
 const topic=ledger.topics.find(row=>row.id===id);assert.equal(topic.status,'in-progress',id);
 Object.assign(topic,{status:'author-verified',verificationRecord:'docs/teaching/'+name+'-VERIFICATION.md',reviewedFiles:files,reviewedSourceSha256:files['src/learn/data/topics/'+id+'.jsx']});
}
const loadPath='scripts/verify-learning-load-boundaries.cjs',source=fs.readFileSync(loadPath,'utf8');
assert(definitions.every(([id])=>!source.includes("'"+id+"'")));
fs.writeFileSync(loadPath,source.replace('const mathematicsLessons = [','const mathematicsLessons = ['+definitions.map(([id])=>"'"+id+"'").join(', ')+', '));
fs.writeFileSync(ledgerPath,JSON.stringify(ledger,null,2)+'\n');
console.log('Mathematics29–32 author-verified; integrated count remains45 pending62 actual production loading cases and route checks.');
