const fs = require('node:fs');
const crypto = require('node:crypto');
const file = 'docs/teaching/dsa-math-foundations-progress.json';
const progress = JSON.parse(fs.readFileSync(file, 'utf8'));
const reviewed = [
  { id: 'binary-search-sorting-two-pointer-patterns', stem: 'ordered-pattern', component: 'OrderedPatternLabs', design: 'ORDERED-PATTERNS-LESSON-DESIGN', verification: 'ORDERED-PATTERNS-VERIFICATION', practice: true },
  { id: 'backtracking-divide-and-conquer', stem: 'backtracking-divide', component: 'BacktrackingDivideLabs', design: 'BACKTRACKING-DIVIDE-LESSON-DESIGN', verification: 'BACKTRACKING-DIVIDE-VERIFICATION', practice: true },
  { id: 'eigenvalues-eigenvectors', stem: 'eigenvalue', component: 'EigenvalueLabs', design: 'EIGENVALUES-EIGENVECTORS-DESIGN', verification: 'EIGENVALUES-EIGENVECTORS-VERIFICATION' },
  { id: 'matrix-calculus-jacobians', stem: 'matrix-calculus', component: 'MatrixCalculusLabs', design: 'MATRIX-CALCULUS-JACOBIANS-DESIGN', verification: 'MATRIX-CALCULUS-JACOBIANS-VERIFICATION' },
];
const hash = filename => crypto.createHash('sha256').update(fs.readFileSync(filename)).digest('hex');
for (const topic of reviewed) {
  const entry = progress.topics.find(item => item.id === topic.id);
  if (entry.status !== 'in-progress') throw new Error('Refuse silently refreshing an already reviewed entry: ' + topic.id);
  const paths = [
    `src/learn/data/topics/${topic.id}.jsx`,
    `src/learn/data/${topic.stem}-models.js`,
    `src/learn/data/${topic.stem}-examples.js`,
    `src/learn/components/lesson-labs/${topic.component}.jsx`,
    `src/learn/components/lesson-labs/${topic.stem}-labs.css`,
    `src/learn/data/curriculum/blueprints/${topic.id}.js`,
    ...(topic.practice ? [`src/learn/data/practice/${topic.id}.js`] : []),
  ];
  for (const name of [topic.design, topic.verification]) if (fs.statSync(`docs/teaching/${name}.md`).size < 500) throw new Error('Incomplete evidence ' + name);
  entry.status = 'implementation-reviewed';
  entry.source = `./topics/${topic.id}.jsx`;
  entry.designRecord = `docs/teaching/${topic.design}.md`;
  entry.verificationRecord = `docs/teaching/${topic.verification}.md`;
  entry.reviewedSourceSha256 = hash(paths[0]);
  entry.reviewedFiles = Object.fromEntries(paths.map(filename => [filename, hash(filename)]));
  entry.integrationRecord = 'docs/teaching/DSA-MATH-FOUNDATIONS-INTEGRATION.md';
}
for (const id of ['greedy-algorithms-exchange-arguments', 'dynamic-programming-states-transitions-optimization', 'tensor-algebra-einsum-notation', 'randomized-linear-algebra']) {
  const entry = progress.topics.find(item => item.id === id);
  if (!['pending', 'in-progress'].includes(entry.status)) throw new Error('Unexpected active status');
  entry.status = 'in-progress';
}
progress.topics.find(item => item.id === 'randomized-linear-algebra').designRecord = 'docs/teaching/RANDOMIZED-LINEAR-ALGEBRA-DESIGN.md';
fs.writeFileSync(file, JSON.stringify(progress, null, 2) + '\n');
console.log('Recorded four newly integrated source versions and the next four active topics; prior review hashes and exact74-topic scope preserved.');
