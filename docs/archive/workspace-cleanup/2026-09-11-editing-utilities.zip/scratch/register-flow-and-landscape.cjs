const fs = require('node:fs');
const id = 'network-flow-minimum-cuts-bipartite-matching';
const manifestPath = 'src/learn/data/lesson-manifest.json';
const manifest = JSON.parse(fs.readFileSync(manifestPath));
manifest[id] = `./topics/${id}.jsx`;
fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + '\n');
const indexPath = 'src/learn/data/curriculum/blueprints/index.js';
let index = fs.readFileSync(indexPath, 'utf8');
for (const [stableId, variable, title] of [
  [id, 'networkFlowBlueprint', 'Network Flow, Minimum Cuts & Bipartite Matching'],
  ['non-convex-optimization-landscape', 'nonconvexLandscapeBlueprint', 'Non-Convex Optimization Landscape'],
]) {
  if (!index.includes(variable)) index = `import ${variable} from './${stableId}.js';\n` + index.replace(/};\s*$/, `  "${title}": ${variable},\n};\n`);
}
fs.writeFileSync(indexPath, index);
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(ledgerPath));
const landscape = ledger.topics.find(topic => topic.id === 'non-convex-optimization-landscape');
landscape.status = 'in-progress';
landscape.designRecord = 'docs/teaching/NONCONVEX-LANDSCAPE-DESIGN.md';
const flow = ledger.topics.find(topic => topic.id === id);
flow.designRecord = 'docs/teaching/NETWORK-FLOW-LESSON-DESIGN.md';
fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2) + '\n');
console.log('Registered complete Flow body and Flow/Landscape briefs; both remain in progress.');
