const fs = require('node:fs');
const assert = require('node:assert/strict');
const path = 'src/learn/data/topics/constrained-multi-objective-optimization.jsx';
const old = fs.readFileSync(path, 'utf8');
const before = 'However, ties in the primary objective can still include dominated alternatives. Compare the remaining objectives as secondary criteria, or check the resulting frontier.';
const after = 'With those exact Pareto-target bounds, every tied optimum must match the target on all objectives: any strict improvement would dominate that target. For general chosen bounds, however, primary-objective ties can include dominated alternatives. Compare the remaining objectives as secondary criteria, or check the resulting frontier.';
assert.equal(old.split(before).length, 2);
fs.writeFileSync(path, old.replace(before, after));
console.log('Clarified exact Pareto-target bounds versus general epsilon bounds; no model or example changed.');
