import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parents[1]
path = root / 'docs/teaching/evidence/graph-fundamentals-author-review.json'
record = json.loads(path.read_text(encoding='utf-8'))
example = 'src/learn/data/graph-fundamentals-examples.js'
amendment = {
    'checkedAt': datetime.now(timezone.utc).isoformat(),
    'previousFreeze': record['authorFrozenAt'],
    'previousExamplesHash': record['productionHashes'][example],
    'finding': 'The actual displayed Python normalized_operators helper also needed the same explicit reciprocal-range guard.',
    'repair': 'Import math.isfinite and reject non-finite inverse degrees with ValueError; all eleven program outputs unchanged.',
    'verification': 'Full native/oracle run with actual Python and JS rejected-subnormal and accepted-finite regressions. Targeted original-font browser check at 1440/390/320 verifies the corrected code, unchanged output, preceding question and page bounds; final 320 capture opened.',
}
for name, old in record['productionHashes'].items():
    current = hashlib.sha256((root / name).read_bytes()).hexdigest()
    if name != example:
        assert current == old, name
    record['productionHashes'][name] = current
for name in ['scripts/prepare-graph-fundamentals-examples.py', 'scripts/verify-graph-fundamentals.py', 'scripts/review-graph-normalization-range.cjs']:
    record['verificationSourceHashes'][name] = hashlib.sha256((root / name).read_bytes()).hexdigest()
record['native'] = json.loads((root / 'scratch/graph-fundamentals-native/results.json').read_text(encoding='utf-8'))
record['rangeAmendmentBrowser'] = json.loads((root / 'scratch/graph-fundamentals-browser/range-amendment-results.json').read_text(encoding='utf-8'))
image = 'scratch/graph-fundamentals-browser/normalization-range-amendment-320.png'
record['openedFinalImages'][image] = hashlib.sha256((root / image).read_bytes()).hexdigest()
record['authorFrozenAt'] = amendment['checkedAt']
record['amendments'].append(amendment)
path.write_text(json.dumps(record, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(record['authorFrozenAt'])
