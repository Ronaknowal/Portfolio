from pathlib import Path
import json

root = Path(__file__).resolve().parents[1]
snapshot = json.loads((root / 'docs/teaching/evidence/category-geometry-foundations-integration.json').read_text())
assert snapshot['reviewedScope'] == 62
assert len(snapshot['loading']['results']) == 75

handoff = root / 'LESSON-AUTHORING-HANDOFF.md'
text = handoff.read_text()
text = text.replace('Updated 10 September 2026 for the active goal', 'Updated 11 September 2026 for the active goal', 1)
start = text.index('**Active goal:**')
end = text.index('\n\nThe subsequent engineering pass', start)
text = text[:start] + '**Active goal:** implement all **17 remaining DSA topics and all 57 Mathematical & Statistical Foundations topics**, including review of the 42 previously published maths lessons and completion of its 15 planned topics. Read [the implementation record](DSA-MATH-FOUNDATIONS-IMPLEMENTATION.md) and [exact 74-topic ledger](docs/teaching/dsa-math-foundations-progress.json). **62 scoped topics are implementation-reviewed: all DSA positions 6–22 and mathematics positions 1–45.** Together with the preserved first five DSA lessons, the full 22-topic DSA module has reviewed implementations and guided practice. The latest completed five are Category Theory, Differential Geometry, Algebra/Functions, Sets/Logic and Geometry/Trigonometry. Their final author and independent records match all 30 production fingerprints; production loading and module-order checks are complete. **Twelve mathematics topics remain, positions 46–57.** Counting (46) and Random Variables (48) have indexed designs and are in progress; Single-Variable Calculus (47) is being designed separately and is not promoted by this snapshot. The next reading topic after Geometry remains planned Counting. Publication, author review, integrated review and user acceptance remain separate. The full goal stays active until every scoped topic and required integration check is complete.' + text[end:]
start = text.index('There are **1,218 unique topics,')
end = text.index('\n\n', start)
text = text[:start] + 'There are **1,218 unique topics, 28 modules, seven paths, 216 published lessons, 341 individual briefs and 370 recorded prerequisite reviews** in the latest integrated snapshot. **877 topics still need individual design in that snapshot.** All identities and memberships are conserved. The latest [frozen integration](docs/teaching/evidence/category-geometry-foundations-integration.json) covers **62 reviewed scoped topics and 75 production loading/recovery cases**, including actual route traversal through mathematics 41–45 into planned Counting46. The prior 57-topic snapshot remains unchanged. Subsequent in-progress designs can change the live brief count; the inventory and source-versioned ledger own exact current state.' + text[end:]
handoff.write_text(text)

implementation = root / 'DSA-MATH-FOUNDATIONS-IMPLEMENTATION.md'
text = implementation.read_text()
start = text.index('**57 of the 74 scoped topics')
end = text.index('\n\nThe ledger records', start)
text = text[:start] + '**62 of the 74 scoped topics are implementation-reviewed: every remaining DSA topic (positions 6–22) and mathematics positions 1–45.** Each has individual design, complete source, native/model evidence, actual desktop/mobile/keyboard review and integrated loading/navigation verification. The preserved first five DSA lessons complete the 22-topic module. [Integrated evidence](docs/teaching/DSA-MATH-FOUNDATIONS-INTEGRATION.md) records the latest 216-publication snapshot, 75 production loading/recovery cases and module-boundary/progress checks. User acceptance remains pending.\n\n**Twelve mathematics topics remain, positions 46–57.** The latest five completed topics are Category Theory (41), Differential Geometry (42), Algebra/Functions/Exponentials/Logarithms (43), Sets/Logic/Relations/Proofs (44), and Geometry/Trigonometry (45). All 30 owned production hashes match their final author and independent reviews. The preceding 57 reviewed topics retain all 363 frozen file hashes. Counting (46) and Random Variables (48) have indexed designs and are in progress; Single-Variable Calculus (47) is being designed separately. The next actual reading entry is planned Counting, not a later published lesson. Registration, inventory and integration remain centrally coordinated. A new publication is registered only after its body is complete; a published mapping does not certify an unfinished rewrite.' + text[end:]
implementation.write_text(text)

integration = root / 'docs/teaching/DSA-MATH-FOUNDATIONS-INTEGRATION.md'
text = integration.read_text()
assert '## Category and geometry foundations integration' not in text
loading_time = snapshot['loading']['measuredAt']
routing_time = snapshot['routingFinishedAt']
section = f'''## Category and geometry foundations integration — mathematics 41–45

The [new frozen production snapshot](evidence/category-geometry-foundations-integration.json), integrated at **{snapshot['integratedAt']}**, raises the scoped total to **62 of 74 implementation-reviewed topics**: all 17 remaining DSA topics and mathematics positions 1–45. The preserved first five DSA lessons complete the 22-topic module. **Twelve mathematics topics remain.** The preceding [57-topic snapshot](evidence/calculus-analysis-topology-integration.json) is unchanged, and every one of its 363 reviewed file hashes was checked before promotion.

Category Theory, Differential Geometry, Algebra/Functions, Sets/Logic and Geometry/Trigonometry now have complete topic-specific teaching, native programs, visual investigations, independent changed practice and annotated primary/alternate resources. Their authors executed 54 complete programs in total; the two existing lessons preserve their original programs, while Algebra, Sets/Logic and Geometry were previously planned entries. Counts describe this increment and do not set future quotas. Separate independent reviews read the actual final teaching/proofs, checked complementary cases and inspected actual images. All **30 final production hashes** agree among author records, independent records, ledger and current files.

- Final review repairs are retained with their original evidence: Category's positive-evidence HTML entity, Algebra's additive curve on a logarithmic axis, and Sets/Logic's sparse-array validation. Geometry's earlier/later link wording and responsive arc-scale caption were corrected before its freeze. Differential Geometry passed complementary map, transport, metric, covariance and stationary-point checks without another source edit. The final records distinguish full runs from focused amendments.
- The production build passed in **{snapshot['buildSeconds']:.2f} seconds** after every final source revision. Curriculum and artifact checks preserve **1,218 topic identities, 28 modules, 216 distinct publication mappings, 257 separate planned outlines and seven paths**. This snapshot has **341 individual briefs and 370 recorded prerequisite reviews**. No draft body was added during integration, and unregistered drafts remain excluded from the production entry graph.
- **75 production loading/recovery cases passed at {loading_time}** against `http://127.0.0.1:4173`: all 22 DSA and 45 reviewed mathematics bodies load only their selected body and actual dependencies, plus the eight hub/outline/math/cache/stale/import/render cases. The known browser module-cache failure still requires the explicit reload fallback; that recovery passed. These are local dependency observations, not universal performance guarantees.
- Production route review finished at **{routing_time}**, using `LEARNING_BASE_URL=http://127.0.0.1:4173`. At **1440/390**, all 17 programming steps, seven path entries/counts, all 22 UI-driven DSA completion actions and **five UI-driven mathematics 41–45 completion actions** pass. Previous/Next and module positions stay in catalogue order through **planned Counting46**, whose completion remains disabled. Marking complete does not silently advance. Shared module context, shared progress, prerequisite links and planned resume remain valid. The separate Deep Learning prefix is seeded only in isolated fixture storage and is not counted as UI completion actions.
- The source-boundary check inspected **{snapshot['sourceBoundary']['sourceFilesScanned']} source files and {snapshot['sourceBoundary']['directMathImports']} direct math consumers**, including unregistered drafts, with no eager generic KaTeX import. Runtime organization checks retain 66 original exports, 62 migration modules and 29 retired production names. The new integration script verifies the complete reviewed file set before promoting only these five lessons.

Reproduction and raw logs are identified by [the integration script](../../scripts/integrate-category-geometry-foundations-reviews.cjs) and its source-versioned JSON. The earlier Bayesian Networks raw-greater-than JSX warning and shared-navigation chunk-size warning remain visible; no warning threshold was raised and no teaching content was reduced. User acceptance and observed learning outcomes remain separate. The full 74-topic goal stays active.

'''
first_break = text.index('\n\n') + 2
integration.write_text(text[:first_break] + section + text[first_break:])
print('Updated handoff, active implementation summary and new integration section; historical snapshots/sections preserved.')
