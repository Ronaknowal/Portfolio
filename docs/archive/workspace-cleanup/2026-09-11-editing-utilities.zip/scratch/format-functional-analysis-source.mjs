import fs from 'node:fs';
import { parse } from '@babel/parser';
import generatorModule from '@babel/generator';
const generate = generatorModule.default || generatorModule;
const files = ['src/learn/data/topics/functional-analysis-rkhs.jsx', 'src/learn/components/lesson-labs/FunctionalAnalysisLabs.jsx'];
function readable(text) {
  return text.replace(/\b(Python|NumPy|SciPy)(?=\d)/g, '$1 ')
    .replace(/\b([A-Za-z]{3,})(?=\d|[√−]|\.\d)/g, '$1 ')
    .replace(/\b(on|at|from|through|is|are|by|gives|of|and|both|than|before|after|width|height|weight|energy|norm|norms|targets|gamma|lambda|pair|matrix|kernel|probability|mass|length|size|section|sections|lecture|pattern|approximately|divides|multiplies|contribution|every|only|below|above|equal|mean|means|mode|coordinate|constant|feature|coefficients|coefficient|rank|value|values|counts|slope|slopes|entries|observations)(?=\d|[\[(−]|\.\d)/gi, '$1 ')
    .replace(/at most(?=\d)/g, 'at most ').replace(/gives(?=Σ)/g, 'gives ')
    .replace(/\b(to|by|weights)(?=\d|[√(])/g, '$1 ')
    .replace(/matrix’s(?=\.\d)/g, 'matrix’s ')
    .replace(/its(?=\d)/g, 'its ');
}
let changed = 0;
for (const file of files) {
  const ast = parse(fs.readFileSync(file,'utf8'), { sourceType:'module', plugins:['jsx'] });
  function visit(node, parent) {
    if (!node || typeof node !== 'object') return;
    if (node.type === 'JSXText' && !['Code','MathBlock'].includes(parent?.openingElement?.name?.name)) {
      const next = readable(node.value); if (next !== node.value) changed += 1; node.value = next;
      node.extra = { rawValue: next, raw: next.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;') };
    }
    if (node.type === 'JSXAttribute' && ['question','hint','title','aria-label','prerequisites'].includes(node.name.name) && node.value?.type==='StringLiteral') {
      const next = readable(node.value.value); if (next !== node.value.value) changed += 1;
      node.value.value = next; delete node.value.extra;
    }
    if (node.type === 'StringLiteral' && /\s/.test(node.value)) {
      const next = readable(node.value); if (next !== node.value) changed += 1;
      node.value = next; delete node.extra;
    }
    for (const [key,value] of Object.entries(node)) if (!['loc','start','end','extra'].includes(key)) {
      if (Array.isArray(value)) value.forEach(child=>visit(child,node)); else if (value && typeof value==='object') visit(value,node);
    }
  }
  visit(ast,null);
  fs.writeFileSync(file,generate(ast,{jsescOption:{minimal:true}}).code+'\n');
}
console.log('Readable prose joins repaired:',changed);
// Formatting only for the pure model; compare normalized semantic ASTs.
const file = 'src/learn/data/functional-analysis-models.js';
const ast = parse(fs.readFileSync(file,'utf8'),{sourceType:'module'});
const output = generate(ast,{jsescOption:{minimal:true}}).code+'\n';
const normalize = value => JSON.stringify(value,(key,item)=>['start','end','loc','extra','comments','leadingComments','trailingComments','innerComments'].includes(key)?undefined:item);
if (normalize(ast)!==normalize(parse(output,{sourceType:'module'}))) throw Error('Model formatting changed AST');
fs.writeFileSync(file,output);
