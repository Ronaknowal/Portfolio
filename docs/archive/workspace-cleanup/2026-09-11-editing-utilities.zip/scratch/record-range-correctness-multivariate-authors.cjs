const fs = require('node:fs');
const { createHash } = require('node:crypto');
const file = 'docs/teaching/dsa-math-foundations-progress.json';
const progress = JSON.parse(fs.readFileSync(file));
const manifest = JSON.parse(fs.readFileSync('src/learn/data/lesson-manifest.json'));
const hash = source => createHash('sha256').update(fs.readFileSync(source)).digest('hex');
const reviewed = [
  {
    id: 'multivariate-calculus-gradients',
    design: 'docs/teaching/MULTIVARIATE-CALCULUS-GRADIENTS-DESIGN.md',
    verification: 'docs/teaching/MULTIVARIATE-CALCULUS-GRADIENTS-VERIFICATION.md',
    files: ['src/learn/data/multivariate-calculus-models.js', 'src/learn/data/multivariate-calculus-examples.js', 'src/learn/components/lesson-labs/MultivariateCalculusLabs.jsx', 'src/learn/components/lesson-labs/multivariate-calculus-labs.css'],
  },
  {
    id: 'segment-trees-fenwick-trees-range-queries',
    design: 'docs/teaching/RANGE-QUERIES-LESSON-DESIGN.md',
    verification: 'docs/teaching/RANGE-QUERIES-VERIFICATION.md',
    files: ['src/learn/data/range-query-models.js', 'src/learn/data/range-deque-models.js', 'src/learn/data/range-query-examples.js', 'src/learn/components/lesson-labs/RangeQueryLabs.jsx', 'src/learn/components/lesson-labs/RangeDequeLabs.jsx', 'src/learn/components/lesson-labs/range-query-labs.css', 'src/learn/data/practice/segment-trees-fenwick-trees-range-queries.js'],
  },
];
for (const record of reviewed) {
  const entry = progress.topics.find(topic => topic.id === record.id);
  if (entry.status !== 'in-progress') throw new Error(`Unexpected status for ${record.id}: ${entry.status}`);
  const source = 'src/learn/data/' + manifest[record.id].slice(2);
  const files = [source, ...record.files, `src/learn/data/curriculum/blueprints/${record.id}.js`];
  Object.assign(entry, { status: 'author-verified', source: manifest[record.id], designRecord: record.design, verificationRecord: record.verification, reviewedSourceSha256: hash(source), reviewedFiles: Object.fromEntries(files.map(source => [source, hash(source)])) });
}
for (const [id, design] of [
  ['gradient-descent-variants-sgd-adam-adagrad-rmsprop-lamb-lars', 'docs/teaching/GRADIENT-DESCENT-VARIANTS-DESIGN.md'],
  ['shortest-paths-spanning-trees-topological-ordering', 'docs/teaching/WEIGHTED-GRAPHS-LESSON-DESIGN.md'],
  ['hashing-collision-resolution-amortized-analysis', 'docs/teaching/HASHING-AMORTIZED-LESSON-DESIGN.md'],
]) {
  const entry = progress.topics.find(topic => topic.id === id);
  Object.assign(entry, { status: 'in-progress', designRecord: design });
  if (manifest[id]) entry.source = manifest[id];
}
fs.writeFileSync(file, JSON.stringify(progress, null, 2) + '\n');
console.log('Range and Multivariate author checks recorded; Correctness preserved. Three next-topic assignments recorded.');
