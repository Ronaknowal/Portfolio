const fs = require('node:fs');
const assert = require('node:assert/strict');
const { parse } = require('@babel/parser');
const generate = require('@babel/generator').default;
const files = [
  'src/learn/data/matrix-decomposition-models.js',
  'src/learn/components/lesson-labs/MatrixDecompositionLabs.jsx',
  'src/learn/data/topics/matrix-decompositions-svd-qr-cholesky-lu.jsx',
  'src/learn/data/curriculum/blueprints/matrix-decompositions-svd-qr-cholesky-lu.js',
];
function normalize(value) {
  if (Array.isArray(value)) return value.map(normalize);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value)
    .filter(([key]) => !['start', 'end', 'loc', 'extra', 'errors'].includes(key))
    .map(([key, child]) => [key, normalize(child)]));
}
fs.mkdirSync('scratch/matrix-decomposition-format-baseline', { recursive: true });
for (const file of files) {
  const before = fs.readFileSync(file, 'utf8');
  const ast = parse(before, { sourceType: 'module', plugins: ['jsx'] });
  const after = generate(ast, { comments: true, compact: false, jsescOption: { minimal: true } }, before).code + '\n';
  assert.deepEqual(normalize(parse(after, { sourceType: 'module', plugins: ['jsx'] })), normalize(ast));
  fs.writeFileSync('scratch/matrix-decomposition-format-baseline/' + file.replaceAll('/', '__'), before);
  fs.writeFileSync(file, after);
}
console.log('Formatted four Matrix Decomposition sources with unchanged normalized AST, comments and strings.');

