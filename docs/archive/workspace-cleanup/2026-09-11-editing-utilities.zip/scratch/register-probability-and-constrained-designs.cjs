const fs = require('node:fs');
const indexPath = 'src/learn/data/curriculum/blueprints/index.js';
let index = fs.readFileSync(indexPath, 'utf8');
for (const [id, variable, title] of [
  ['probability-distributions-bayes-theorem', 'probabilityDistributionsBlueprint', "Probability Distributions & Bayes' Theorem"],
  ['constrained-multi-objective-optimization', 'constrainedMultiobjectiveBlueprint', 'Constrained & Multi-Objective Optimization'],
]) {
  if (!index.includes(variable)) index = `import ${variable} from './${id}.js';\n` + index.replace(/};\s*$/, `  ${JSON.stringify(title)}: ${variable},\n};\n`);
}
fs.writeFileSync(indexPath, index);
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(ledgerPath));
const topic = ledger.topics.find(entry => entry.id === 'probability-distributions-bayes-theorem');
topic.status = 'in-progress';
topic.designRecord = 'docs/teaching/PROBABILITY-DISTRIBUTIONS-BAYES-DESIGN.md';
fs.writeFileSync(ledgerPath, JSON.stringify(ledger, null, 2) + '\n');
console.log('Two actual topic designs registered; neither grants new reviewed status.');
