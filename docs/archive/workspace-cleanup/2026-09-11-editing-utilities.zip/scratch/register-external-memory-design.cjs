const fs = require('node:fs');
const indexPath = 'src/learn/data/curriculum/blueprints/index.js';
let index = fs.readFileSync(indexPath, 'utf8');
const variable = 'externalMemoryBlueprint';
if (!index.includes(variable)) {
  index = "import externalMemoryBlueprint from './external-memory-algorithms-b-trees-i-o-complexity.js';\n" + index.replace(/};\s*$/, '  "External-Memory Algorithms, B-Trees & I/O Complexity": externalMemoryBlueprint,\n};\n');
}
fs.writeFileSync(indexPath, index);
const path = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = JSON.parse(fs.readFileSync(path));
const entry = ledger.topics.find(topic => topic.id === 'external-memory-algorithms-b-trees-i-o-complexity');
entry.status = 'in-progress';
entry.designRecord = 'docs/teaching/EXTERNAL-MEMORY-LESSON-DESIGN.md';
fs.writeFileSync(path, JSON.stringify(ledger, null, 2) + '\n');
console.log('External-Memory design registered; no new publication or reviewed claim.');
