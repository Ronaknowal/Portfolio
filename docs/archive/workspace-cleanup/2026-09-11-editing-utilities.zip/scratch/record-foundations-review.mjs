import fs from 'node:fs';
import { createHash } from 'node:crypto';
const progressPath = 'docs/teaching/dsa-math-foundations-progress.json';
const progress = JSON.parse(fs.readFileSync(progressPath));
const manifest = JSON.parse(fs.readFileSync('src/learn/data/lesson-manifest.json'));
const records = [
  ['vectors-matrices-tensor-operations', 'vector-tensor', 'VectorTensorLabs', 'VECTORS-MATRICES-TENSORS-DESIGN', 'VECTORS-MATRICES-TENSORS-VERIFICATION'],
  ['matrix-decompositions-svd-qr-cholesky-lu', 'matrix-decomposition', 'MatrixDecompositionLabs', 'MATRIX-DECOMPOSITIONS-LESSON-DESIGN', 'MATRIX-DECOMPOSITIONS-VERIFICATION'],
  ['disjoint-sets-union-find', 'union-find', 'UnionFindLabs', 'UNION-FIND-LESSON-DESIGN', 'UNION-FIND-VERIFICATION'],
  ['complexity-analysis-recursion', 'complexity-recursion', 'ComplexityRecursionLabs', 'COMPLEXITY-RECURSION-LESSON-DESIGN', 'COMPLEXITY-RECURSION-VERIFICATION'],
];
const hash = filename => createHash('sha256').update(fs.readFileSync(filename)).digest('hex');
for (const [id, prefix, component, design, verification] of records) {
  const topic = progress.topics.find(item => item.id === id);
  const files = [`src/learn/data/topics/${id}.jsx`, `src/learn/data/${prefix}-models.js`,
    `src/learn/data/${prefix}-examples.js`, `src/learn/components/lesson-labs/${component}.jsx`,
    `src/learn/components/lesson-labs/${prefix}-labs.css`, `src/learn/data/curriculum/blueprints/${id}.js`];
  if (topic.moduleId === 'data-structures-algorithms') files.push(`src/learn/data/practice/${id}.js`);
  Object.assign(topic, { source: manifest[id], status: 'implementation-reviewed',
    designRecord: `docs/teaching/${design}.md`, verificationRecord: `docs/teaching/${verification}.md`,
    integrationRecord: 'docs/teaching/DSA-MATH-FOUNDATIONS-INTEGRATION.md',
    reviewedSourceSha256: hash(files[0]), reviewedFiles: Object.fromEntries(files.map(filename => [filename, hash(filename)])) });
}
fs.writeFileSync(progressPath, JSON.stringify(progress, null, 2) + '\n');
console.log('Recorded four completed author/native/browser/integration reviews; 70 scoped topics still require final review.');
