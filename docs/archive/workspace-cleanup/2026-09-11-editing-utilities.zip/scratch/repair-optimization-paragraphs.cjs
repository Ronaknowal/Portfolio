const fs = require('node:fs');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const parser = require('@babel/parser');
const output = 'scratch/optimization-paragraph-repair';
fs.mkdirSync(output, { recursive: true });
const files = [
  'src/learn/data/topics/non-convex-optimization-landscape.jsx',
  'src/learn/data/topics/constrained-multi-objective-optimization.jsx',
];
function walk(node, visit) {
  if (!node || typeof node !== 'object') return;
  if (Array.isArray(node)) { node.forEach(child => walk(child, visit)); return; }
  visit(node);
  Object.entries(node).filter(([key]) => !['loc', 'extra'].includes(key)).forEach(([, value]) => walk(value, visit));
}
function normalized(node) {
  if (Array.isArray(node)) return node.map(normalized);
  if (!node || typeof node !== 'object') return node;
  return Object.fromEntries(Object.entries(node).filter(([key]) => !['start', 'end', 'loc', 'extra', 'tokens'].includes(key)).map(([key, value]) => [key, normalized(value)]));
}
function tag(node, name) { return node?.type === 'JSXElement' && node.openingElement.name.type === 'JSXIdentifier' && node.openingElement.name.name === name; }
const results = [];
for (const file of files) {
  const source = fs.readFileSync(file, 'utf8');
  fs.writeFileSync(`${output}/${file.split('/').at(-1)}.before`, source);
  const ast = parser.parse(source, { sourceType: 'module', plugins: ['jsx'] });
  const edits = [];
  let groups = 0, paragraphs = 0;
  walk(ast, node => {
    if (!tag(node, 'Prose') || !node.children.some(child => tag(child, 'p'))) return;
    assert.equal(node.openingElement.attributes.length, 0);
    assert(node.children.every(child => tag(child, 'p') || (child.type === 'JSXText' && !child.value.trim())));
    groups++;
    edits.push([node.openingElement.start, node.openingElement.end, '<>'], [node.closingElement.start, node.closingElement.end, '</>']);
    for (const child of node.children) {
      if (!tag(child, 'p')) continue;
      assert.equal(child.openingElement.attributes.length, 0);
      paragraphs++;
      edits.push([child.openingElement.start, child.openingElement.end, '<Prose>'], [child.closingElement.start, child.closingElement.end, '</Prose>']);
      child.openingElement.name.name = 'Prose';
      child.closingElement.name.name = 'Prose';
    }
    node.type = 'JSXFragment';
    node.openingFragment = { type: 'JSXOpeningFragment' };
    node.closingFragment = { type: 'JSXClosingFragment' };
    delete node.openingElement;
    delete node.closingElement;
  });
  let revised = source;
  for (const [start, end, replacement] of edits.sort((a, b) => b[0] - a[0])) revised = revised.slice(0, start) + replacement + revised.slice(end);
  const parsed = parser.parse(revised, { sourceType: 'module', plugins: ['jsx'] });
  assert.deepEqual(normalized(parsed), normalized(ast), 'Only the specified wrapper/paragraph tags change; all text, inline elements, expressions and other AST remain identical.');
  let remaining = 0;
  walk(parsed, node => {
    if (tag(node, 'Prose')) walk(node.children, child => { if (tag(child, 'p') || tag(child, 'Prose')) remaining++; });
  });
  assert.equal(remaining, 0);
  assert(groups > 0 && paragraphs >= groups);
  fs.writeFileSync(file, revised);
  results.push({ file, groups, paragraphs, remainingNestedParagraphs: remaining, beforeHash: crypto.createHash('sha256').update(source).digest('hex'), afterHash: crypto.createHash('sha256').update(revised).digest('hex'), normalizedAstEqualsTagOnlyTransformation: true });
}
fs.writeFileSync(`${output}/source-results.json`, JSON.stringify({ at: new Date().toISOString(), results }, null, 2));
console.log(results);
