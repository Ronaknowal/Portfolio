import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { secondOrderMethodsExamples as before } from '../src/learn/data/second-order-methods-examples.js';
const entries = Object.entries(before).map(([name, example]) => {
  assert.match(name, /^[A-Za-z][A-Za-z0-9]*$/);
  assert.ok(!example.code.includes('`') && !example.code.includes('${'));
  return `  ${name}: {\n    title: ${JSON.stringify(example.title)},\n    code: String.raw\`${example.code}\`,\n    expected: ${JSON.stringify(example.expected)},\n  },`;
});
writeFileSync('src/learn/data/second-order-methods-examples.js', '// Complete independently runnable Python programs; native runtime versions are in the lesson.\nexport const secondOrderMethodsExamples = {\n' + entries.join('\n') + '\n};\n');
const { secondOrderMethodsExamples: after } = await import('../src/learn/data/second-order-methods-examples.js?formatted=1');
assert.deepEqual(after, before);
writeFileSync('scratch/second-order-review/native/format-equivalence.json', JSON.stringify({ checkedAt: new Date().toISOString(), status: 'passed', examples: entries.length, contract: 'All titles, complete code strings and expected stdout exactly unchanged.' }, null, 2) + '\n');
console.log('Nine example records preserved exactly in readable multiline source.');
