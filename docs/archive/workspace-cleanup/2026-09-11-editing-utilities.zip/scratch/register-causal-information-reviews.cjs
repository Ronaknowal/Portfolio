const fs = require('node:fs');
const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const read = file => JSON.parse(fs.readFileSync(file));
const hash = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const save = (file, value) => fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n');
const evidence = 'docs/teaching/evidence/';
const entropy = read('scratch/entropy-verification/final-source-hashes.json');
const definitions = [
  ['causal-inference-do-calculus', 'CAUSAL-INFERENCE', Object.fromEntries(read(evidence + 'causal-inference-author-review.json').sourceFiles.filter(row => row.path.startsWith('src/')).map(row => [row.path, row.sha256]))],
  ['entropy-cross-entropy-kl-divergence', 'ENTROPY-CROSS-ENTROPY-KL', Object.fromEntries(entropy.files.map(row => [row.file, row.sha256]))],
  ['mutual-information-information-bottleneck', 'MUTUAL-INFORMATION', Object.fromEntries(read(evidence + 'mutual-information-verification.json').source.map(row => [row.path, row.sha256]))],
  ['rate-distortion-theory', 'RATE-DISTORTION', read(evidence + 'rate-distortion-author-review.json').files],
];
const ledgerPath = 'docs/teaching/dsa-math-foundations-progress.json';
const ledger = read(ledgerPath);
for (const [id, name, files] of definitions) {
  for (const [file, expected] of Object.entries(files)) assert.equal(hash(file), expected, file);
  assert(fs.existsSync('docs/teaching/' + name + '-VERIFICATION.md'));
  const topic = ledger.topics.find(row => row.id === id);
  assert.equal(topic.status, 'in-progress', id);
  Object.assign(topic, {
    status: 'author-verified', verificationRecord: 'docs/teaching/' + name + '-VERIFICATION.md',
    reviewedFiles: files, reviewedSourceSha256: files['src/learn/data/topics/' + id + '.jsx'],
  });
}
save(evidence + 'entropy-author-review.json', {
  frozenAt: entropy.timestamp, files: definitions[1][2], originalAuthorFreeze: entropy.previousFreeze,
  native: read('scratch/entropy-verification/native-results.json'),
  browser: read('scratch/entropy-browser/results.json'),
  numericalBrowser: read('scratch/entropy-browser/numeric-boundary-results.json'),
  finalPipeline: read('scratch/entropy-browser/pipeline-polish-results.json'),
  independentReview: 'docs/teaching/ENTROPY-INDEPENDENT-REVIEW.md',
});
const loadPath = 'scripts/verify-learning-load-boundaries.cjs';
const source = fs.readFileSync(loadPath, 'utf8');
assert(definitions.every(([id]) => !source.includes("'" + id + "'")));
fs.writeFileSync(loadPath, source.replace('const mathematicsLessons = [', 'const mathematicsLessons = [' + definitions.map(([id]) => "'" + id + "'").join(', ') + ', '));
save(ledgerPath, ledger);
console.log('Mathematics25–28 author-verified; production loading scope now58 cases. Integrated status remains41 until actual checks pass.');
