const fs = require('node:fs');
const parser = require('@babel/parser');
const generate = require('@babel/generator').default;
for (const file of ['src/learn/data/greedy-exchange-models.js', 'src/learn/components/lesson-labs/GreedyExchangeLabs.jsx']) {
  const original = fs.readFileSync(file, 'utf8');
  const ast = parser.parse(original, { sourceType: 'module', plugins: ['jsx'] });
  const formatted = generate(ast, { comments: true, jsescOption: { minimal: true } }, original).code + '\n';
  const reparsed = parser.parse(formatted, { sourceType: 'module', plugins: ['jsx'] });
  if (generate(ast, { compact: true }).code !== generate(reparsed, { compact: true }).code) throw new Error(`Formatting changed syntax in ${file}`);
  fs.writeFileSync(file, formatted);
  console.log(`Formatted with syntax/comment conservation: ${file}`);
}
