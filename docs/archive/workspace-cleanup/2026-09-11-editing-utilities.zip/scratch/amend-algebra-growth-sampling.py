from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

root = Path(__file__).resolve().parents[1]
destination = root / 'docs/teaching/evidence/algebra-functions-author-review.json'
record = json.loads(destination.read_text())
def fingerprint(relative):
    data = (root / relative).read_bytes()
    return {'path': relative, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

lab = 'src/learn/components/lesson-labs/AlgebraFunctionsLabs.jsx'
before = next(item for item in record['production'] if item['path'] == lab)
after = fingerprint(lab)
amendment = {
    'at': datetime.now(timezone.utc).isoformat(),
    'finding': 'Independent reviewer identified two-endpoint additive polyline becoming incorrectly straight on a logarithmic y axis. Arithmetic tables were correct.',
    'repair': 'Sample the additive rule at the same 81 time points as the exponential before log transformation. No other production source changed.',
    'previousFreeze': record['frozenAt'], 'before': before, 'after': after,
    'verification': json.loads((root/'scratch/algebra-functions-browser/additive-log-repair-results.json').read_text()),
    'script': fingerprint('scripts/review-algebra-growth-sampling.cjs'),
    'openedScreenshots': [fingerprint(f'scratch/algebra-functions-browser/additive-log-repair-{width}.png') for width in (1440,390,320)],
    'limits': 'Actual-font three-width targeted source/geometry/state check. t=4 transforms log10(180), independently verified from SVG. Linear-axis midpoint preserved. All three images opened. Earlier broad native/browser evidence unchanged; not rerun or attributed to this amendment.'
}
record.setdefault('postFreezeAmendments', []).append(amendment)
record['production'] = [after if item['path'] == lab else item for item in record['production']]
record['frozenAt'] = amendment['at']
destination.write_text(json.dumps(record, indent=2)+'\n')
with (root/'docs/teaching/ALGEBRA-FUNCTIONS-VERIFICATION.md').open('a',encoding='utf8') as handle:
    handle.write(f"\n## Independent-review amendment: additive curve on logarithmic axis\n\nAt {amendment['at']}, replaced the additive curve's two endpoints with 81 evaluations of its actual rule. Joining endpoint log coordinates had incorrectly represented the midpoint as sqrt(100×260), rather than 180. `review-algebra-growth-sampling.cjs` passes actual-font 1440/390/320: transformed midpoint fraction {amendment['verification']['records'][0]['logMidpointFraction']}, independent log-ratio expectation, correct linear midpoint, 81 samples, no console/page errors or document overflow. All three final images were opened. Only lab source changed, from {before['sha256']} to {after['sha256']}; previous freeze and prior evidence remain explicitly retained in the author JSON. No broad rerun or integration claim.\n")
print(json.dumps({'frozenAt':record['frozenAt'],'lab':after},indent=2))
