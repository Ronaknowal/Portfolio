const fs = require('node:fs');
const assert = require('node:assert/strict');
const parser = require('@babel/parser');
const generate = require('@babel/generator').default;
const files = ['src/learn/components/lesson-labs/MultivariateCalculusLabs.jsx', 'src/learn/data/multivariate-calculus-models.js', 'src/learn/data/topics/multivariate-calculus-gradients.jsx'];
function normalize(value) {
  if (Array.isArray(value)) return value.map(normalize);
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).filter(([key]) => !['start', 'end', 'loc', 'extra', 'tokens'].includes(key)).map(([key, child]) => [key, normalize(child)]));
  return value;
}
for (const file of files) {
  const before = fs.readFileSync(file, 'utf8');
  const ast = parser.parse(before, { sourceType: 'module', plugins: ['jsx'] });
  const after = generate(ast, { comments: true, compact: false, retainLines: false }, before).code + '\n';
  assert.deepEqual(normalize(parser.parse(after, { sourceType: 'module', plugins: ['jsx'] })), normalize(ast), file);
  fs.writeFileSync(file, after);
}
fs.writeFileSync('scratch/multivariate-verification/formatting-results.json', JSON.stringify({ date: new Date().toISOString(), files, normalizedAstIdentical: true, templateRawAndJsxValuesCompared: true }, null, 2));

