const fs = require('fs');
const parser = require('@babel/parser');
const generate = require('@babel/generator').default;
const postcss = require('postcss');
const assert = require('node:assert/strict');
const files = ['src/learn/data/persistent-structures-models.js', 'src/learn/components/lesson-labs/PersistentStructuresLabs.jsx', 'scripts/verify-persistent-structures-models.mjs'];
function clean(value) {
  if (Array.isArray(value)) return value.map(clean);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value).filter(([key]) => !['start', 'end', 'loc', 'extra', 'leadingComments', 'trailingComments', 'innerComments'].includes(key)).map(([key, item]) => [key, clean(item)]));
}
for (const file of files) {
  const source = fs.readFileSync(file, 'utf8');
  const before = parser.parse(source, { sourceType: 'module', plugins: ['jsx'] });
  const formatted = generate(before, { comments: true, compact: false, retainLines: false, jsescOption: { minimal: true } }, source).code + '\n';
  const after = parser.parse(formatted, { sourceType: 'module', plugins: ['jsx'] });
  assert.deepEqual(clean(after), clean(before), file);
  fs.writeFileSync(file, formatted);
  console.log(file + ' normalized AST unchanged');
}
const cssFile = 'src/learn/components/lesson-labs/persistent-structures-labs.css';
const root = postcss.parse(fs.readFileSync(cssFile, 'utf8'));
function signature(tree) {
  const result = [];
  tree.walk(node => result.push([node.type, node.selector, node.name, node.params, node.prop, node.value, node.important]));
  return result;
}
const before = signature(root);
root.walk(node => {
  const nested = node.parent.type === 'atrule';
  node.raws.before = node.type === 'decl' ? '\n' + (node.parent.parent.type === 'atrule' ? '    ' : '  ') : '\n' + (nested ? '  ' : '');
  if (node.type === 'decl') node.raws.between = ': ';
  else { node.raws.between = ' '; node.raws.after = '\n' + (nested ? '  ' : ''); }
});
const formatted = root.toString().trim() + '\n';
assert.deepEqual(signature(postcss.parse(formatted)), before);
fs.writeFileSync(cssFile, formatted);
console.log(cssFile + ' selectors/declarations unchanged');

