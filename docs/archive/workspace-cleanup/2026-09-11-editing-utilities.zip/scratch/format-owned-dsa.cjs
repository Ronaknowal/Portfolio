const fs = require('node:fs');
const assert = require('node:assert/strict');
const { parse } = require('@babel/parser');
const generate = require('@babel/generator').default;
const files = [
  'src/learn/data/heap-trie-models.js',
  'src/learn/data/graph-traversal-models.js',
  'src/learn/components/lesson-labs/HeapTrieLabs.jsx',
  'src/learn/components/lesson-labs/GraphTraversalLabs.jsx',
  'scripts/verify-heap-trie-models.mjs',
  'scripts/verify-graph-traversal-models.mjs',
];
const canonical = value => {
  if (Array.isArray(value)) return value.map(canonical);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value)
    .filter(([key]) => !['start','end','loc','extra','errors'].includes(key))
    .map(([key,child]) => [key,canonical(child)]));
};
const planned = files.map(file => {
  const before = fs.readFileSync(file, 'utf8');
  const ast = parse(before, { sourceType:'module', plugins:['jsx'] });
  const after = generate(ast, { comments:true, compact:false, jsescOption:{minimal:true} }, before).code + '\n';
  const afterAst = parse(after, { sourceType:'module', plugins:['jsx'] });
  assert.deepEqual(canonical(afterAst), canonical(ast), `Semantic AST changed in ${file}`);
  return {file,before,after};
});
fs.mkdirSync('scratch/dsa-format-baseline', {recursive:true});
for (const item of planned) {
  fs.writeFileSync('scratch/dsa-format-baseline/' + item.file.replaceAll('/','__'), item.before);
  fs.writeFileSync(item.file, item.after);
}
console.log('Formatted six owned Heap/Graph sources; normalized ASTs, comments, string literals and JSX text values are unchanged.');
