const fs = require('node:fs');
const file = 'docs/teaching/dsa-math-foundations-progress.json';
const progress = JSON.parse(fs.readFileSync(file, 'utf8'));
const designs = {
  'greedy-algorithms-exchange-arguments': 'GREEDY-EXCHANGE-LESSON-DESIGN',
  'dynamic-programming-states-transitions-optimization': 'DYNAMIC-PROGRAMMING-LESSON-DESIGN',
  'tensor-algebra-einsum-notation': 'TENSOR-ALGEBRA-EINSUM-DESIGN',
  'randomized-linear-algebra': 'RANDOMIZED-LINEAR-ALGEBRA-DESIGN',
};
for (const [id, design] of Object.entries(designs)) {
  const entry = progress.topics.find(topic => topic.id === id);
  if (entry.status !== 'in-progress') throw new Error('Only active designs may be updated');
  entry.designRecord = `docs/teaching/${design}.md`;
}
fs.writeFileSync(file, JSON.stringify(progress, null, 2) + '\n');
