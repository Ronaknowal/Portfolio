"""Section 4e: multi-stage pipeline composing stages from 4a-4d."""
from s4a_heuristic import CORPUS, passes_heuristics
from s4b_perplexity import train_unigram_lm, perplexity
from s4d_llm_judge import mock_llm_rate


def main():
    n0 = len(CORPUS)
    docs = list(enumerate(CORPUS))  # (original_idx, text)
    print(f"stage 0: raw corpus                    n={len(docs):>2}/{n0}  (100.0%)")

    # Stage 1: heuristic filter (cheap, CPU, near-free).
    docs = [(i, d) for i, d in docs if passes_heuristics(d)]
    print(f"stage 1: heuristic filter              n={len(docs):>2}/{n0}  ({len(docs)/n0:.1%})")

    # Stage 2: perplexity filter against Wikipedia-like reference docs.
    reference = [CORPUS[j] for j in [0, 1, 7, 14, 18]]
    logp, *_ = train_unigram_lm(reference)
    docs_pp = [(i, d, perplexity(d, logp)) for i, d in docs]
    # Keep docs with perplexity below median-of-kept.
    ppvals = sorted(x[2] for x in docs_pp)
    pp_threshold = ppvals[len(ppvals) // 2] if ppvals else float("inf")
    docs = [(i, d) for i, d, pp in docs_pp if pp <= pp_threshold]
    print(f"stage 2: perplexity filter (<= {pp_threshold:.0f})   n={len(docs):>2}/{n0}  ({len(docs)/n0:.1%})")

    # Stage 3: classifier-based filtering — use LLM ratings as labels, threshold 3.
    docs = [(i, d) for i, d in docs if mock_llm_rate(d) >= 3]
    print(f"stage 3: quality classifier (>= 3)     n={len(docs):>2}/{n0}  ({len(docs)/n0:.1%})")

    # Stage 4: LLM-as-judge rating cutoff at 4 (annotate the survivors).
    docs = [(i, d) for i, d in docs if mock_llm_rate(d) >= 4]
    print(f"stage 4: LLM-judge rating (>= 4)       n={len(docs):>2}/{n0}  ({len(docs)/n0:.1%})")

    print()
    print("surviving docs (by original corpus index):")
    for i, d in docs:
        preview = d[:60].replace("\n", " ")
        print(f"  doc{i:>2}  {preview}...")


if __name__ == "__main__":
    main()
