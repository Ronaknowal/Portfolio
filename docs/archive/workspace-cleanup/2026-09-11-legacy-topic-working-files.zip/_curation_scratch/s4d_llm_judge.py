"""Section 4d: simulated LLM-as-judge curator loop.

The 'mock LLM' is a rule-based stand-in that rates each document 1-5 on
perceived educational quality. In practice this role is played by a strong
instruction-tuned model (Llama-3-70B, Claude, GPT-4) applied to a small
sample, not the full corpus.
"""
from collections import Counter
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import numpy as np
from s4a_heuristic import CORPUS


EDU_WORDS = {
    "model", "research", "data", "science", "analysis", "theory", "experiment",
    "method", "system", "algorithm", "study", "process", "history", "century",
    "technology", "biology", "cell", "energy", "reaction", "language", "dna",
    "architecture", "attention", "encoder", "transformer", "photosynthesis",
    "mitochondrion", "library", "committee", "package", "install", "function",
}
SPAM_WORDS = {
    "buy", "click", "sale", "discount", "cheap", "promo", "winner", "deal",
    "coupon", "shipping", "guaranteed", "lowest", "cart", "checkout",
}


def mock_llm_rate(doc):
    """Rate a document 1-5 on 'educational quality'.

    Stands in for an LLM-as-judge prompt. A real pipeline sends the document
    plus a detailed rubric to the model and parses the integer score back.
    """
    toks = doc.lower().split()
    n = len(toks)
    if n < 20:
        return 1  # too short to learn from

    edu_hits = sum(1 for t in toks if t.strip(".,;:!?()[]{}") in EDU_WORDS)
    spam_hits = sum(1 for t in toks if t.strip(".,;:!?()[]{}") in SPAM_WORDS)
    has_lorem = "lorem ipsum" in doc.lower()
    top_ratio = Counter(toks).most_common(1)[0][1] / n
    sent_end = sum(1 for c in doc if c in ".!?")
    avg_len = sum(len(w) for w in toks) / n

    score = 3  # baseline
    score += min(2, edu_hits)                 # up to +2 for domain vocab
    score -= min(3, spam_hits // 2)           # penalty for spam terms
    if has_lorem: score -= 2
    if top_ratio > 0.3: score -= 2            # repetition penalty
    if sent_end < 2: score -= 1
    if avg_len < 3 or avg_len > 8: score -= 1
    return max(1, min(5, score))


def main():
    # Step 1: sample a subset of the corpus for LLM annotation.
    # In production this is typically 100k-500k docs out of billions.
    # Here we annotate all 20 for clarity.
    ratings = [mock_llm_rate(d) for d in CORPUS]
    print("LLM-as-judge ratings (1-5):")
    for i, r in enumerate(ratings):
        print(f"  doc{i:>2}  rating={r}")
    print()
    dist = Counter(ratings)
    for s in sorted(dist):
        print(f"  rating={s}  count={dist[s]}  {'#' * dist[s]}")

    # Step 2: treat rating >= 3 as 'pass' and train a binary classifier.
    y = np.array([1 if r >= 3 else 0 for r in ratings])
    vec = TfidfVectorizer(min_df=1, ngram_range=(1, 2), max_features=500)
    X = vec.fit_transform(CORPUS)

    # Train on first 14, evaluate on last 6 — to simulate generalization.
    rng = np.random.default_rng(11)
    idx = np.arange(len(CORPUS))
    rng.shuffle(idx)
    tr, te = idx[:14], idx[14:]
    clf = LogisticRegression(max_iter=500, C=1.0).fit(X[tr], y[tr])
    pred_te = clf.predict(X[te])
    print()
    print(f"held-out classifier accuracy: {(pred_te == y[te]).mean():.2%}")

    # Step 3: score every document and report pass rate at different cuts.
    proba = clf.predict_proba(X)[:, 1]
    print()
    print("pass rates by classifier threshold (trained on LLM labels):")
    for th in [0.3, 0.5, 0.7]:
        kept = int((proba >= th).sum())
        print(f"  th={th}  kept={kept}/{len(CORPUS)}")

    # Step 4: if we instead keep docs whose LLM rating directly is >= k.
    print()
    print("pass rates by direct LLM rating cutoff:")
    for k in [2, 3, 4, 5]:
        kept = sum(1 for r in ratings if r >= k)
        print(f"  rating >= {k}  kept={kept}/{len(CORPUS)}")


if __name__ == "__main__":
    main()
