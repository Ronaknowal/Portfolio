"""Section 4a: heuristic filter."""
from collections import Counter

CORPUS = [
    # 0: good — plain English paragraph.
    "The mitochondrion is a double-membrane-bound organelle found in most eukaryotic cells. "
    "It generates most of the cell's supply of adenosine triphosphate, the source of chemical energy. "
    "Mitochondria are commonly between 0.75 and 3 micrometres in diameter but vary considerably in size and structure. "
    "They have their own DNA, a feature usually attributed to their bacterial origin.",
    # 1: good — technical writing with numbers.
    "A transformer model consists of an encoder and a decoder, each built from a stack of layers. "
    "Each layer contains a multi-head self-attention mechanism and a position-wise feed-forward network. "
    "Residual connections and layer normalization are applied around each sub-layer. "
    "The model was introduced by Vaswani et al in 2017 and has since become the dominant architecture.",
    # 2: bad — short, almost no content.
    "Click here.",
    # 3: bad — navigation-menu / symbol soup.
    "| Home | About | Contact | Login | Register | >>> [+] [-] ($$$) *** ||| === --- ___ ~~~ @@@ ^^^ {{{}}}",
    # 4: bad — JSON blob.
    '{"status":"ok","data":{"items":[{"id":1,"v":"a"},{"id":2,"v":"b"},{"id":3,"v":"c"}],"n":3},"t":1713600000}',
    # 5: good — news-article style.
    "The committee announced the decision on Monday after a three-hour meeting. "
    "Several members raised concerns about the budget implications, but the final vote was unanimous. "
    "Implementation is expected to begin in the first quarter of next year. "
    "A spokesperson said further details would be released in the coming weeks.",
    # 6: bad — repetitive single-letter strings.
    "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa bbbbbbbbbbbbbbb ccccccccccc dddddd eeeeee f g h i j k " * 3,
    # 7: good — Wikipedia-like.
    "Photosynthesis is the process by which green plants use sunlight to synthesize foods from carbon dioxide and water. "
    "It generally involves the green pigment chlorophyll and produces oxygen as a byproduct. "
    "The overall reaction can be summarised as carbon dioxide plus water plus light energy yields glucose plus oxygen. "
    "Photosynthesis is the primary source of energy in most food chains.",
    # 8: bad — too short and generic.
    "Welcome to our site.",
    # 9: bad — SEO filler.
    "best cheap buy discount online deal sale coupon promo offer free shipping guaranteed lowest price " * 4,
    # 10: good — instructional.
    "To install the package first open a terminal and navigate to your project directory. "
    "Run the command pip install example-package. The installer will download any required dependencies. "
    "Once installation completes you can import the package in your Python scripts. "
    "Verify the installation by running the included test suite.",
    # 11: bad — template placeholder.
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. "
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. "
    "Lorem ipsum dolor sit amet. Lorem ipsum.",
    # 12: good — conversational but substantive.
    "When you think about it the hardest part of learning a new language is not the vocabulary but the rhythm. "
    "Native speakers drop articles compress syllables and leave sentences incomplete in ways textbooks never describe. "
    "You learn that by listening not by studying. It takes years and there is no shortcut around the time commitment.",
    # 13: bad — pricing table row-ish.
    "$9.99 $19.99 $29.99 $39.99 $49.99 buy now add to cart checkout save save save discount % off % off",
    # 14: good — academic abstract.
    "We propose a novel approach to question answering over structured knowledge bases. "
    "Our method combines neural retrieval with symbolic reasoning and achieves state-of-the-art results on three benchmarks. "
    "We analyze the contribution of each component through detailed ablation studies. "
    "The model is released publicly along with our code and trained checkpoints.",
    # 15: bad — mostly numbers.
    "2024 2025 2026 1234 5678 9012 3456 7890 1111 2222 3333 4444 5555 6666 7777 8888 9999 0000 1010 2020 3030",
    # 16: good — code comment plus prose.
    "The function accepts a list of integers and returns their sum. "
    "It handles empty inputs by returning zero and it works on arbitrarily large lists thanks to the built-in bigint support. "
    "We prefer this over a manual loop because the builtin is implemented in C and runs roughly ten times faster.",
    # 17: bad — adversarial keyword-stuffing.
    "buy buy buy cheap cheap cheap now now now fast fast fast deal deal deal " * 6,
    # 18: good — historical prose.
    "The library at Alexandria was founded in the early third century BCE under Ptolemy I Soter. "
    "At its height it may have housed several hundred thousand scrolls. "
    "It served as a centre of scholarship for centuries before its gradual decline. "
    "Exactly how and when it was destroyed remains a matter of historical debate.",
    # 19: bad — tiny and spammy.
    "WINNER CLICK NOW",
]


def passes_heuristics(doc, debug=False):
    """Return True iff the document passes a set of cheap surface checks."""
    words = doc.split()
    n = len(words)
    if not (50 <= n <= 100_000):
        if debug: return ("word_count", n)
        return False

    avg_len = sum(len(w) for w in words) / max(n, 1)
    if not (3.0 <= avg_len <= 10.0):
        if debug: return ("avg_word_len", round(avg_len, 2))
        return False

    alnum_ratio = sum(c.isalnum() or c.isspace() for c in doc) / max(len(doc), 1)
    if alnum_ratio < 0.8:
        if debug: return ("alnum_ratio", round(alnum_ratio, 2))
        return False

    if "lorem ipsum" in doc.lower():
        if debug: return ("template_marker", "lorem ipsum")
        return False

    sent_end = sum(1 for c in doc if c in ".!?")
    if sent_end < 3:
        if debug: return ("sentence_endings", sent_end)
        return False

    top = Counter(words).most_common(1)
    if top and top[0][1] / n > 0.4:
        if debug: return ("repetition", top[0])
        return False

    return True if not debug else "pass"


def main():
    kept, dropped = 0, 0
    for i, doc in enumerate(CORPUS):
        reason = passes_heuristics(doc, debug=True)
        ok = reason == "pass"
        kept += ok
        dropped += not ok
        print(f"doc{i:>2}  {'KEEP' if ok else 'DROP':>4}  {reason if not ok else ''}")
    print()
    print(f"kept    {kept:>2} / {len(CORPUS)}")
    print(f"dropped {dropped:>2} / {len(CORPUS)}")
    print(f"pass rate {kept/len(CORPUS):.2%}")


if __name__ == "__main__":
    main()
