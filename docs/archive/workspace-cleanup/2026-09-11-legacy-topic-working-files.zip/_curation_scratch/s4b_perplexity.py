"""Section 4b: perplexity-based filtering with a unigram reference LM."""
import math
from collections import Counter
from s4a_heuristic import CORPUS


def train_unigram_lm(reference_docs):
    """Fit a unigram language model over a reference corpus (Wikipedia-like docs)."""
    counts = Counter()
    for d in reference_docs:
        counts.update(d.lower().split())
    total = sum(counts.values())
    V = len(counts) + 1  # +1 for the implicit <unk>
    # Laplace-smoothed unigram probabilities.
    def logp(tok):
        return math.log((counts.get(tok, 0) + 1) / (total + V))
    return logp, counts, total, V


def perplexity(doc, logp):
    """Per-token perplexity under the reference LM."""
    toks = doc.lower().split()
    if not toks:
        return float("inf")
    ll = sum(logp(t) for t in toks)
    return math.exp(-ll / len(toks))


def main():
    # Reference corpus: docs that we independently know look "encyclopedic".
    # Pick indices 0, 1, 7, 14, 18 from the synthetic corpus — the Wikipedia-like ones.
    REF_IDX = [0, 1, 7, 14, 18]
    reference = [CORPUS[i] for i in REF_IDX]
    logp, counts, total, V = train_unigram_lm(reference)

    print(f"reference: {len(reference)} docs, {total} tokens, vocab={len(counts)}")
    print()
    print("  doc  n_tokens   perplexity")
    scores = []
    for i, doc in enumerate(CORPUS):
        pp = perplexity(doc, logp)
        scores.append((i, pp))
        n_toks = len(doc.split())
        tag = "ref " if i in REF_IDX else "    "
        print(f"  {tag}{i:>2}  {n_toks:>7}   {pp:>10.1f}")

    # Histogram bins (log10 perplexity).
    print()
    print("perplexity histogram (log10):")
    buckets = Counter()
    for _, pp in scores:
        b = round(math.log10(max(pp, 1.0)), 1)
        buckets[b] += 1
    for b in sorted(buckets):
        print(f"  10^{b:>4}  {'#' * buckets[b]}  ({buckets[b]})")

    # Threshold: keep docs with perplexity below the 60th percentile of scores.
    sorted_scores = sorted(s[1] for s in scores)
    threshold = sorted_scores[int(0.6 * len(sorted_scores))]
    kept = [i for i, pp in scores if pp <= threshold]
    print()
    print(f"threshold (60th pct) = {threshold:.1f}")
    print(f"kept: {kept}  (n={len(kept)}/{len(scores)})")


if __name__ == "__main__":
    main()
