"""Section 4c: quality classifier trained on heuristic-labeled docs."""
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import numpy as np
from s4a_heuristic import CORPUS


# Labels chosen from the corpus above: 1 = good (Wikipedia-like), 0 = bad.
# We pretend these labels came from heuristic surface checks rather than manual annotation.
GOOD_IDX = [0, 1, 5, 7, 10, 12, 14, 16, 18]
BAD_IDX = [2, 3, 4, 6, 8, 9, 11, 13, 15, 17, 19]


def label_via_surface_heuristics(docs):
    """Assign a noisy label 1 (good) or 0 (bad) from surface statistics.

    Rationale: in practice, tiny labeled sets are bootstrapped from cheap rules.
    """
    labels = []
    for d in docs:
        toks = d.split()
        n = len(toks)
        if n == 0:
            labels.append(0); continue
        avg_len = sum(len(w) for w in toks) / n
        sent_end = sum(1 for c in d if c in ".!?")
        has_lorem = "lorem ipsum" in d.lower()
        alnum = sum(c.isalnum() or c.isspace() for c in d) / max(len(d), 1)
        # Simple rule: good if enough words, enough sentences, no template, clean chars.
        good = (n >= 40 and sent_end >= 3 and 3.5 <= avg_len <= 6.5 and
                alnum >= 0.85 and not has_lorem)
        labels.append(1 if good else 0)
    return np.array(labels)


def train_and_eval():
    # Step 1: bootstrap noisy labels from surface heuristics.
    y_bootstrap = label_via_surface_heuristics(CORPUS)
    # Step 2: split train / held-out.
    rng = np.random.default_rng(17)
    idx = np.arange(len(CORPUS))
    rng.shuffle(idx)
    train_idx, test_idx = idx[:14], idx[14:]
    X_train_docs = [CORPUS[i] for i in train_idx]
    X_test_docs = [CORPUS[i] for i in test_idx]
    y_train, y_test = y_bootstrap[train_idx], y_bootstrap[test_idx]

    # Step 3: TF-IDF features + logistic regression (lightweight classifier).
    vec = TfidfVectorizer(min_df=1, ngram_range=(1, 2), max_features=500)
    Xtr = vec.fit_transform(X_train_docs)
    Xte = vec.transform(X_test_docs)
    clf = LogisticRegression(max_iter=500, C=1.0).fit(Xtr, y_train)

    pred = clf.predict(Xte)
    proba = clf.predict_proba(Xte)[:, 1]

    print("train labels (bootstrapped from heuristics):")
    for i, y in zip(train_idx, y_train):
        print(f"  doc{i:>2}  y={y}")
    print()
    print("held-out predictions:")
    for i, y, p, pr in zip(test_idx, y_test, pred, proba):
        match = "OK" if y == p else "MISS"
        print(f"  doc{i:>2}  true={y} pred={p}  p(good)={pr:.3f}  {match}")
    print()
    acc = (pred == y_test).mean()
    print(f"held-out accuracy: {acc:.2%}")

    # Step 4: score the full corpus (this is what you'd do at inference).
    X_all = vec.transform(CORPUS)
    p_good_all = clf.predict_proba(X_all)[:, 1]
    print()
    print("full-corpus scores (p_good):")
    for i, p in enumerate(p_good_all):
        print(f"  doc{i:>2}  p(good)={p:.3f}")

    # Threshold sweep.
    print()
    print("pass rates at different classifier thresholds:")
    for th in [0.3, 0.4, 0.5, 0.6, 0.7, 0.8]:
        kept = int((p_good_all >= th).sum())
        print(f"  threshold={th}  kept={kept}/{len(CORPUS)}")


if __name__ == "__main__":
    train_and_eval()
