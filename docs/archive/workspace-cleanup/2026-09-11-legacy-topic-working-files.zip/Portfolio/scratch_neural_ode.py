"""Neural ODE from-scratch verification for the learn topic.

Runs all the code blocks in section 4 and prints output we can paste back as
# Output: comments. Uses PyTorch 2.6 + CUDA when available; falls back to CPU.
"""

import math
import time
import torch
import torch.nn as nn
import torch.nn.functional as F

device = "cuda" if torch.cuda.is_available() else "cpu"
torch.manual_seed(0)
print(f"[setup] device={device}  torch={torch.__version__}")


# ----------------------------------------------------------------------------
# 4.1  Euler solver — verify on linear ODE dz/dt = -z, z(0)=1, z(T) = exp(-T)
# ----------------------------------------------------------------------------
print("\n[4.1] Euler solver vs. analytic exp(-T)")

def euler_solve(f, z0, t0, t1, n_steps):
    z = z0
    h = (t1 - t0) / n_steps
    t = t0
    for _ in range(n_steps):
        z = z + h * f(z, t)
        t = t + h
    return z

f_decay = lambda z, t: -z
for n in [10, 100, 1000, 10000]:
    z = euler_solve(f_decay, torch.tensor(1.0), 0.0, 1.0, n)
    err = abs(z.item() - math.exp(-1.0))
    print(f"  n={n:>5}  z(1)={z.item():.6f}  exact={math.exp(-1.0):.6f}  err={err:.2e}")


# ----------------------------------------------------------------------------
# 4.2  RK4 solver — same problem, much smaller error per step
# ----------------------------------------------------------------------------
print("\n[4.2] RK4 vs Euler on the same ODE")

def rk4_solve(f, z0, t0, t1, n_steps):
    z = z0
    h = (t1 - t0) / n_steps
    t = t0
    for _ in range(n_steps):
        k1 = f(z, t)
        k2 = f(z + 0.5 * h * k1, t + 0.5 * h)
        k3 = f(z + 0.5 * h * k2, t + 0.5 * h)
        k4 = f(z + h * k3, t + h)
        z = z + (h / 6.0) * (k1 + 2*k2 + 2*k3 + k4)
        t = t + h
    return z

for n in [4, 10, 100]:
    ze = euler_solve(f_decay, torch.tensor(1.0), 0.0, 1.0, n).item()
    zr = rk4_solve(f_decay, torch.tensor(1.0), 0.0, 1.0, n).item()
    exact = math.exp(-1.0)
    print(f"  n={n:>4}  euler_err={abs(ze-exact):.2e}   rk4_err={abs(zr-exact):.2e}")


# ----------------------------------------------------------------------------
# 4.3  Solve a 2D rotation field — circle test
# ----------------------------------------------------------------------------
print("\n[4.3] 2D rotation field, integrate from t=0 to t=pi (half-circle)")

def f_rot(z, t):
    # dz/dt = R * z   with R = [[0, -1], [1, 0]]  (90 deg/sec rotation)
    return torch.stack([-z[1], z[0]])

z0 = torch.tensor([1.0, 0.0])
zT_euler = euler_solve(f_rot, z0, 0.0, math.pi, 200)
zT_rk4   = rk4_solve(f_rot,   z0, 0.0, math.pi, 200)
print(f"  euler z(pi) = ({zT_euler[0].item():+.4f}, {zT_euler[1].item():+.4f})  "
      f"(expected ~ (-1, 0))")
print(f"  rk4   z(pi) = ({zT_rk4[0].item():+.4f}, {zT_rk4[1].item():+.4f})  "
      f"(expected ~ (-1, 0))")


# ----------------------------------------------------------------------------
# 4.4  Neural ODE: implement custom autograd Function with adjoint backprop
# ----------------------------------------------------------------------------
print("\n[4.4] Adjoint-method backprop vs autograd reference")

class ODEFunc(nn.Module):
    """A small MLP with concatenated time, parameterizing dz/dt = f(z, t; theta)."""
    def __init__(self, dim=2, hidden=32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim + 1, hidden),
            nn.Tanh(),
            nn.Linear(hidden, hidden),
            nn.Tanh(),
            nn.Linear(hidden, dim),
        )

    def forward(self, z, t):
        if z.dim() == 1:
            tt = torch.tensor([t], dtype=z.dtype, device=z.device)
            inp = torch.cat([z, tt], dim=-1)
            return self.net(inp)
        else:
            tt = torch.full((z.size(0), 1), float(t), dtype=z.dtype, device=z.device)
            inp = torch.cat([z, tt], dim=-1)
            return self.net(inp)


def odeint_rk4(f, z0, t_grid, params=None):
    """Forward-only RK4 integration; returns z(t_grid[-1])."""
    z = z0
    for i in range(len(t_grid) - 1):
        t = t_grid[i].item()
        h = (t_grid[i+1] - t_grid[i]).item()
        k1 = f(z, t)
        k2 = f(z + 0.5 * h * k1, t + 0.5 * h)
        k3 = f(z + 0.5 * h * k2, t + 0.5 * h)
        k4 = f(z + h * k3, t + h)
        z = z + (h / 6.0) * (k1 + 2*k2 + 2*k3 + k4)
    return z


class NeuralODEFn(torch.autograd.Function):
    """Custom autograd Function that solves an ODE forward and uses the
    adjoint sensitivity method backward — O(1) memory in solver depth."""

    @staticmethod
    def forward(ctx, z0, t_grid, flat_params, func):
        # Set params from flat tensor
        with torch.no_grad():
            offset = 0
            for p in func.parameters():
                n = p.numel()
                p.copy_(flat_params[offset:offset+n].view_as(p))
                offset += n

        with torch.no_grad():
            zT = odeint_rk4(func, z0, t_grid)

        ctx.save_for_backward(zT, t_grid, flat_params)
        ctx.func = func
        return zT

    @staticmethod
    def backward(ctx, grad_zT):
        zT, t_grid, flat_params = ctx.saved_tensors
        func = ctx.func
        n_params = flat_params.numel()
        dim = zT.numel()

        # Augmented state s = [z, a, dL/dtheta]; integrate backward
        def aug_dyn(state, t):
            z = state[:dim].detach().requires_grad_(True)
            a = state[dim:2*dim]
            with torch.enable_grad():
                fz = func(z, t)
                # dL/dz adjoint: da/dt = -a^T df/dz   =>  using vjp
                grads = torch.autograd.grad(
                    fz, list(func.parameters()) + [z],
                    grad_outputs=-a,
                    retain_graph=True,
                    create_graph=False,
                    allow_unused=True,
                )
                dadt = grads[-1] if grads[-1] is not None else torch.zeros_like(z)
                # parameter grads
                pg_list = []
                offset = 0
                for p, g in zip(func.parameters(), grads[:-1]):
                    if g is None:
                        pg_list.append(torch.zeros(p.numel(), device=p.device))
                    else:
                        pg_list.append(g.contiguous().view(-1))
                pg_flat = torch.cat(pg_list)
            dz_dt = fz.detach()  # forward dynamics (sign flip handled by reversed t below)
            return torch.cat([dz_dt, dadt.detach(), pg_flat])

        # Initial augmented state at t=T
        state = torch.cat([
            zT.detach().view(-1),
            grad_zT.detach().view(-1),
            torch.zeros(n_params, device=zT.device, dtype=zT.dtype),
        ])

        # Integrate from T back to 0 via reversed grid
        t_rev = t_grid.flip(0)
        for i in range(len(t_rev) - 1):
            t = t_rev[i].item()
            h = (t_rev[i+1] - t_rev[i]).item()  # negative h for reverse
            k1 = aug_dyn(state, t)
            k2 = aug_dyn(state + 0.5 * h * k1, t + 0.5 * h)
            k3 = aug_dyn(state + 0.5 * h * k2, t + 0.5 * h)
            k4 = aug_dyn(state + h * k3, t + h)
            state = state + (h / 6.0) * (k1 + 2*k2 + 2*k3 + k4)

        grad_z0 = state[dim:2*dim].view_as(zT)
        grad_params = state[2*dim:]
        return grad_z0, None, grad_params, None


def neural_ode(z0, t_grid, func):
    flat = torch.cat([p.detach().view(-1) for p in func.parameters()])
    flat = flat.requires_grad_(True)
    return NeuralODEFn.apply(z0, t_grid, flat, func), flat


# Verify gradients match standard backprop on a simple 2D case
torch.manual_seed(7)
func_a = ODEFunc(dim=2, hidden=8)
func_b = ODEFunc(dim=2, hidden=8)
# Sync params
with torch.no_grad():
    for pa, pb in zip(func_a.parameters(), func_b.parameters()):
        pb.copy_(pa)

z0 = torch.tensor([0.5, -0.3], requires_grad=False)
t_grid = torch.linspace(0.0, 1.0, 21)

# Reference: integrate with autograd-enabled RK4 (memory-heavy, but ground truth)
def odeint_autograd(f, z0, t_grid):
    z = z0
    for i in range(len(t_grid) - 1):
        t = t_grid[i].item()
        h = (t_grid[i+1] - t_grid[i]).item()
        k1 = f(z, t)
        k2 = f(z + 0.5 * h * k1, t + 0.5 * h)
        k3 = f(z + 0.5 * h * k2, t + 0.5 * h)
        k4 = f(z + h * k3, t + h)
        z = z + (h / 6.0) * (k1 + 2*k2 + 2*k3 + k4)
    return z

zT_ref = odeint_autograd(func_a, z0, t_grid)
loss_ref = (zT_ref ** 2).sum()
loss_ref.backward()
ref_grads = torch.cat([p.grad.detach().view(-1) for p in func_a.parameters()])

# Adjoint
zT_adj, flat = neural_ode(z0, t_grid, func_b)
loss_adj = (zT_adj ** 2).sum()
loss_adj.backward()

max_err = (flat.grad - ref_grads).abs().max().item()
rel_err = max_err / ref_grads.abs().max().item()
print(f"  forward zT match:   max|adj - ref| = {(zT_adj - zT_ref.detach()).abs().max().item():.2e}")
print(f"  param grad match:   max abs err = {max_err:.2e}   rel = {rel_err:.2e}")


# ----------------------------------------------------------------------------
# 4.5  Train a Neural ODE on the spiral classification task (canonical demo)
# ----------------------------------------------------------------------------
print("\n[4.5] Spiral classification: Neural ODE vs ResNet baseline")

def make_spiral(n=600, noise=0.06):
    n_per = n // 2
    theta = torch.linspace(0.5, 2.5 * math.pi, n_per)
    r = 0.3 + theta / (2.5 * math.pi)
    x0 = torch.stack([r * torch.cos(theta), r * torch.sin(theta)], dim=1)
    x1 = torch.stack([r * torch.cos(theta + math.pi), r * torch.sin(theta + math.pi)], dim=1)
    X = torch.cat([x0, x1], dim=0) + noise * torch.randn(n, 2)
    y = torch.cat([torch.zeros(n_per), torch.ones(n_per)]).long()
    perm = torch.randperm(n)
    return X[perm], y[perm]

torch.manual_seed(1)
X_train, y_train = make_spiral(n=600)
X_test,  y_test  = make_spiral(n=200)


# Use torchdiffeq-like simple wrapper: a forward-only batched RK4 with autograd
# (fine for tutorial; we already verified adjoint gives the same gradients)
def odeint_batched(f, z0, t_grid):
    """Batched RK4 with autograd through all steps."""
    z = z0
    for i in range(len(t_grid) - 1):
        t = t_grid[i].item()
        h = (t_grid[i+1] - t_grid[i]).item()
        k1 = f(z, t)
        k2 = f(z + 0.5 * h * k1, t + 0.5 * h)
        k3 = f(z + 0.5 * h * k2, t + 0.5 * h)
        k4 = f(z + h * k3, t + h)
        z = z + (h / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
    return z


class NeuralODEClassifier(nn.Module):
    """Augmented Neural ODE: lift x in R^2 -> z in R^d, run ODE, classify."""
    def __init__(self, in_dim=2, latent=8, hidden=64, n_steps=10):
        super().__init__()
        self.embed = nn.Linear(in_dim, latent)
        self.func = ODEFunc(dim=latent, hidden=hidden)
        self.head = nn.Linear(latent, 2)
        self.t_grid = torch.linspace(0.0, 1.0, n_steps + 1)

    def forward(self, x):
        z0 = self.embed(x)
        zT = odeint_batched(self.func, z0, self.t_grid.to(x.device))
        return self.head(zT)


class ResNetClassifier(nn.Module):
    def __init__(self, in_dim=2, latent=8, hidden=64, n_blocks=10):
        super().__init__()
        self.embed = nn.Linear(in_dim, latent)
        self.blocks = nn.ModuleList([
            nn.Sequential(
                nn.Linear(latent, hidden),
                nn.Tanh(),
                nn.Linear(hidden, latent),
            )
            for _ in range(n_blocks)
        ])
        self.head = nn.Linear(latent, 2)

    def forward(self, x):
        z = self.embed(x)
        for blk in self.blocks:
            z = z + 0.1 * blk(z)
        return self.head(z)


def train_and_eval(model, name, epochs=80, lr=5e-3, batch=64):
    model = model.to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    Xtr = X_train.to(device); ytr = y_train.to(device)
    Xte = X_test.to(device); yte = y_test.to(device)
    losses, accs = [], []
    n = Xtr.size(0)
    t0 = time.time()
    for ep in range(epochs):
        model.train()
        perm = torch.randperm(n, device=device)
        ep_loss = 0.0; nb = 0
        for s in range(0, n, batch):
            idx = perm[s:s+batch]
            opt.zero_grad()
            logits = model(Xtr[idx])
            loss = F.cross_entropy(logits, ytr[idx])
            loss.backward()
            opt.step()
            ep_loss += loss.item(); nb += 1
        avg_loss = ep_loss / nb
        losses.append(avg_loss)
        model.eval()
        with torch.no_grad():
            acc = (model(Xte).argmax(-1) == yte).float().mean().item()
        accs.append(acc)
        if (ep + 1) in (1, 5, 10, 20, 40, 60, 80):
            print(f"  [{name}] ep={ep+1:>2}  loss={avg_loss:.4f}  test_acc={acc:.3f}")
    dt = time.time() - t0
    n_params = sum(p.numel() for p in model.parameters())
    print(f"  [{name}] params={n_params}  total_dt={dt:.2f}s")
    return losses, accs, dt, n_params


torch.manual_seed(2)
node = NeuralODEClassifier(in_dim=2, latent=16, hidden=64, n_steps=10)
node_losses, node_accs, node_dt, node_params = train_and_eval(node, "NODE", epochs=80, lr=5e-3)

torch.manual_seed(2)
res = ResNetClassifier(in_dim=2, latent=16, hidden=64, n_blocks=10)
res_losses, res_accs, res_dt, res_params = train_and_eval(res, "ResNet", epochs=80, lr=5e-3)

print(f"\n  speed ratio NODE/ResNet = {node_dt / res_dt:.2f}x")
print(f"  final acc:  NODE={node_accs[-1]:.3f}   ResNet={res_accs[-1]:.3f}")


# Print loss trajectories at every 10 epochs for the plot
print("\n[4.5b] Loss trajectories (every 10 epochs):")
for i in range(0, 80, 10):
    print(f"  ep={i+1:>2}  NODE_loss={node_losses[i]:.4f}  ResNet_loss={res_losses[i]:.4f}  "
          f"NODE_acc={node_accs[i]:.3f}  ResNet_acc={res_accs[i]:.3f}")


# ----------------------------------------------------------------------------
# 4.7  Trajectory of a single test point through the trained Neural ODE
# ----------------------------------------------------------------------------
print("\n[4.7] Trajectory of a single point z(t) through the trained NODE")

node.eval()
with torch.no_grad():
    sample = X_test[:1].to(device)
    z = node.embed(sample)
    t_grid = node.t_grid.to(device)
    traj = [z.clone().cpu()]
    for i in range(len(t_grid) - 1):
        t = t_grid[i].item()
        h = (t_grid[i+1] - t_grid[i]).item()
        k1 = node.func(z, t)
        k2 = node.func(z + 0.5 * h * k1, t + 0.5 * h)
        k3 = node.func(z + 0.5 * h * k2, t + 0.5 * h)
        k4 = node.func(z + h * k3, t + h)
        z = z + (h / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
        traj.append(z.clone().cpu())
    # Print first 2 latent coords across time
    for i, zt in enumerate(traj):
        v = zt[0]
        print(f"  t={t_grid[i].item():.2f}  z[0:2]=({v[0].item():+.3f}, {v[1].item():+.3f})  "
              f"||z||={v.norm().item():.3f}")


# ----------------------------------------------------------------------------
# 4.6  Adaptive solver — solve a stiff-ish 2D system, count function evals
# ----------------------------------------------------------------------------
print("\n[4.6] Adaptive Dopri5-like step rejection — function evaluations")

# Use a simple adaptive embedded Heun (RK2(1)) with PI-controller for tutorial
def adaptive_heun(f, z0, t0, t1, atol=1e-4, rtol=1e-4, h0=0.05):
    z = z0
    t = t0
    h = h0
    nfe = 0
    accepted = 0
    rejected = 0
    h_log = []
    while t < t1 - 1e-12:
        h = min(h, t1 - t)
        k1 = f(z, t); nfe += 1
        z_euler = z + h * k1
        k2 = f(z_euler, t + h); nfe += 1
        z_heun = z + 0.5 * h * (k1 + k2)
        # error estimate = heun - euler
        err = (z_heun - z_euler).abs()
        sc = atol + rtol * torch.maximum(z.abs(), z_heun.abs())
        e_norm = (err / sc).pow(2).mean().sqrt().item()
        if e_norm <= 1.0:
            t = t + h
            z = z_heun
            accepted += 1
            h_log.append(h)
        else:
            rejected += 1
        # Step size update (PI-ish)
        h = h * min(2.0, max(0.2, 0.9 * (1.0 / max(e_norm, 1e-8)) ** 0.5))
    return z, nfe, accepted, rejected, h_log


# Mild dynamics
def f_circle(z, t):
    return torch.stack([-z[1], z[0]])

zT, nfe, acc, rej, h_log = adaptive_heun(f_circle, torch.tensor([1.0, 0.0]), 0.0, math.pi)
print(f"  mild rotation: nfe={nfe}  accepted={acc}  rejected={rej}  "
      f"min/max h = {min(h_log):.4f} / {max(h_log):.4f}")

# Stiff-ish dynamics: dz/dt = -50 * z (rapid decay) requires small steps
def f_stiff(z, t):
    return -50.0 * z

zT2, nfe2, acc2, rej2, h_log2 = adaptive_heun(f_stiff, torch.tensor([1.0]), 0.0, 0.5)
print(f"  stiff decay:   nfe={nfe2}  accepted={acc2}  rejected={rej2}  "
      f"min/max h = {min(h_log2):.5f} / {max(h_log2):.5f}")
print(f"  exact z(0.5)=exp(-25) = {math.exp(-25):.3e}   computed = {zT2.item():.3e}")
