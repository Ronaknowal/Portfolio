"""4d. Auxiliary load-balance loss — training with and without it.

We force a collapse bias by initializing the router to slightly prefer expert 0
(simulating what happens when some experts get a faster start in a real run),
then run long enough for the feedback loop to take over.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

class Expert(nn.Module):
    def __init__(self, d, h):
        super().__init__()
        self.fc1 = nn.Linear(d, h)
        self.fc2 = nn.Linear(h, d)
    def forward(self, x):
        return self.fc2(F.gelu(self.fc1(x)))

class MoELayer(nn.Module):
    def __init__(self, d, h, E, K, bias_expert=None, bias_amount=0.5):
        super().__init__()
        self.router = nn.Linear(d, E, bias=True)
        # Bias toward a particular expert to simulate an uneven start.
        if bias_expert is not None:
            with torch.no_grad():
                self.router.bias.zero_()
                self.router.bias[bias_expert] = bias_amount
        self.experts = nn.ModuleList([Expert(d, h) for _ in range(E)])
        self.K, self.E = K, E

    def forward(self, x):
        logits = self.router(x)
        probs = F.softmax(logits, -1)
        top_vals, top_idx = probs.topk(self.K, -1)
        top_vals = top_vals / top_vals.sum(-1, True)
        out = torch.zeros_like(x)
        for e in range(self.E):
            mask = (top_idx == e)
            if not mask.any():
                continue
            ti, slot = mask.nonzero(as_tuple=True)
            w = top_vals[ti, slot].unsqueeze(-1)
            out.index_add_(0, ti, w * self.experts[e](x[ti]))
        return out, logits, probs, top_idx


def aux_loss(probs, top_idx, num_experts):
    """Switch-Transformer load-balance loss: L = N * sum f_i * P_i."""
    P = probs.mean(dim=0)
    top1 = top_idx[:, 0]
    f = F.one_hot(top1, num_experts).float().mean(dim=0)
    return num_experts * (f * P).sum()


def train_loop(use_aux, steps=800, N=64, D=16, H=32, E=8, K=2,
               aux_w=0.3, seed=0, bias_expert=0, bias_amount=1.0):
    torch.manual_seed(seed)
    moe = MoELayer(D, H, E, K, bias_expert=bias_expert, bias_amount=bias_amount)
    # Dataset with expert-0-preferred direction: when the mean of x is positive,
    # target uses expert-0-like transformation. This creates a real specialization
    # opportunity and amplifies collapse.
    W_task = torch.randn(D, D)

    opt = torch.optim.Adam(moe.parameters(), lr=3e-3)

    history = []
    for step in range(steps):
        x = torch.randn(N, D)
        target = x @ W_task
        y, logits, probs, idx = moe(x)
        main = F.mse_loss(y, target)
        aux = aux_loss(probs, idx, E)
        loss = main + (aux_w * aux if use_aux else 0.0 * aux)
        opt.zero_grad()
        loss.backward()
        opt.step()

        top1 = idx[:, 0]
        frac = F.one_hot(top1, E).float().mean(0).detach().tolist()
        history.append({"step": step, "main": main.item(), "aux": aux.item(),
                         "frac": frac})
    return history


print("=" * 60)
print("WITHOUT auxiliary loss (router biased toward E0 at init)")
print("=" * 60)
h_no = train_loop(use_aux=False)
final = h_no[-1]["frac"]
for i, f in enumerate(final):
    bar = "#" * int(f * 60)
    print(f"  E{i}: {f:.3f}  {bar}")
print(f"max={max(final):.3f}  min={min(final):.3f}  "
      f"(uniform target = {1/8:.3f})")

print()
print("=" * 60)
print("WITH auxiliary loss (weight=0.3), same biased init")
print("=" * 60)
h_yes = train_loop(use_aux=True)
final = h_yes[-1]["frac"]
for i, f in enumerate(final):
    bar = "#" * int(f * 60)
    print(f"  E{i}: {f:.3f}  {bar}")
print(f"max={max(final):.3f}  min={min(final):.3f}  "
      f"(uniform target = {1/8:.3f})")

# Save curves
import json
with open("aux_curves.json", "w") as f:
    json.dump({
        "no_aux_max_series": [max(r["frac"]) for r in h_no],
        "yes_aux_max_series": [max(r["frac"]) for r in h_yes],
        "no_aux_final": h_no[-1]["frac"],
        "yes_aux_final": h_yes[-1]["frac"],
    }, f)
print("\nwrote aux_curves.json")
