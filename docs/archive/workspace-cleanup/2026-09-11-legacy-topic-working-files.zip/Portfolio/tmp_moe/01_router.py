"""4a. Basic router + top-k."""
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.manual_seed(0)

class Router(nn.Module):
    def __init__(self, d_model, num_experts, top_k):
        super().__init__()
        self.W_r = nn.Linear(d_model, num_experts, bias=False)
        self.top_k = top_k
        self.num_experts = num_experts

    def forward(self, x):
        # x: (N, d_model)
        logits = self.W_r(x)                   # (N, E)
        probs = F.softmax(logits, dim=-1)      # (N, E)
        top_vals, top_idx = probs.topk(self.top_k, dim=-1)  # (N, k), (N, k)
        # Renormalize the selected weights so they sum to 1 per token.
        top_vals = top_vals / top_vals.sum(dim=-1, keepdim=True)
        return logits, probs, top_idx, top_vals

N, D, E, K = 16, 32, 8, 2
x = torch.randn(N, D)
router = Router(D, E, K)
logits, probs, idx, vals = router(x)

print("shape logits :", tuple(logits.shape))
print("shape probs  :", tuple(probs.shape))
print("shape idx    :", tuple(idx.shape))
print("shape vals   :", tuple(vals.shape))
print("token 0 -> experts", idx[0].tolist(), "weights", [f"{v:.3f}" for v in vals[0].tolist()])
print("token 1 -> experts", idx[1].tolist(), "weights", [f"{v:.3f}" for v in vals[1].tolist()])
print("weight sums (should be 1.0):", vals.sum(dim=-1)[:4].tolist())
