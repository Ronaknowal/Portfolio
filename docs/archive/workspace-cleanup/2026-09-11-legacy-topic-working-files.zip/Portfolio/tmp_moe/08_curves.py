"""Generate expert-usage curves over training steps for the Plot."""
import torch
import torch.nn as nn
import torch.nn.functional as F
import json

def aux_loss(probs, top_idx, E):
    P = probs.mean(0)
    f = F.one_hot(top_idx[:, 0], E).float().mean(0)
    return E * (f * P).sum()

class Tiny(nn.Module):
    def __init__(self, D, E, K):
        super().__init__()
        self.r = nn.Linear(D, E)
        self.exp = nn.ModuleList([nn.Linear(D, D) for _ in range(E)])
        self.K, self.E = K, E
    def forward(self, x):
        logits = self.r(x); probs = F.softmax(logits, -1)
        tv, ti = probs.topk(self.K, -1)
        tv = tv / tv.sum(-1, True)
        out = torch.zeros_like(x)
        for e in range(self.E):
            mask = (ti == e)
            if not mask.any(): continue
            idx, slot = mask.nonzero(as_tuple=True)
            w = tv[idx, slot].unsqueeze(-1)
            out.index_add_(0, idx, w * self.exp[e](x[idx]))
        return out, probs, ti

def run(use_aux, steps=600, seed=7, N=64, D=16, E=8, K=2):
    torch.manual_seed(seed)
    W = torch.randn(D, D)
    m = Tiny(D, E, K)
    opt = torch.optim.Adam(m.parameters(), lr=3e-3)
    max_series = []
    for step in range(steps):
        x = torch.randn(N, D)
        y, probs, ti = m(x)
        loss = F.mse_loss(y, x @ W)
        if use_aux:
            loss = loss + 0.3 * aux_loss(probs, ti, E)
        opt.zero_grad(); loss.backward(); opt.step()
        top1 = ti[:, 0]
        frac = F.one_hot(top1, E).float().mean(0)
        max_series.append(frac.max().item())
    return max_series

bad = run(False)
good = run(True)

# Subsample to ~30 points for the plot
def subsample(a, n=30):
    step = max(1, len(a) // n)
    return [(i, round(a[i], 3)) for i in range(0, len(a), step)]

print("no_aux  =", subsample(bad))
print("yes_aux =", subsample(good))

with open("curves.json", "w") as f:
    json.dump({
        "no_aux": subsample(bad),
        "yes_aux": subsample(good),
    }, f)
