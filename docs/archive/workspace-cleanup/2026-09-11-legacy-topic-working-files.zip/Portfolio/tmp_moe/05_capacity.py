"""4e. Capacity factor and token dropping."""
import torch
import torch.nn.functional as F

torch.manual_seed(2)

def dispatch_with_capacity(router_logits, top_k, capacity_factor):
    """
    Simulate Switch/GShard-style capacity: each expert can process at most
      cap = ceil(N * top_k / E * capacity_factor)
    tokens. Tokens beyond capacity are DROPPED (they will bypass the MoE layer
    via the residual connection in the full model).
    """
    N, E = router_logits.shape
    probs = F.softmax(router_logits, -1)
    top_vals, top_idx = probs.topk(top_k, -1)         # (N, k)
    top_vals = top_vals / top_vals.sum(-1, True)

    cap = int((N * top_k / E) * capacity_factor + 0.999)  # ceil
    assigned = torch.zeros_like(top_idx, dtype=torch.bool)
    counts = torch.zeros(E, dtype=torch.long)
    for t in range(N):
        for s in range(top_k):
            e = top_idx[t, s].item()
            if counts[e] < cap:
                assigned[t, s] = True
                counts[e] += 1
            # else: dropped

    total_slots = N * top_k
    kept = assigned.sum().item()
    dropped = total_slots - kept
    return {"capacity": cap, "counts": counts.tolist(),
            "kept": kept, "dropped": dropped, "drop_rate": dropped / total_slots}


# Simulate a batch with router logits that slightly prefer E0 (the realistic case).
N, E, K = 256, 8, 2
logits = torch.randn(N, E)
logits[:, 0] += 0.5  # mild bias toward E0 (realistic post-aux-loss residual skew)

print(f"batch N={N}, E={E}, top_k={K}")
print(f"uniform-load expert capacity (no margin) = N*k/E = {N*K/E:.0f}")
print()
print(f"{'factor':>8}  {'capacity':>8}  {'kept':>6}  {'dropped':>8}  {'drop%':>7}  counts")
print("-" * 80)
for cf in [0.75, 1.0, 1.25, 1.5, 2.0]:
    r = dispatch_with_capacity(logits, K, cf)
    pct = 100 * r["drop_rate"]
    counts = " ".join(f"{c:3d}" for c in r["counts"])
    print(f"{cf:>8.2f}  {r['capacity']:>8d}  {r['kept']:>6d}  {r['dropped']:>8d}  {pct:>6.1f}%  [{counts}]")
