"""4c. Expert forward + combine — complete MoE layer."""
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.manual_seed(0)

class Expert(nn.Module):
    """A standard FFN: Linear -> GELU -> Linear."""
    def __init__(self, d_model, d_hidden):
        super().__init__()
        self.fc1 = nn.Linear(d_model, d_hidden)
        self.fc2 = nn.Linear(d_hidden, d_model)
    def forward(self, x):
        return self.fc2(F.gelu(self.fc1(x)))

class MoELayer(nn.Module):
    def __init__(self, d_model, d_hidden, num_experts, top_k):
        super().__init__()
        self.router = nn.Linear(d_model, num_experts, bias=False)
        self.experts = nn.ModuleList(
            [Expert(d_model, d_hidden) for _ in range(num_experts)]
        )
        self.k, self.E = top_k, num_experts

    def forward(self, x):
        # x: (N, D)
        N, D = x.shape
        logits = self.router(x)                        # (N, E)
        probs = F.softmax(logits, dim=-1)              # (N, E)
        top_vals, top_idx = probs.topk(self.k, -1)     # (N, k)
        top_vals = top_vals / top_vals.sum(-1, True)   # renormalize

        out = torch.zeros_like(x)
        for e in range(self.E):
            # Which (token, slot) pairs chose expert e?
            mask = (top_idx == e)                      # (N, k) bool
            if not mask.any():
                continue
            tok_idx, slot = mask.nonzero(as_tuple=True)  # each (M,)
            expert_out = self.experts[e](x[tok_idx])   # (M, D)
            weights = top_vals[tok_idx, slot].unsqueeze(-1)  # (M, 1)
            out.index_add_(0, tok_idx, weights * expert_out)

        return out, logits, top_idx

N, D, H, E, K = 16, 32, 64, 8, 2
x = torch.randn(N, D)
moe = MoELayer(D, H, E, K)
y, logits, idx = moe(x)

print("input shape  :", tuple(x.shape))
print("output shape :", tuple(y.shape))
print("top_idx[0:3] :", idx[:3].tolist())

# Sanity: total parameters vs active parameters
total = sum(p.numel() for p in moe.parameters())
expert_params = sum(p.numel() for p in moe.experts[0].parameters())
router_params = sum(p.numel() for p in moe.router.parameters())
active = router_params + K * expert_params
print(f"\ntotal params  : {total:,}")
print(f"active / tok  : {active:,}  ({100*active/total:.1f}%)")
print(f"sparsity gain : {total/active:.1f}x")
