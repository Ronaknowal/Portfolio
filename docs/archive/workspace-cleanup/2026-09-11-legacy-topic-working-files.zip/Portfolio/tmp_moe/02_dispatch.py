"""4b. Token dispatch — gather tokens by expert."""
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.manual_seed(0)

N, D, E, K = 16, 32, 8, 2

class Router(nn.Module):
    def __init__(self, d, e, k):
        super().__init__()
        self.W_r = nn.Linear(d, e, bias=False)
        self.k, self.e = k, e
    def forward(self, x):
        logits = self.W_r(x)
        probs = F.softmax(logits, dim=-1)
        v, i = probs.topk(self.k, dim=-1)
        v = v / v.sum(-1, keepdim=True)
        return logits, probs, i, v

x = torch.randn(N, D)
router = Router(D, E, K)
_, _, idx, vals = router(x)  # idx: (N, K)

# Dispatch: for each expert, collect the (token_index, slot, weight) triples.
# slot = which of the K choices routed this token here (0 or 1).
buckets = {e: [] for e in range(E)}
for t in range(N):
    for s in range(K):
        e = idx[t, s].item()
        w = vals[t, s].item()
        buckets[e].append((t, s, w))

print(f"N={N} tokens, E={E} experts, k={K}")
print(f"expected avg per expert = N*k/E = {N*K/E:.2f}")
print()
for e in range(E):
    toks = [t for t, _, _ in buckets[e]]
    print(f"expert {e}: {len(toks):2d} tokens -> {toks}")

load = torch.tensor([len(buckets[e]) for e in range(E)], dtype=torch.float)
print(f"\nload stats: min={load.min().item():.0f}  max={load.max().item():.0f}  "
      f"mean={load.mean().item():.2f}  std={load.std().item():.2f}")
