"""4f. Shared + routed experts (DeepSeek-style)."""
import torch
import torch.nn as nn
import torch.nn.functional as F

class Expert(nn.Module):
    def __init__(self, d, h):
        super().__init__()
        self.fc1 = nn.Linear(d, h)
        self.fc2 = nn.Linear(h, d)
    def forward(self, x):
        return self.fc2(F.gelu(self.fc1(x)))

class SharedRoutedMoE(nn.Module):
    """
    DeepSeek-V2/V3 style:
      - `n_shared` experts that ALWAYS run on every token
      - `n_routed` experts, of which the router picks top-k
    Output = shared_output + routed_output
    """
    def __init__(self, d_model, d_hidden_routed, d_hidden_shared,
                 n_shared, n_routed, top_k):
        super().__init__()
        self.shared = nn.ModuleList(
            [Expert(d_model, d_hidden_shared) for _ in range(n_shared)]
        )
        self.routed = nn.ModuleList(
            [Expert(d_model, d_hidden_routed) for _ in range(n_routed)]
        )
        self.router = nn.Linear(d_model, n_routed, bias=False)
        self.K, self.N_r, self.N_s = top_k, n_routed, n_shared

    def forward(self, x):
        # shared path — every expert runs, sum their outputs
        shared_out = sum(e(x) for e in self.shared)

        # routed path — top-k
        logits = self.router(x)
        probs = F.softmax(logits, -1)
        top_vals, top_idx = probs.topk(self.K, -1)
        top_vals = top_vals / top_vals.sum(-1, True)

        routed_out = torch.zeros_like(x)
        for e in range(self.N_r):
            mask = (top_idx == e)
            if not mask.any():
                continue
            ti, slot = mask.nonzero(as_tuple=True)
            w = top_vals[ti, slot].unsqueeze(-1)
            routed_out.index_add_(0, ti, w * self.routed[e](x[ti]))

        return shared_out + routed_out


# Compare: vanilla MoE (8 experts, top-2) vs shared+routed (1 shared + 7 routed, top-2)
# Fix TOTAL parameters and compare ACTIVE-per-token.
D = 128

# vanilla MoE: 8 experts each of hidden=512
vanilla_h = 512
vanilla = nn.ModuleList([Expert(D, vanilla_h) for _ in range(8)])
vanilla_router = nn.Linear(D, 8)

# shared+routed: 1 shared (fat) + 7 routed. Keep each routed expert at fine-grained hidden=256;
# shared expert absorbs the "always-on" capacity at hidden=512.
sr = SharedRoutedMoE(d_model=D, d_hidden_routed=256, d_hidden_shared=512,
                      n_shared=1, n_routed=7, top_k=2)

def total(m):
    return sum(p.numel() for p in m.parameters())

def expert_params(e):
    return sum(p.numel() for p in e.parameters())

print("Vanilla MoE  (8 experts, top-2)")
total_v = sum(expert_params(e) for e in vanilla) + sum(p.numel() for p in vanilla_router.parameters())
active_v = sum(p.numel() for p in vanilla_router.parameters()) + 2 * expert_params(vanilla[0])
print(f"  total params  : {total_v:,}")
print(f"  active / tok  : {active_v:,}  ({100*active_v/total_v:.1f}%)")

print("\nShared+Routed  (1 shared + 7 routed, top-2)")
total_sr = total(sr)
shared_size = expert_params(sr.shared[0])
routed_size = expert_params(sr.routed[0])
router_size = sum(p.numel() for p in sr.router.parameters())
active_sr = router_size + shared_size + 2 * routed_size
print(f"  total params  : {total_sr:,}")
print(f"  shared expert : {shared_size:,}  (always active)")
print(f"  routed expert : {routed_size:,}  (2 of 7 active)")
print(f"  active / tok  : {active_sr:,}  ({100*active_sr/total_sr:.1f}%)")

# Forward pass
x = torch.randn(16, D)
y = sr(x)
print(f"\nshared+routed forward: in {tuple(x.shape)} -> out {tuple(y.shape)}")

# Real scale: Mixtral vs DeepSeek numbers
print()
print("Real-world comparison")
print(f"  Mixtral 8x7B     : 8 experts, top-2  ->  47B total /  13B active  (27%)")
print(f"  DeepSeek-V2      : 1 shared + 160 routed, top-6  ->  236B total / 21B active  (9%)")
print(f"  DeepSeek-V3      : 1 shared + 256 routed, top-8  ->  671B total / 37B active  (5.5%)")
