"""Generate token-to-expert routing heatmaps for the visual section.

Before training: router bias collapses traffic on one expert.
After training with aux loss: routing spreads across experts.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

def aux_loss(probs, top_idx, E):
    P = probs.mean(0)
    top1 = top_idx[:, 0]
    f = F.one_hot(top1, E).float().mean(0)
    return E * (f * P).sum()

class Tiny(nn.Module):
    def __init__(self, D, E, K, bias=None):
        super().__init__()
        self.r = nn.Linear(D, E, bias=True)
        if bias is not None:
            with torch.no_grad():
                self.r.bias.zero_()
                self.r.bias[bias] = 1.0
        self.K, self.E = K, E
        # tiny "identity-ish" experts so the loss can actually be low
        self.exp = nn.ModuleList([nn.Linear(D, D) for _ in range(E)])

    def route(self, x):
        logits = self.r(x)
        probs = F.softmax(logits, -1)
        tv, ti = probs.topk(self.K, -1)
        tv = tv / tv.sum(-1, True)
        return logits, probs, ti, tv

    def forward(self, x):
        logits, probs, ti, tv = self.route(x)
        out = torch.zeros_like(x)
        for e in range(self.E):
            mask = (ti == e)
            if not mask.any(): continue
            idx, slot = mask.nonzero(as_tuple=True)
            w = tv[idx, slot].unsqueeze(-1)
            out.index_add_(0, idx, w * self.exp[e](x[idx]))
        return out, logits, probs, ti

torch.manual_seed(7)
D, E, K = 16, 8, 2
W = torch.randn(D, D)
x_show = torch.randn(8, D)

# BEFORE: train WITHOUT aux loss -> routing collapses onto a few experts.
m_bad = Tiny(D, E, K, bias=0)
opt_b = torch.optim.Adam(m_bad.parameters(), lr=3e-3)
for _ in range(800):
    x = torch.randn(64, D)
    y, _, _, _ = m_bad(x)
    loss = F.mse_loss(y, x @ W)
    opt_b.zero_grad(); loss.backward(); opt_b.step()
_, _, probs_before, _ = m_bad(x_show)

# AFTER: train WITH aux loss -> routing balances across experts.
torch.manual_seed(7)
m_good = Tiny(D, E, K, bias=0)
opt_g = torch.optim.Adam(m_good.parameters(), lr=3e-3)
for _ in range(800):
    x = torch.randn(64, D)
    y, _, probs, ti = m_good(x)
    loss = F.mse_loss(y, x @ W) + 0.3 * aux_loss(probs, ti, E)
    opt_g.zero_grad(); loss.backward(); opt_g.step()
_, _, probs_after, _ = m_good(x_show)

# Format as 8x8 matrices rounded to 2 decimals
print("BEFORE (trained without aux loss -> collapse):")
for row in probs_before.tolist():
    print("  [" + ", ".join(f"{v:.2f}" for v in row) + "],")
print()
print("AFTER (trained with aux_w=0.3):")
for row in probs_after.tolist():
    print("  [" + ", ".join(f"{v:.2f}" for v in row) + "],")
