"""Production library test with datasketch MinHashLSH."""
from datasketch import MinHash, MinHashLSH

def shingles(doc, n=5):
    toks = doc.split()
    return {" ".join(toks[i:i+n]) for i in range(len(toks) - n + 1)}

def to_mh(doc, num_perm=128):
    m = MinHash(num_perm=num_perm)
    for sh in shingles(doc, n=3):
        m.update(sh.encode("utf-8"))
    return m

docs = {
    "a1": "Rust is a systems programming language with ownership and zero-cost abstractions.",
    "a2": "Rust is a systems programming language with ownership types and zero-cost abstractions.",
    "a3": "Rust is systems programming with ownership types and zero cost abstractions everywhere.",
    "b1": "Bloom filters allow compact set membership with a tunable false positive rate.",
    "b2": "Bloom filters provide compact set membership with a tunable false positive rate.",
    "c1": "Pasta al dente requires well-salted boiling water and precise cooking timing.",
}

lsh = MinHashLSH(threshold=0.4, num_perm=128)
mhs = {k: to_mh(v) for k, v in docs.items()}
for k, mh in mhs.items():
    lsh.insert(k, mh)

print("production datasketch MinHashLSH, threshold=0.4, num_perm=128")
for k in docs:
    near = [x for x in lsh.query(mhs[k]) if x != k]
    print(f"  {k}: near-dups -> {sorted(near)}")
