import torch
import torch.nn as nn
import torch.nn.functional as F
import time

torch.manual_seed(0)

# A toy hybrid block: one layer is "Mamba-like" (a simplified diagonal recurrent SSM),
# another is standard causal self-attention.  Both wrapped with LayerNorm + residual + FFN.

class SimpleSSM(nn.Module):
    """A simplified selective SSM, diagonal A, serial scan for clarity."""
    def __init__(self, d_model, d_state=8):
        super().__init__()
        self.d_model = d_model
        self.d_state = d_state
        self.x_proj = nn.Linear(d_model, 2 * d_state + 1, bias=False)
        self.dt_proj = nn.Linear(1, d_model, bias=True)
        self.A_log = nn.Parameter(torch.log(torch.arange(1, d_state + 1, dtype=torch.float32)))
        self.D = nn.Parameter(torch.zeros(d_model))
        self.out_proj = nn.Linear(d_model, d_model, bias=False)

    def forward(self, u):
        B, L, D = u.shape
        N = self.d_state
        x_dbl = self.x_proj(u)
        dt_raw = x_dbl[..., :1]
        B_t = x_dbl[..., 1:1+N]
        C_t = x_dbl[..., 1+N:1+2*N]
        delta = F.softplus(self.dt_proj(dt_raw))
        A = -torch.exp(self.A_log)
        A_bar = torch.exp(delta.unsqueeze(-1) * A.view(1, 1, 1, N))
        B_bar = delta.unsqueeze(-1) * B_t.unsqueeze(2)
        h = torch.zeros(B, D, N, device=u.device)
        ys = []
        for t in range(L):
            h = A_bar[:, t] * h + B_bar[:, t] * u[:, t].unsqueeze(-1)
            y = (h * C_t[:, t].unsqueeze(1)).sum(dim=-1)
            ys.append(y)
        y = torch.stack(ys, dim=1)
        y = y + self.D.view(1, 1, -1) * u
        return self.out_proj(y)


class CausalSelfAttention(nn.Module):
    def __init__(self, d_model, n_heads=4):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.qkv = nn.Linear(d_model, 3 * d_model, bias=False)
        self.out = nn.Linear(d_model, d_model, bias=False)

    def forward(self, x):
        B, L, D = x.shape
        H, Hd = self.n_heads, self.head_dim
        qkv = self.qkv(x).reshape(B, L, 3, H, Hd).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        attn = (q @ k.transpose(-2, -1)) / (Hd ** 0.5)
        mask = torch.triu(torch.ones(L, L, device=x.device, dtype=torch.bool), diagonal=1)
        attn = attn.masked_fill(mask, float("-inf"))
        attn = attn.softmax(dim=-1)
        out = (attn @ v).transpose(1, 2).reshape(B, L, D)
        return self.out(out)


class FFN(nn.Module):
    def __init__(self, d_model, mult=2):
        super().__init__()
        self.fc1 = nn.Linear(d_model, mult * d_model)
        self.fc2 = nn.Linear(mult * d_model, d_model)
    def forward(self, x):
        return self.fc2(F.silu(self.fc1(x)))


class HybridBlock(nn.Module):
    """A single block: either Mamba-style or Attention, then FFN."""
    def __init__(self, d_model, kind, d_state=8, n_heads=4):
        super().__init__()
        self.kind = kind
        self.ln1 = nn.LayerNorm(d_model)
        self.ln2 = nn.LayerNorm(d_model)
        if kind == "mamba":
            self.mixer = SimpleSSM(d_model, d_state=d_state)
        elif kind == "attn":
            self.mixer = CausalSelfAttention(d_model, n_heads=n_heads)
        self.ffn = FFN(d_model)

    def forward(self, x):
        x = x + self.mixer(self.ln1(x))
        x = x + self.ffn(self.ln2(x))
        return x


class TinyLM(nn.Module):
    """A tiny causal LM.  Layout determined by `layout` (a list of 'mamba'/'attn')."""
    def __init__(self, vocab, d_model, layout, d_state=8, n_heads=4):
        super().__init__()
        self.embed = nn.Embedding(vocab, d_model)
        self.blocks = nn.ModuleList([
            HybridBlock(d_model, kind, d_state=d_state, n_heads=n_heads) for kind in layout
        ])
        self.ln_f = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, vocab, bias=False)
        self.layout = layout

    def forward(self, idx):
        x = self.embed(idx)
        for blk in self.blocks:
            x = blk(x)
        x = self.ln_f(x)
        return self.head(x)


# A copy task: predict token from K positions ago.  Pure-Mamba struggles with
# precise content-dependent retrieval, attention/hybrid does it cleanly.
def make_batch(B, L, V, offset):
    x = torch.randint(0, V, (B, L))
    y = x.clone()
    y[:, :offset] = -100
    y[:, offset:] = x[:, :L - offset]
    return x, y

def train_model(layout, steps=400, lr=3e-3, B=64, L=32, V=8, offset=4, label=""):
    torch.manual_seed(42)
    model = TinyLM(V, d_model=32, layout=layout, d_state=8, n_heads=4)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.CrossEntropyLoss(ignore_index=-100)
    losses = []
    for s in range(steps):
        x, y = make_batch(B, L, V, offset)
        logits = model(x)
        loss = loss_fn(logits.reshape(-1, V), y.reshape(-1))
        opt.zero_grad(); loss.backward(); opt.step()
        if s % 100 == 0 or s == steps - 1:
            preds = logits.argmax(dim=-1)
            mask = (y != -100)
            acc = ((preds == y) & mask).float().sum() / mask.float().sum()
            losses.append((s, loss.item(), acc.item()))
    n = sum(p.numel() for p in model.parameters())
    print(f"\n[{label}]  layout={layout}  params={n}")
    print(f"{'step':>5}  {'loss':>7}  {'acc':>6}")
    for s, l, a in losses:
        print(f"{s:>5}  {l:>7.4f}  {a:>5.3f}")
    return model

print("=" * 60)
print("Comparing pure-Mamba vs pure-Attention vs Hybrid on copy task")
print("=" * 60)

m1 = train_model(["mamba"] * 4,                       label="Pure-Mamba (4 layers)")
m2 = train_model(["attn"] * 4,                        label="Pure-Attn  (4 layers)")
m3 = train_model(["mamba", "mamba", "mamba", "attn"], label="Hybrid 3:1 (4 layers)")
