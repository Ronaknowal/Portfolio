"""Compute plot/heatmap data tables for the topic."""
import math

# LSH probability curve: P(share a band) = 1 - (1 - s^r)^b
print("LSH band-matching probability table (rows -> across; bands matching)")
print("s \\  (b,r)   (32,4)   (20,5)   (10,10)")
for s in [0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]:
    row = []
    for b, r in [(32, 4), (20, 5), (10, 10)]:
        p = 1 - (1 - s ** r) ** b
        row.append(f"{p:6.3f}")
    print(f"{s:.1f}        {'  '.join(row)}")

print()
# Bloom FP rate vs bits/item (m/n) for several k
print("Bloom false-positive rate vs bits-per-item (m/n):")
print("m/n \\  k    k=4       k=6       k=8       k=10")
for mn in [4, 6, 8, 10, 12, 14, 16, 20, 24]:
    row = []
    for k in [4, 6, 8, 10]:
        fp = (1 - math.exp(-k / mn)) ** k
        row.append(f"{fp:8.5f}")
    print(f"{mn:3d}       {'  '.join(row)}")

print()
# Self-check: MinHash signature memory for 1M docs, 128-hash, 64-bit each
print("Self-check computed answers:")
docs = 1_000_000
hashes = 128
bytes_per_hash = 8
total = docs * hashes * bytes_per_hash
print(f"  1M docs × 128 hashes × 8 bytes = {total:,} bytes = {total/1024/1024/1024:.2f} GB")

# 1B URLs, 0.1% FP
n, p = 1_000_000_000, 0.001
m = -n * math.log(p) / (math.log(2) ** 2)
k = (m / n) * math.log(2)
print(f"  1B URLs @ 0.1% FP: m={m/8/1024/1024/1024:.2f} GB bits, k={k:.1f} hashes")

# Jaccard estimate from 10/32 matches
print(f"  10/32 MinHash agreement -> J_est = {10/32:.3f}")
