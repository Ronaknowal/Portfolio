"""Verification script for data curation & dedup topic - runs all from-scratch code."""
import hashlib
import math
import random
from collections import defaultdict


# ---------------------------------------------------------------------------
# 4a. Shingles
# ---------------------------------------------------------------------------
def shingles(doc, n=5):
    tokens = doc.split()
    if len(tokens) < n:
        return {" ".join(tokens)}
    return {" ".join(tokens[i:i + n]) for i in range(len(tokens) - n + 1)}


print("=" * 70)
print("4a. Shingles")
print("=" * 70)
ex = "the quick brown fox jumps over the lazy dog by the river"
sh = shingles(ex, n=5)
print(f"doc tokens: {len(ex.split())}")
print(f"# shingles (n=5): {len(sh)}")
for s in sorted(sh)[:3]:
    print(f"  - {s!r}")
print()


# ---------------------------------------------------------------------------
# 4b. MinHash from scratch
# ---------------------------------------------------------------------------
def minhash(doc, num_hashes=128, n=5):
    shings = shingles(doc, n=n)
    sig = [float("inf")] * num_hashes
    for sh in shings:
        for i in range(num_hashes):
            h = int(hashlib.md5(f"{i}:{sh}".encode()).hexdigest(), 16)
            if h < sig[i]:
                sig[i] = h
    return sig


def true_jaccard(a, b, n=5):
    sa, sb = shingles(a, n=n), shingles(b, n=n)
    return len(sa & sb) / max(1, len(sa | sb))


def estimated_jaccard(sig_a, sig_b):
    return sum(a == b for a, b in zip(sig_a, sig_b)) / len(sig_a)


print("=" * 70)
print("4b. MinHash signatures (128 hashes)")
print("=" * 70)
doc_a = ("Large language models are trained on trillions of tokens "
         "scraped from the public web and curated for quality "
         "before being fed into the training pipeline at scale")
doc_b = ("Modern language models are trained on trillions of tokens "
         "scraped from the public web and filtered for quality "
         "before being fed into the training pipeline at scale")
doc_c = ("Bloom filters are a compact probabilistic data structure "
         "that supports efficient membership queries with a tunable "
         "false positive rate and zero false negatives")

for n in (3, 5):
    jab = true_jaccard(doc_a, doc_b, n=n)
    jac = true_jaccard(doc_a, doc_c, n=n)
    ea = minhash(doc_a, 128, n=n)
    eb = minhash(doc_b, 128, n=n)
    ec = minhash(doc_c, 128, n=n)
    print(f"n={n}  J(A,B)_true={jab:.3f}  J(A,B)_est={estimated_jaccard(ea, eb):.3f}  "
          f"J(A,C)_true={jac:.3f}  J(A,C)_est={estimated_jaccard(ea, ec):.3f}")
print()


# ---------------------------------------------------------------------------
# 4c. LSH banding
# ---------------------------------------------------------------------------
def lsh_candidates(sigs, bands=32, rows=4):
    assert bands * rows == len(next(iter(sigs.values())))
    buckets = defaultdict(list)
    for doc_id, sig in sigs.items():
        for b in range(bands):
            band = tuple(sig[b * rows:(b + 1) * rows])
            key = (b, hash(band))
            buckets[key].append(doc_id)
    cands = set()
    for ids in buckets.values():
        if len(ids) < 2:
            continue
        for i in range(len(ids)):
            for j in range(i + 1, len(ids)):
                cands.add(tuple(sorted((ids[i], ids[j]))))
    return cands


print("=" * 70)
print("4c. LSH banding (32 bands of 4 rows)")
print("=" * 70)
# synthetic mini-corpus: 3 near-dup clusters + unrelated
random.seed(0)
base1 = "the capital of france is paris and its population is about two million people"
base2 = "rust is a systems programming language with ownership types and zero cost abstractions"
base3 = "bloom filters allow compact set membership with a configurable false positive probability"

def perturb(s, rate=0.1):
    toks = s.split()
    return " ".join(
        t if random.random() > rate else random.choice(["the", "a", "some", "one"])
        for t in toks
    )

corpus = {}
for i in range(5):
    corpus[f"fr{i}"] = perturb(base1, rate=0.08)
for i in range(5):
    corpus[f"rs{i}"] = perturb(base2, rate=0.08)
for i in range(5):
    corpus[f"bf{i}"] = perturb(base3, rate=0.08)
corpus["out1"] = "unrelated document about lunar geology and impact craters across the surface"
corpus["out2"] = "cooking pasta al dente requires well-salted boiling water and precise timing"

sigs = {k: minhash(v, 128, n=3) for k, v in corpus.items()}
cands = lsh_candidates(sigs, bands=32, rows=4)
# count cross-cluster contamination
def cluster(name):
    return name[:2]
within = sum(1 for (a, b) in cands if cluster(a) == cluster(b))
across = sum(1 for (a, b) in cands if cluster(a) != cluster(b))
print(f"corpus size: {len(corpus)}")
print(f"candidate pairs found: {len(cands)}")
print(f"  within-cluster: {within}   cross-cluster: {across}")
print(f"sample candidate pairs: {sorted(cands)[:4]}")
print()


# ---------------------------------------------------------------------------
# 4d. Bloom filter from scratch
# ---------------------------------------------------------------------------
class BloomFilter:
    def __init__(self, n_items, fp_rate=0.001):
        self.m = int(-n_items * math.log(fp_rate) / (math.log(2) ** 2))
        self.k = max(1, int((self.m / n_items) * math.log(2)))
        self.bits = bytearray(self.m // 8 + 1)
        self.n = 0

    def _hashes(self, item):
        item_bytes = item.encode() if isinstance(item, str) else item
        h1 = int(hashlib.md5(item_bytes).hexdigest(), 16)
        h2 = int(hashlib.sha1(item_bytes).hexdigest(), 16)
        for i in range(self.k):
            yield (h1 + i * h2) % self.m

    def add(self, item):
        for h in self._hashes(item):
            self.bits[h // 8] |= 1 << (h % 8)
        self.n += 1

    def __contains__(self, item):
        return all(self.bits[h // 8] & (1 << (h % 8)) for h in self._hashes(item))

    def expected_fp_rate(self):
        return (1 - math.exp(-self.k * self.n / self.m)) ** self.k


print("=" * 70)
print("4d. Bloom filter: 10K items, target FP rate 1%")
print("=" * 70)
bf = BloomFilter(n_items=10_000, fp_rate=0.01)
print(f"m={bf.m:,} bits   k={bf.k}   memory={bf.m/8/1024:.1f} KiB")

random.seed(1)
inserted = [f"url_{i}_{random.randint(0, 10**9)}" for i in range(10_000)]
for u in inserted:
    bf.add(u)

# check: all inserted are present (no false negatives)
false_neg = sum(1 for u in inserted if u not in bf)
print(f"false negatives on {len(inserted)} inserted items: {false_neg}")

# FP rate on held-out items
held_out = [f"held_{i}_{random.randint(0, 10**9)}" for i in range(100_000)]
fp = sum(1 for u in held_out if u in bf)
print(f"false positives on {len(held_out)} held-out items: {fp}  "
      f"(observed FP rate {fp/len(held_out):.4f})")
print(f"theoretical FP rate at n=10K: {bf.expected_fp_rate():.4f}")
print()


# ---------------------------------------------------------------------------
# 4e. Pipeline
# ---------------------------------------------------------------------------
def dedup_pipeline(docs, bloom_fp=0.001, bands=32, rows=4, n_shingle=3):
    # stage 1: URL-level bloom
    url_seen = BloomFilter(n_items=max(len(docs), 1000), fp_rate=bloom_fp)
    stage1 = []
    for url, text in docs:
        if url in url_seen:
            continue
        url_seen.add(url)
        stage1.append((url, text))

    # stage 2: MinHash+LSH clustering
    sigs = {url: minhash(text, bands * rows, n=n_shingle) for url, text in stage1}
    cands = lsh_candidates(sigs, bands=bands, rows=rows)
    # union-find on candidate pairs
    parent = {url: url for url, _ in stage1}
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb
    for a, b in cands:
        # tighten with an estimated-Jaccard threshold to avoid false LSH pairings
        if estimated_jaccard(sigs[a], sigs[b]) >= 0.7:
            union(a, b)
    # keep one representative per cluster
    seen_root = {}
    stage2 = []
    for url, text in stage1:
        root = find(url)
        if root in seen_root:
            continue
        seen_root[root] = True
        stage2.append((url, text))
    return stage1, stage2


print("=" * 70)
print("4e. End-to-end pipeline on synthetic near-dup corpus")
print("=" * 70)
# construct a corpus with URL dups + near-dup clusters
random.seed(2)
raw = []
for i in range(20):
    raw.append((f"https://a.com/{i}", perturb(base1, rate=0.08)))
for i in range(20):
    raw.append((f"https://b.com/{i}", perturb(base2, rate=0.08)))
for i in range(20):
    raw.append((f"https://c.com/{i}", perturb(base3, rate=0.08)))
# duplicate some URLs
for i in range(30):
    raw.append(raw[i % 10])
# unique noise
for i in range(20):
    raw.append((f"https://n.com/{i}",
                " ".join(random.choices("alpha beta gamma delta epsilon zeta eta theta iota".split(), k=15))))

print(f"raw input: {len(raw)} docs")
stage1, stage2 = dedup_pipeline(raw)
print(f"after URL bloom dedup:     {len(stage1)} docs  (removed {len(raw)-len(stage1)})")
print(f"after MinHash+LSH dedup:   {len(stage2)} docs  (removed {len(stage1)-len(stage2)})")
print(f"overall reduction:         {len(raw)} -> {len(stage2)}  "
      f"({(1-len(stage2)/len(raw))*100:.1f}% removed)")
