import torch
import torch.nn as nn
import torch.nn.functional as F
import time

torch.manual_seed(0)

# Compare per-token decode latency: pure-Mamba vs pure-Attention vs Hybrid 1:7
# All on CPU with the same model dim, varying context length L.

class MiniSSM(nn.Module):
    """Diagonal selective SSM, recurrent step (no scan) — represents inference cost."""
    def __init__(self, d_model, d_state=16):
        super().__init__()
        self.d_state = d_state
        self.d_model = d_model
        self.x_proj = nn.Linear(d_model, 2 * d_state + 1, bias=False)
        self.dt_proj = nn.Linear(1, d_model, bias=True)
        self.A_log = nn.Parameter(torch.log(torch.arange(1, d_state + 1, dtype=torch.float32)))
        self.out = nn.Linear(d_model, d_model, bias=False)

    def step(self, u_t, state):
        # u_t: [B, D]; state: [B, D, N] -> y_t: [B, D], new_state: [B, D, N]
        B, D = u_t.shape
        N = self.d_state
        x_dbl = self.x_proj(u_t)
        dt_raw = x_dbl[:, :1]
        B_t = x_dbl[:, 1:1+N]
        C_t = x_dbl[:, 1+N:1+2*N]
        delta = F.softplus(self.dt_proj(dt_raw))     # [B, D]
        A = -torch.exp(self.A_log)                    # [N]
        A_bar = torch.exp(delta.unsqueeze(-1) * A.view(1, 1, N))   # [B, D, N]
        B_bar = delta.unsqueeze(-1) * B_t.unsqueeze(1)             # [B, D, N]
        new_state = A_bar * state + B_bar * u_t.unsqueeze(-1)
        y = (new_state * C_t.unsqueeze(1)).sum(dim=-1)
        return self.out(y), new_state


class MiniAttn(nn.Module):
    """Attention with KV cache — cost grows linearly with cache length."""
    def __init__(self, d_model, n_heads=4):
        super().__init__()
        self.h = n_heads
        self.hd = d_model // n_heads
        self.qkv = nn.Linear(d_model, 3 * d_model, bias=False)
        self.out = nn.Linear(d_model, d_model, bias=False)

    def step(self, u_t, kv_cache):
        # u_t: [B, D]; kv_cache: ([B, T, H, Hd], [B, T, H, Hd]) or None
        B, D = u_t.shape
        H, Hd = self.h, self.hd
        qkv = self.qkv(u_t).reshape(B, 3, H, Hd)
        q, k, v = qkv[:, 0], qkv[:, 1], qkv[:, 2]   # each [B, H, Hd]
        if kv_cache is None:
            K, V = k.unsqueeze(1), v.unsqueeze(1)    # [B, 1, H, Hd]
        else:
            Kp, Vp = kv_cache
            K = torch.cat([Kp, k.unsqueeze(1)], dim=1)
            V = torch.cat([Vp, v.unsqueeze(1)], dim=1)
        # attn: q [B, H, Hd] vs K [B, T, H, Hd] -> [B, H, T]
        attn = torch.einsum("bhd,bthd->bht", q, K) / (Hd ** 0.5)
        attn = attn.softmax(dim=-1)
        out = torch.einsum("bht,bthd->bhd", attn, V).reshape(B, D)
        return self.out(out), (K, V)


def time_decode_pure_mamba(d_model=256, d_state=16, n_layers=8, L=1024, B=1, warmup=2, runs=3):
    layers = [MiniSSM(d_model, d_state=d_state) for _ in range(n_layers)]
    state = [torch.zeros(B, d_model, d_state) for _ in range(n_layers)]
    u = torch.randn(B, d_model)
    # warmup
    s = [s_.clone() for s_ in state]
    for _ in range(warmup):
        x = u
        for li, lyr in enumerate(layers):
            y, s[li] = lyr.step(x, s[li])
            x = x + y
    # time L tokens
    times = []
    for _ in range(runs):
        s = [s_.clone() * 0 for s_ in state]
        t0 = time.perf_counter()
        for _ in range(L):
            x = torch.randn(B, d_model)
            for li, lyr in enumerate(layers):
                y, s[li] = lyr.step(x, s[li])
                x = x + y
        times.append((time.perf_counter() - t0) * 1000)
    return min(times)


def time_decode_pure_attn(d_model=256, n_heads=4, n_layers=8, L=1024, B=1, warmup=2, runs=3):
    layers = [MiniAttn(d_model, n_heads=n_heads) for _ in range(n_layers)]
    cache = [None] * n_layers
    u = torch.randn(B, d_model)
    for _ in range(warmup):
        x = u
        for li, lyr in enumerate(layers):
            y, cache[li] = lyr.step(x, cache[li])
            x = x + y
    times = []
    for _ in range(runs):
        cache = [None] * n_layers
        t0 = time.perf_counter()
        for _ in range(L):
            x = torch.randn(B, d_model)
            for li, lyr in enumerate(layers):
                y, cache[li] = lyr.step(x, cache[li])
                x = x + y
        times.append((time.perf_counter() - t0) * 1000)
    return min(times)


def time_decode_hybrid(d_model=256, d_state=16, n_heads=4, n_layers=8, attn_every=8,
                       L=1024, B=1, warmup=2, runs=3):
    layers = []
    for li in range(n_layers):
        if (li + 1) % attn_every == 0:
            layers.append(("attn", MiniAttn(d_model, n_heads=n_heads)))
        else:
            layers.append(("ssm", MiniSSM(d_model, d_state=d_state)))
    state = [torch.zeros(B, d_model, d_state) if k == "ssm" else None for k, _ in layers]
    cache = [None if k == "ssm" else None for k, _ in layers]
    u = torch.randn(B, d_model)
    for _ in range(warmup):
        x = u
        for li, (k, lyr) in enumerate(layers):
            if k == "ssm":
                y, state[li] = lyr.step(x, state[li])
            else:
                y, cache[li] = lyr.step(x, cache[li])
            x = x + y
    times = []
    for _ in range(runs):
        state = [torch.zeros(B, d_model, d_state) if k == "ssm" else None for k, _ in layers]
        cache = [None] * n_layers
        t0 = time.perf_counter()
        for _ in range(L):
            x = torch.randn(B, d_model)
            for li, (k, lyr) in enumerate(layers):
                if k == "ssm":
                    y, state[li] = lyr.step(x, state[li])
                else:
                    y, cache[li] = lyr.step(x, cache[li])
                x = x + y
        times.append((time.perf_counter() - t0) * 1000)
    return min(times)


print("Per-token decode latency (CPU, d_model=128, n_layers=8, L tokens generated)")
print(f"{'L':>6}  {'Pure-Attn':>11}  {'Pure-Mamba':>11}  {'Hybrid 1:7':>11}")
for L in [128, 512, 2048]:
    t_a = time_decode_pure_attn(d_model=128, n_layers=8, L=L)
    t_m = time_decode_pure_mamba(d_model=128, n_layers=8, L=L)
    t_h = time_decode_hybrid(d_model=128, n_layers=8, attn_every=8, L=L)
    print(f"{L:>6}  {t_a:>9.1f}ms  {t_m:>9.1f}ms  {t_h:>9.1f}ms")

# Also compute the KV-cache vs SSM-state memory footprint
print()
print("Per-layer state size for d_model=4096, d_state=128, fp16/fp32:")
d, n = 4096, 128
print(f"  Mamba state per layer:    {d * n * 4 / (1024**2):.2f} MB (fp32)")
print(f"  KV cache per layer @ 32K: {2 * 32768 * d * 2 / (1024**3):.2f} GB (fp16)")
print(f"  KV cache per layer @256K: {2 * 262144 * d * 2 / (1024**3):.2f} GB (fp16)")
