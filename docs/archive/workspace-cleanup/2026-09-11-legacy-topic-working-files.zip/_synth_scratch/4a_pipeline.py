"""4a. Teacher-prompt-student pipeline skeleton.

A rule-based 'teacher' stands in for a real LLM. Real pipelines swap
MockTeacher for an API call and keep the rest unchanged.
"""
import random
from dataclasses import dataclass

random.seed(0)

TOPICS = ["fractions", "derivatives", "prime numbers", "linear equations",
          "integration by parts"]
STYLES = ["worked example", "definition with motivation", "exercise with answer"]

@dataclass
class Sample:
    topic: str
    style: str
    content: str
    score: float

class MockTeacher:
    """Deterministic-with-noise stand-in for a real LLM teacher."""
    templates = {
        "worked example":
            "Example ({topic}). Take the concrete case below and work through each "
            "step, showing intermediate results and explaining why each step is valid "
            "before combining them into the final answer with care and precision.",
        "definition with motivation":
            "Definition ({topic}). Informally, {topic} answers the question of how "
            "one quantity depends on another. Formally, we state the definition here "
            "and highlight the properties that make it useful in later derivations.",
        "exercise with answer":
            "Exercise ({topic}). Compute the result. Solution: the answer is X, "
            "obtained by applying the standard technique from the chapter above.",
    }
    noise_rates = {
        "worked example": 0.10,
        "definition with motivation": 0.30,
        "exercise with answer": 0.55,
    }
    def generate(self, topic, style):
        text = self.templates[style].format(topic=topic)
        if random.random() < self.noise_rates[style]:
            text = text + " By the way, this reminds me of an unrelated anecdote."
        return text

def quality_classifier(text: str) -> float:
    """Heuristic 'judge' the teacher outputs go through before acceptance."""
    score = min(len(text) / 260.0, 1.0)
    # penalise tell-tale tangent phrases the teacher sometimes emits
    if "anecdote" in text.lower() or "by the way" in text.lower():
        score *= 0.35
    return score

def run(n_per_combo=200, threshold=0.45):
    teacher = MockTeacher()
    pass_rates = {}  # (topic, style) -> rate
    kept_total, seen_total = 0, 0
    for topic in TOPICS:
        for style in STYLES:
            kept, seen = 0, 0
            for _ in range(n_per_combo):
                seen += 1
                t = teacher.generate(topic, style)
                if quality_classifier(t) >= threshold:
                    kept += 1
            pass_rates[(topic, style)] = kept / seen
            kept_total += kept; seen_total += seen
    return pass_rates, kept_total, seen_total

if __name__ == "__main__":
    rates, kept, seen = run()
    print(f"total generated: {seen}  kept: {kept}  pass_rate: {kept/seen:.2%}")
    print()
    print(f"{'topic':<24} | " + " | ".join(f"{s[:10]:>10}" for s in STYLES))
    for topic in TOPICS:
        row = " | ".join(f"{rates[(topic, s)]:>10.2%}" for s in STYLES)
        print(f"{topic:<24} | {row}")
