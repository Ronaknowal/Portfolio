"""4b. Verifier-filtered math synthetic data.

The teacher proposes (problem, answer) pairs. The verifier re-derives the
answer symbolically (sympy) or numerically. Keep only samples where the
teacher's answer matches the verifier.
"""
import random
import sympy as sp

random.seed(0)

x = sp.Symbol("x")

def noisy_teacher_answer(true_ans, error_rate):
    """Simulate a teacher that gets it right most of the time."""
    if random.random() < error_rate:
        # off-by-one, sign flip, dropped term
        kind = random.choice(["plus_one", "neg", "halve"])
        if kind == "plus_one":   return true_ans + 1
        if kind == "neg":        return -true_ans
        if kind == "halve":      return true_ans // 2 if isinstance(true_ans, int) else true_ans / 2
    return true_ans

# three problem templates of increasing difficulty for the teacher
def arithmetic_problem():
    a, b = random.randint(10, 99), random.randint(10, 99)
    return f"{a} * {b} = ?", a * b, 0.10

def linear_eq_problem():
    a, b, c = random.randint(2, 9), random.randint(1, 9), random.randint(10, 50)
    # a*x + b = c -> x = (c - b) / a, force integer answer
    c = a * random.randint(1, 10) + b
    ans = (c - b) // a
    return f"Solve {a}*x + {b} = {c}", ans, 0.25

def derivative_problem():
    a, n = random.randint(2, 6), random.randint(2, 5)
    # d/dx a*x^n = a*n*x^(n-1)
    true = a * n
    # teacher returns numeric coefficient of x^(n-1); simple target
    return f"d/dx {a}*x^{n} at x=1 gives what coefficient?", true, 0.40

GENERATORS = {
    "arithmetic":  arithmetic_problem,
    "linear_eq":   linear_eq_problem,
    "derivative":  derivative_problem,
}

def verify(problem, claimed, kind):
    """Symbolic verification of the teacher's answer."""
    if kind == "arithmetic":
        # parse 'a * b = ?'
        lhs = problem.split(" = ")[0]
        return sp.sympify(lhs) == claimed
    if kind == "linear_eq":
        # 'Solve a*x + b = c'
        body = problem.replace("Solve ", "")
        lhs, rhs = body.split(" = ")
        solved = sp.solve(sp.sympify(lhs) - sp.sympify(rhs), x)
        return len(solved) == 1 and solved[0] == claimed
    if kind == "derivative":
        # recover a,n from the string 'd/dx {a}*x^{n} at x=1 ...'
        left = problem.split("at")[0]
        a_str, n_str = left.replace("d/dx ", "").strip().split("*x^")
        a, n = int(a_str), int(n_str)
        return sp.diff(a * x**n, x).subs(x, 1) == claimed
    return False

def run(n=400):
    stats = {}
    for kind, gen in GENERATORS.items():
        kept, total = 0, 0
        for _ in range(n):
            problem, true_ans, err_rate = gen()
            claimed = noisy_teacher_answer(true_ans, err_rate)
            if verify(problem, claimed, kind):
                kept += 1
            total += 1
        stats[kind] = (kept, total, kept / total)
    return stats

if __name__ == "__main__":
    stats = run()
    print(f"{'domain':<12} | {'kept':>5} | {'total':>5} | {'pass_rate':>9}")
    for k, (kept, total, rate) in stats.items():
        print(f"{k:<12} | {kept:>5} | {total:>5} | {rate:>8.2%}")
