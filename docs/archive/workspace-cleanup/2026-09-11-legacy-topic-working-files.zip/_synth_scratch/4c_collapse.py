"""4c. Model collapse simulation.

Generation 0 has a true Gaussian N(0, 1). At generation k, we fit a Gaussian
to the previous generation's samples (via sample mean and sample variance,
both unbiased estimators) and draw n samples from that fitted Gaussian.
Pure self-training: no fresh samples from the truth enter after generation 0.
"""
import random
import math

random.seed(0)

def box_muller(n, mu, sigma):
    out = []
    while len(out) < n:
        u1, u2 = random.random(), random.random()
        if u1 == 0.0:
            continue
        z0 = math.sqrt(-2.0 * math.log(u1)) * math.cos(2.0 * math.pi * u2)
        z1 = math.sqrt(-2.0 * math.log(u1)) * math.sin(2.0 * math.pi * u2)
        out.append(mu + sigma * z0)
        if len(out) < n:
            out.append(mu + sigma * z1)
    return out

def sample_stats(xs):
    n = len(xs)
    mu = sum(xs) / n
    var = sum((x - mu) ** 2 for x in xs) / n   # MLE (biased) - what you get from fitting
    return mu, math.sqrt(var)

def simulate(mix_real=0.0, n_samples=200, n_generations=50):
    """mix_real in [0,1]: fraction of each generation's training samples drawn
    fresh from the true N(0,1) distribution. 0.0 = pure self-training."""
    mu, sigma = 0.0, 1.0
    history = [(mu, sigma)]
    xs = box_muller(n_samples, mu, sigma)
    for _ in range(n_generations):
        mu_hat, sigma_hat = sample_stats(xs)
        history.append((mu_hat, sigma_hat))
        n_syn = int(round(n_samples * (1 - mix_real)))
        n_real = n_samples - n_syn
        xs = box_muller(n_syn, mu_hat, sigma_hat) + box_muller(n_real, 0.0, 1.0)
    return history

def expected_trajectory(mix_real, n_trials=300, n_samples=200, n_generations=50):
    acc = None
    for t in range(n_trials):
        random.seed(t)
        h = simulate(mix_real, n_samples, n_generations)
        if acc is None:
            acc = [sig ** 2 for _, sig in h]
        else:
            for i, (_, sig) in enumerate(h):
                acc[i] += sig ** 2
    return [v / n_trials for v in acc]

if __name__ == "__main__":
    curves = {
        0.00: expected_trajectory(0.00),
        0.25: expected_trajectory(0.25),
        0.50: expected_trajectory(0.50),
    }
    print(f"{'gen':>3} | " + " | ".join(f"mix={m:.2f}" for m in curves))
    for g in range(0, 51, 5):
        row = " | ".join(f"{curves[m][g]:>7.3f}" for m in curves)
        print(f"{g:>3} | {row}")

    # export the every-5th-generation points for the jsx Plot
    print()
    for m in curves:
        pts = [(g, round(curves[m][g], 3)) for g in range(0, 51, 5)]
        print(f"mix={m:.2f} ->", pts)
