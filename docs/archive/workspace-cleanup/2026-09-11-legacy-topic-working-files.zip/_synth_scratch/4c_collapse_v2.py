"""4c extended: smaller sample size reveals collapse faster.
   Also report collapse on the tail — fraction of samples beyond |x| > 2.
"""
import random, math

def box_muller(n, mu, sigma):
    out = []
    while len(out) < n:
        u1, u2 = random.random(), random.random()
        if u1 == 0: continue
        z0 = math.sqrt(-2*math.log(u1)) * math.cos(2*math.pi*u2)
        z1 = math.sqrt(-2*math.log(u1)) * math.sin(2*math.pi*u2)
        out.append(mu + sigma*z0)
        if len(out) < n:
            out.append(mu + sigma*z1)
    return out

def sample_stats(xs):
    n = len(xs)
    mu = sum(xs)/n
    var = sum((x-mu)**2 for x in xs) / n
    return mu, math.sqrt(max(var, 1e-12))

def simulate(mix_real=0.0, n_samples=50, n_generations=50):
    mu, sigma = 0.0, 1.0
    hist = [(mu, sigma)]
    xs = box_muller(n_samples, mu, sigma)
    for _ in range(n_generations):
        mu_hat, sigma_hat = sample_stats(xs)
        hist.append((mu_hat, sigma_hat))
        n_syn = int(round(n_samples * (1 - mix_real)))
        n_real = n_samples - n_syn
        xs = box_muller(n_syn, mu_hat, sigma_hat) + box_muller(n_real, 0.0, 1.0)
    return hist

def avg(trials, mix_real, n_samples, n_generations):
    acc_var = [0.0] * (n_generations + 1)
    for t in range(trials):
        random.seed(t)
        h = simulate(mix_real, n_samples, n_generations)
        for i, (_, s) in enumerate(h):
            acc_var[i] += s*s
    return [v/trials for v in acc_var]

if __name__ == "__main__":
    # coarser sampling, more trials, gen=50
    for n in (50, 200):
        print(f"\n--- n_samples = {n} ---")
        c0 = avg(500, 0.0, n, 50)
        c1 = avg(500, 0.25, n, 50)
        c2 = avg(500, 0.50, n, 50)
        print(f"{'gen':>3} | mix=0.00 | mix=0.25 | mix=0.50")
        for g in (0, 10, 20, 30, 40, 50):
            print(f"{g:>3} | {c0[g]:>8.3f} | {c1[g]:>8.3f} | {c2[g]:>8.3f}")
        # exportable
        print("pts mix=0.00", [(g, round(c0[g], 3)) for g in range(0, 51, 5)])
        print("pts mix=0.25", [(g, round(c1[g], 3)) for g in range(0, 51, 5)])
        print("pts mix=0.50", [(g, round(c2[g], 3)) for g in range(0, 51, 5)])
